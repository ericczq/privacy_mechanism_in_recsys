version https://git-lfs.github.com/spec/v1
oid sha256:dda2343acc495f6aa30962b6be4a1b0cc316afa51a201627ae691b405e8c44fa
size 17300
