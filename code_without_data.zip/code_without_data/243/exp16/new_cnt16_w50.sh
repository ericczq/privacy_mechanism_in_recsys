version https://git-lfs.github.com/spec/v1
oid sha256:99741925e2f62cfcd9618d6d19f5c4912290c34c07f64dc4e26e8cc72958c7e7
size 3002
