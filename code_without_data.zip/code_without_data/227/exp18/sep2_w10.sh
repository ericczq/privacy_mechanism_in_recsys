version https://git-lfs.github.com/spec/v1
oid sha256:24f9000f45007eb02492d686a25239aea5caf33fb8db2c4714c0038aa6b13bed
size 1297
