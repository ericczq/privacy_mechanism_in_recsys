version https://git-lfs.github.com/spec/v1
oid sha256:cea0b33c79653fe067d3a8310c051449cf427d7589685b93383e4f5de5ad6b00
size 876
