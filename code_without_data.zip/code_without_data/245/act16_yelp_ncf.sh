version https://git-lfs.github.com/spec/v1
oid sha256:25b15db1b693d7a56dec19ab8d64beeccc90b87f1c9e366ce2fcd72b61252e15
size 1592
