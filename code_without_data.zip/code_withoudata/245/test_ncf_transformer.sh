cd ..


#python main_rl.py --regenerate 1 --model_name NCF --loss softmax_cross_entropy \
# --emb_size 128 --hidden_size 128 --num_neg 16 \
#  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
#       --dataset ml-100k \
#        --gpu 6 --exp_id 10 \
#       --topk [5,10,20,50,100] --min_strategy all --epoch 40 \
#        --random_seed 42 \
#        --version mv_tmp \
#        --rl_working_step 0 --rl_agent_type EpsilonGreedy --test_epoch 5 \
#       --action_split_len 4  \
#        --specific_num 424 --risk_policy_agt_num 212 --continues True \
#        --reload_init_rec_reward 0 --save_init_rec_reward_path 'mvlen100k_sn424_ncf_result.pkl'
#
#
#python main_rl.py --regenerate 1 --model_name NCF --loss softmax_cross_entropy \
# --emb_size 128 --hidden_size 128 --num_neg 16 \
#  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
#       --dataset yelp --eval_on_sampling 1000 \
#        --gpu 6 --exp_id 10 \
#        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
#        --random_seed 42 \
#        --version tmp_yelp \
#        --rl_working_step 0 --rl_agent_type EpsilonGreedy --test_epoch 5 \
#       --action_split_len 4  \
#        --specific_num 5558 --risk_policy_agt_num 2779  \
#        --reload_init_rec_reward 0 --save_init_rec_reward_path 'yelp_sn5558_rn2779_ncf_result.pkl'
#
#
#
#python main_rl.py --regenerate 1 --model_name BiSA --loss softmax_cross_entropy \
# --emb_size 128 --hidden_size 128 --num_neg 512 --num_heads 4 --num_layers 1 \
#  --lr 1e-4 --l2 1e-4 --dropout 0.2 --history_max 50 \
#       --dataset ml-100k \
#        --gpu 6 --exp_id 10 \
#        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
#        --random_seed 42 \
#        --version test_tmp \
#        --rl_working_step 0 --rl_agent_type EpsilonGreedy --test_epoch 1 \
#       --action_split_len 4  \
#        --specific_num 424 --risk_policy_agt_num 212 --continues True \
#        --reload_init_rec_reward 0 --save_init_rec_reward_path 'mvlen100k_tmp_sn424_transformer_128_result.pkl'

#nag 1024 = 2061

#  0.2086
#python main_rl.py --regenerate 1 --model_name BiSA --loss softmax_cross_entropy \
# --emb_size 128 --hidden_size 128 --num_neg 512 --num_heads 4 --num_layers 1 \
#  --lr 5e-4 --l2 1e-4 --dropout 0.2 --history_max 50 \
#       --dataset ml-100k \
#        --gpu 6 --exp_id 10 \
#        --topk [5,10,20,50,100] --min_strategy all --epoch 15 \
#        --random_seed 42 \
#        --version test_tmp \
#        --rl_working_step 0 --rl_agent_type EpsilonGreedy --test_epoch 1 \
#       --action_split_len 4  \
#        --specific_num 424 --risk_policy_agt_num 212 --continues True \
#        --reload_init_rec_reward 0 --save_init_rec_reward_path 'mvlen100k_tmp_sn424_transformer_128_result.pkl'



python main_rl.py --regenerate 1 --model_name BiSA --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 num_neg 128 \
  --lr 5e-4 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset yelp --eval_on_sampling 1000 \
        --gpu 1 --exp_id 10 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 15 \
        --random_seed 42 \
        --version tmp_yelp \
        --rl_working_step 0 --rl_agent_type EpsilonGreedy --test_epoch 2 \
       --action_split_len 4  \
        --specific_num 5558 --risk_policy_agt_num 2779  \
        --reload_init_rec_reward 0 \
        --save_init_rec_reward_path 'yelp_tmp_sn5558_rn2779_transformer_128_result.pkl'
