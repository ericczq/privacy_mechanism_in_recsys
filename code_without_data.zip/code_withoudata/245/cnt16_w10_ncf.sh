cd ..
python main_rl.py --regenerate 1 --model_name NCF --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset ml-100k \
        --gpu 3 --exp_id 10 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version NCF_cnt_act16_sn424_rn212_w10 \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16  \
        --specific_num 424 --risk_policy_agt_num 212 --continues True --risky_w 10 \
        --reload_init_rec_reward 1 \
        --save_init_rec_reward_path '/mnt/eric.czq/privacy_clean/src/mvlen100k_sn424_gru_result.pkl'


#python main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
# --emb_size 128 --hidden_size 128 --num_neg 16 \
#  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
#       --dataset ml-100k \
#        --gpu 4 --exp_id 9 \
#        --topk [5,10,20,50,100] --min_strategy all --epoch 40 \
#        --random_seed 42 \
#        --version cnt_act16_sn424_rn212_w10 --dataloader_mode longest \
#        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
#       --action_split_len 16  \
#        --specific_num 424 --risk_policy_agt_num 212 --continues True --risky_w 10 \
#        --reload_init_rec_reward 1 \
#        --save_init_rec_reward_path '/mnt/eric.czq/privacy_clean/src/mvlen100k_sn424_gru_result.pkl'
