# -*- coding: UTF-8 -*-

import os
import sys
import pickle
import logging
import argparse
import numpy as np
import torch
import warnings
import random
import gc

from preprocessing.eric_dataloader import *
from preprocessing.Masked_User import *

from models import *
from helpers import *
from utils import utils
from rl_helper.rl_utils import *
from rl_helper.solver import *
from copy import deepcopy


def parse_global_args(parser):
    parser.add_argument('--gpu', type=str, default='1',
                        help='Set CUDA_VISIBLE_DEVICES')
    parser.add_argument('--verbose', type=int, default=logging.INFO,
                        help='Logging Level, 0, 10, ..., 50')
    parser.add_argument('--log_file', type=str, default='',
                        help='Logging file path')
    parser.add_argument('--random_seed', type=int, default=2021,
                        help='Random seed of numpy and pytorch.')
    parser.add_argument('--load', type=int, default=0,
                        help='Whether load model and continue to train')
    parser.add_argument('--i_emb_path', type=str, default='',
                        help='The path of pre-trained item embedding file')
    parser.add_argument('--train', type=int, default=1,
                        help='To train the model or not.')
    parser.add_argument('--regenerate', type=int, default=0,
                        help='Whether to regenerate intermediate files.')
    parser.add_argument('--eval_on_sampling', type=int, default=0,
                        help='Eval on random negative samplings or the whole candidate sets.')
    parser.add_argument('--version', type=str, default='1',
                        help='to tackle the problem of log that can only run a model a time')
    parser.add_argument('--user_feature_train', type=bool, default=False,
                        help='Model use User chararter feature or not ')

    parser.add_argument('--rl_working_step', type=int, default=40,  # 200
                        help='Each RL agent working epoch ')
    parser.add_argument('--rl_agent_type', type=str, default='UCB',  #
                        help='agent_type is [EpsilonGreedy,UCB,BayesianUCB,ThompsonSampling] ')

    parser.add_argument('--rl_reload_path', type=str, default=None,  #
                        help='reload path for rl_pretrained_agent ')
    parser.add_argument('--rl_reload_version', type=str, default=None,  #
                        help='reload version for rl_pretrained_agent ')
    parser.add_argument('--rl_reload_step', type=int, default=None,  #
                        help='reload step for rl_pretrained_agent ')

    parser.add_argument('--action_split_len', type=int, default=5,  #
                        help='2**N action sapce ')

    parser.add_argument('--continues', type=bool, default=False,  #
                        help='whether open the continus action  ')

    parser.add_argument('--open_usr_feature', type=bool, default=False,  #
                        help='whether open the user_feature')

    parser.add_argument('--min_all_information_num', type=int, default=4000,  #
                        help='min_all_information_num')
    parser.add_argument('--specific_num', type=int, default=None,  #
                        help='specific policy agent num')

    parser.add_argument('--risk_policy_agt_num', type=int, default=300,  #
                        help='risk_policy_agt_num, include in specific agent num')

    parser.add_argument('--character_feature_len', type=int, default='4',  #
                        help='personal character feature length')

    parser.add_argument('--dataloader_mode', type=str, default='latest',  #
                        help='specific dataloader_name [longest, latest, random]')

    parser.add_argument('--exp_id', type=int, default=0,  #
                        help='the experiment id for saving results')

    parser.add_argument('--reload_init_rec_reward', type=int, default='0',  #
                        help='reload_init_rec_reward or not. If 0 then do not use this function.')
    parser.add_argument('--save_init_rec_reward_path', type=str, default=None,  #
                        help='save_init_rec_reward_path. Eg xx.pkl ')

    parser.add_argument('--risky_w', type=float, default=10.0,  #
                        help='save_init_rec_reward_path. Eg xx.pkl ')

    parser.add_argument('--enhanced', type=bool, default=False,  #
                        help='enhanced with user feature cost. False = not really care about each ')

    parser.add_argument('--profile_combined', type=bool, default=False,  #
                        help='combined_profile')

    return parser


def rec_model_train(args, mask_user,init=False):
    #
    if args.continues == False and args.dataloader_mode == 'random':
        print('warining! : appear not continue action mode with random shuffle!')
        import time
        time.sleep(150)
    #


    corpus = reader_name(args,
                         mask_user=mask_user,
                         history_split_mode=args.dataloader_mode, action_split_len=args.action_split_len
                         )

    # get user len
    user_ori_data_len = deepcopy(corpus.ori_len)
    user_polic_data_len = deepcopy(corpus.policy_u_len)

    # get user feature embedding
    feature_embedding_dim_list = mask_user.character_feature_embedding_dim

    # Define model
    model = model_name(args, corpus, user_feature_dim=feature_embedding_dim_list,
                       user_feature_train=args.user_feature_train)

    logging.info(model)
    model = model.double()
    model.apply(model.init_weights)
    model.actions_before_train()
    if torch.cuda.device_count() > 0:
        model = model.cuda()

    # Run model
    data_dict = dict()
    for phase in ['train', 'dev', 'test']:
        ds_args = {'phase': phase,
                   'eval_on_sampling': args.eval_on_sampling,
                   'ns_mode': model.ns_mode,
                   'num_neg': model.num_neg,
                   'val_num_neg': args.val_num_neg}
        if args.dataset in ('books_2018', 'yelp') and phase == 'dev':
            ds_args['eval_on_sampling'] = 1
        data_dict[phase] = SeqDataset.SeqDataset(corpus, ds_args)

    del corpus
    gc.collect()

    runner = runner_name(args)

    if args.load > 0:
        model.load_model()
    elif args.i_emb_path != '':
        model.load_pretrained_i_emb(args.i_emb_path)

    # logging.info('Test Before Training: ' + runner.print_res(model, data_dict['test'], args.eval_on_sampling))
    if args.train > 0:
        runner.train(model, data_dict)
    logging.info(
        os.linesep + 'Test After Training: ' + runner.print_res(model, data_dict['test'],
                                                                args.eval_on_sampling))

    model.actions_after_train()
    logging.info(os.linesep + '-' * 45 + ' END: ' + utils.get_time() + ' ' + '-' * 45)

    reward_list = runner.print_reward(model, data_dict['test'], args.eval_on_sampling)  # [0,N-1]



    ## added for test  0 results
    if init :
        logging.info(
            os.linesep + 'Test with 0 padding After Training: ' + runner.print_res(model, data_dict['test'],
                                                                                   args.eval_on_sampling))
        mask_user.reset_zero_policy_user_action()
        mask_user.reset_zero_risk_policy_user_action()
        corpus = reader_name(args,
                             mask_user=mask_user,
                             history_split_mode=args.dataloader_mode, action_split_len=args.action_split_len
                             )
        zero_data_dict = dict()
        for phase in ['train', 'dev', 'test']:
            ds_args = {'phase': phase,
                       'eval_on_sampling': args.eval_on_sampling,
                       'ns_mode': model.ns_mode,
                       'num_neg': model.num_neg,
                       'val_num_neg': args.val_num_neg}
            if args.dataset in ('books_2018', 'yelp') and phase == 'dev':
                ds_args['eval_on_sampling'] = 1
            zero_data_dict[phase] = SeqDataset.SeqDataset(corpus, ds_args)

        del corpus
        gc.collect()

        model.actions_after_train()
        logging.info(os.linesep + '-' * 45 + ' END: ' + utils.get_time() + ' ' + '-' * 45)

        zero_reward_list = runner.print_reward(model, zero_data_dict['test'], args.eval_on_sampling)  # [0,N-1]


        mask_user.reset_full_policy_user_action()

        return reward_list,user_ori_data_len,user_polic_data_len,zero_reward_list
    else:
        return reward_list, user_ori_data_len, user_polic_data_len


def main():
    logging.info('-' * 45 + ' BEGIN: ' + utils.get_time() + ' ' + '-' * 45)
    exclude = ['check_epoch', 'log_file', 'model_path', 'path', 'pin_memory',
               'regenerate', 'sep', 'train', 'verbose']
    logging.info(utils.format_arg_str(args, exclude_lst=exclude))

    # Random seed
    random.seed(args.random_seed)
    np.random.seed(args.random_seed)
    torch.manual_seed(args.random_seed)
    torch.cuda.manual_seed(args.random_seed)

    # GPU
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu
    logging.info("# cuda devices: {}".format(torch.cuda.device_count()))

    #
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    ## inital user class
    mask_user = mkdataset(dataset=args.dataset, dataset_path=args.path,
                          character_feature_len=args.character_feature_len, action_split_len=args.action_split_len,
                          device=device, min_all_information_num=args.min_all_information_num,
                          continues_setting=args.continues, open_usr_feature=args.open_usr_feature
                          )
    #

    mask_user.initial_random_user_list(specific_num=args.specific_num, risk_policy_user_num=args.risk_policy_agt_num)
    print('privacy user number is ' + str(mask_user.get_policy_user_num()))
    print('Within privacy user, severe risk user number is ' + str(mask_user.get_risk_policy_user_num()))
    privacy_user_id_list = mask_user.get_policy_user_index_list()
    ## finish inital user on dataset


    ## multi agent initial

    #

    agent_list, action_space, start_step,record_reward_list = inital_agent_list(args, privacy_user_id_list=privacy_user_id_list)

    #
    print(agent_list[0])
    if start_step == 0:
        print('begin inital when all mask is 1')
        mask_user.reset_full_policy_user_action()



        if args.reload_init_rec_reward > 0:
            print('reloading inital rec reward')
            if args.save_init_rec_reward_path is not None:

                with open(args.save_init_rec_reward_path, 'rb') as file:
                    init_reward_lists = pickle.load(file)
            else:
                print('args.save_init_rec_reward_path is None!!!')
        else:
            # get the init reward
            init_reward_lists,_,_,zero_reward_list = rec_model_train(args, mask_user,init=True)
            if args.save_init_rec_reward_path is not None:
                f2 = open(args.save_init_rec_reward_path, 'wb')
                pickle.dump(init_reward_lists, f2)
                print('save init_reward_lists in :' + str(args.save_init_rec_reward_path))

        # set_best_rec_reword(init_reward_list,rec_reward_name='NDCG@100')
        if args.open_usr_feature:
            if args.enhanced:
                most_privacy_cost=1.0#+float(args.character_feature_len)
            else:
                most_privacy_cost=2.0

            init_agt_preference(agent_list, init_reward_lists, rec_reward_name='NDCG@100',
                                risk_user_list=mask_user.get_risk_policy_user_index_list(), risky_w=args.risky_w,
                                most_privacy_cost=most_privacy_cost)#,zero_reward_list=zero_reward_list)#added profile cost 1.0
        else:
            init_agt_preference(agent_list, init_reward_lists, rec_reward_name='NDCG@100',
                            risk_user_list=mask_user.get_risk_policy_user_index_list(), risky_w=args.risky_w)
        print('finish inital')
    else:

        for agt in agent_list:
            #print('id is '+str(agt.get_uid())+' and his action is'+str(agt.get_latest_action()))
            if args.open_usr_feature==True:
                mask_user.set_policy_user_action_with_profile(agt.get_uid(), agt.get_latest_action(),profile_combined=args.profile_combined)
            else:
                # set action except profile
                mask_user.set_policy_user_action_except_profile(agt.get_uid(),agt.get_latest_action())

    # show initial weight
    for agt in agent_list:
        print('user ' + str(agt.get_uid()) + ' computed gamma is ' + str(agt.get_gamma()))

    #  begin training
    record_trained_model_name = args.version
    #record_reward_list=[]
    print('rec_reward list len is '+str(len(record_reward_list)))
    #
    for rl_epoch in range(start_step, args.rl_working_step):
        if args.open_usr_feature==True:
            rl_generate_new_action_with_profile(mask_user, rl_epoch, agent_list, privacy_user_id_list,profile_combined=args.profile_combined)
        else:
            rl_generate_new_action(mask_user, rl_epoch, agent_list, privacy_user_id_list)

        reward_list,user_ori_data_len,user_polic_data_len = rec_model_train(args, mask_user)
        record_reward_list.append(reward_list['NDCG@100'])
        #
        # if 'tmp' in args.version:
        #     uid=reward_list['uid']
        #     file = open(args.version+'uid.pkl', 'wb')
        #     pickle.dump(uid, file)
        #     file.close()
        ## end for model training
        rl_agent_train(args, rl_epoch, agent_list, reward_list, privacy_user_id_list,
                       exp_id=args.exp_id,save_list=record_reward_list,
                       user_ori_data_len=user_ori_data_len, user_polic_data_len=user_polic_data_len
                       )


if __name__ == '__main__':

    # warnings.filterwarnings('ignore')
    warnings.filterwarnings("ignore", category=Warning)

    init_parser = argparse.ArgumentParser(description='Model')
    init_parser.add_argument('--model_name', type=str, default='BPR', help='Choose a model to run.')
    # added dataloader_name
    init_parser.add_argument('--dataloader_name', type=str, default='BaseReader_eric',
                             help='specific dataloader_name [BaseReader_eric , BaseReader_eric_latest_upload, BaseReader_eric_random_percentage]')
    #
    init_args, init_extras = init_parser.parse_known_args()
    model_name = eval('{0}.{0}'.format(init_args.model_name))

    # print(init_args.dataloader_name)

    # 将str转化为实例-> 修改t.b.d
    if init_args.dataloader_name is None:
        reader_name = eval('{0}.{0}'.format(model_name.reader))
        print('inital at' + str(model_name.reader))
    else:
        # print(init_args.dataloader_name)
        reader_name = eval('{0}.{0}'.format(init_args.dataloader_name))
        print('inital at' + str(init_args.dataloader_name))

    runner_name = eval('{0}.{0}'.format(model_name.runner))

    # Args
    parser = argparse.ArgumentParser(description='')
    parser = parse_global_args(parser)
    parser = reader_name.parse_data_args(parser)
    parser = runner_name.parse_runner_args(parser)
    parser = model_name.parse_model_args(parser)
    args, extras = parser.parse_known_args()

    #
    print(args.topk)

    # Logging configuration
    log_args = [args.dataset, args.version, str(args.random_seed)]
    # for arg in ['loss', 'num_neg', 'eval_on_sampling', 'dropout', 'lr', 'l2', 'history_max', 'num_heads', 'inner_times', 'num_layers'] + model_name.extra_log_args:
    for arg in ['dataloader_mode', 'action_split_len', 'continues', 'specific_num'] + model_name.extra_log_args:
        if arg in args:
            log_args.append(arg + '=' + str(eval('args.' + arg)))

    log_file_name = '__'.join(log_args).replace(' ', '__')
    if args.i_emb_path != '':
        log_file_name += '__finetune=' + args.i_emb_path[args.i_emb_path.rfind('/') + 1:args.i_emb_path.find('__')]
    if args.log_file == '':
        args.log_file = '../log/{}/{}.txt'.format(init_args.model_name, log_file_name)
    if args.model_path == '':
        args.model_path = '../model/{}/{}.pt'.format(init_args.model_name, log_file_name)

    utils.check_dir(args.log_file)
    logging.basicConfig(filename=args.log_file, level=args.verbose)
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(init_args)

    main()
