# -*- coding: UTF-8 -*-

import os
import sys
import pickle
import logging
import argparse
import numpy as np
import torch
import warnings
import random

 
from models import *
from helpers import *
from utils import utils


def parse_global_args(parser):
    parser.add_argument('--gpu', type=str, default='0',
                        help='Set CUDA_VISIBLE_DEVICES')
    parser.add_argument('--verbose', type=int, default=logging.INFO,
                        help='Logging Level, 0, 10, ..., 50')
    parser.add_argument('--log_file', type=str, default='',
                        help='Logging file path')
    parser.add_argument('--random_seed', type=int, default=2019,
                        help='Random seed of numpy and pytorch.')
    parser.add_argument('--load', type=int, default=0,
                        help='Whether load model and continue to train')
    parser.add_argument('--i_emb_path', type=str, default='',
                        help='The path of pre-trained item embedding file')
    parser.add_argument('--train', type=int, default=1,
                        help='To train the model or not.')
    parser.add_argument('--regenerate', type=int, default=0,
                        help='Whether to regenerate intermediate files.')
    parser.add_argument('--eval_on_sampling', type=int, default=0,
                        help='Eval on random negative samplings or the whole candidate sets.')
    parser.add_argument('--num_layers', type=int, default=2,
                            help='Number of self-attention layers.')
    parser.add_argument('--num_heads', type=int, default=2,
                            help='Number of self-attention heads.')
    parser.add_argument('--inner_times', type=int, default=2,
                            help='times of embedding size.')
    parser.add_argument('--final_print', type=int, default=0,
                            help='whether eval and test at each epoch.')
    parser.add_argument('--version', type=str, default='1',
                            help='to tackle the problem of log that can only run a model a time')
    parser.add_argument('--compo', type=int, default=0,
                            help='to tackle the problem of log that can only run a model a time')
    parser.add_argument('--singleaug', type=int, default=0,
                            help='to tackle the problem of log that can only run a model a time')
    parser.add_argument('--analy', type=int, default=0,
                            help='to tackle the problem of log that can only run a model a time')
    return parser




#warnings.filterwarnings('ignore')
warnings.filterwarnings("ignore", category=Warning)

init_parser = argparse.ArgumentParser(description='Model')
init_parser.add_argument('--model_name', type=str, default='GRU4Rec', help='Choose a model to run.')
init_args, init_extras = init_parser.parse_known_args()
model_name = eval('{0}.{0}'.format(init_args.model_name))
reader_name = eval('{0}.{0}'.format(model_name.reader))
runner_name = eval('{0}.{0}'.format(model_name.runner))

# Args
parser = argparse.ArgumentParser(description='')
parser = parse_global_args(parser)
parser = reader_name.parse_data_args(parser)
parser = runner_name.parse_runner_args(parser)
parser = model_name.parse_model_args(parser)
args, extras = parser.parse_known_args()

args.dataset = 'yelp'
# Logging configuration
log_args = [args.version, init_args.model_name, args.dataset, str(args.random_seed)]
#for arg in ['loss', 'num_neg', 'eval_on_sampling', 'dropout', 'lr', 'l2', 'history_max', 'num_heads', 'inner_times', 'num_layers'] + model_name.extra_log_args:
for arg in ['num_neg', 'eval_on_sampling', 'dropout', 'lr', 'l2', 'history_max', 'num_heads', 'inner_times', 'num_layers'] + model_name.extra_log_args:
    log_args.append(arg + '=' + str(eval('args.' + arg)))


log_file_name = '__'.join(log_args).replace(' ', '__')
if args.i_emb_path != '':
    log_file_name += '__finetune=' + args.i_emb_path[args.i_emb_path.rfind('/')+1:args.i_emb_path.find('__')]
if args.log_file == '':
    args.log_file = '../log/{}/{}.txt'.format(init_args.model_name, log_file_name)
if args.model_path == '':
    args.model_path = '../model/{}/{}.pt'.format(init_args.model_name, log_file_name)

utils.check_dir(args.log_file)
logging.basicConfig(filename=args.log_file, level=args.verbose)
logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
logging.info(init_args)

# Random seed
random.seed(args.random_seed)
np.random.seed(args.random_seed)
torch.manual_seed(args.random_seed)
torch.cuda.manual_seed(args.random_seed)

# GPU
args.gpu = '7'
args.min_k = 5
args.init_k = 5
args.num_neg=4
args.model_name = 'GRU4Rec'
args.loss = 'softmax_cross_entropy'
args.emb_size = 128
args.hidden_size = 100
args.history_max = 50

args.topk = '[5,10,20,50,100]'
args.min_strategy = 'all'
args.eval_batch_size = 1024
os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu
logging.info("# cuda devices: {}".format(torch.cuda.device_count()))

# Read data
corpus_path = os.path.join(args.path, args.dataset, model_name.reader + '.pkl')
if not args.regenerate and os.path.exists(corpus_path):
    logging.info('Load corpus from {}'.format(corpus_path))
    corpus = pickle.load(open(corpus_path, 'rb'))
else:
    corpus = reader_name(args)
    logging.info('Save corpus to {}'.format(corpus_path))
    pickle.dump(corpus, open(corpus_path, 'wb'))


# Define model
model = model_name(args, corpus)
logging.info(model)
model = model.double()
model.apply(model.init_weights)
model.actions_before_train()
if torch.cuda.device_count() > 0:
    model = model.cuda()

# Run model
data_dict = dict()
ds_args = {'eval_on_sampling': args.eval_on_sampling,
           'ns_mode': model.ns_mode,
           'num_neg': model.num_neg}

for phase in ['train', 'dev', 'test']:
    ds_args['phase'] = phase
    data_dict[phase] = SeqDataset.SeqDataset(corpus, ds_args)

runner = runner_name(args)

data = data_dict['test']

# from torch.utils.data import DataLoader
# dl = DataLoader(data, batch_size=256, shuffle=False, num_workers=2, collate_fn=data.collate_batch, pin_memory=True)

# for b in dl:
#     b = utils.batch_to_gpu(b)
# #     i_ids = b['item_id']          # [batch_size, -1]
# #     history = b['item_his']  # [batch_size, history_max]
# #     lengths = b['lengths']
# #     i_vectors = model.i_embeddings(i_ids)
# #     his_vectors = model.i_embeddings(history)

# #     # Sort and Pack
# #     sort_his_lengths, sort_idx = torch.topk(lengths, k=len(lengths))
# #     sort_his_vectors = his_vectors.index_select(dim=0, index=sort_idx)
#     prediction = model(b, 'test', 0)
#     break

# from time import time
# t1 = time()
# logging.info('Test Before Training: ' + runner.print_res(model, data_dict['test'], args.eval_on_sampling))
# t2 = time()
# logging.info('{:<.1f} s'.format(t2-t1))


# # runner.train(model, data_dict, args.final_print)

# data = data_dict['train']
# data.negative_sampling()

from torch.utils.data import DataLoader
dl = DataLoader(data, batch_size=4, shuffle=True, num_workers=2, collate_fn=data.collate_batch, pin_memory=True)

for b in dl:
    b = utils.batch_to_gpu(b)
    prediction = model(b, 'test', 0)
    break

prediction = prediction.cpu().data.numpy()
u_id = batch["user_id"].cpu().data.numpy()
filtered_idx = [list(data.user_clicked_set[u]) for u in u_id]
for i, j in enumerate(filtered_idx):
    prediction[i][j] = -np.inf