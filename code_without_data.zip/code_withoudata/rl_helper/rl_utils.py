import random
from collections import defaultdict
import pickle
from copy import deepcopy
from rl_helper.solver import *
import torch
import os


def int_to_binary_list_continues(action_split_len=5, action=0):
    ans = []
    tmp = action
    while (tmp > 0):
        ans.append(1)
        tmp = tmp - 1
    while (len(ans) < action_split_len):
        ans.append(0)
    assert len(ans) == action_split_len

    # latest upload first

    # latest upload first
    # eg action = 1 -> [0,0,0,0,1] then the last part upload
    ans.reverse()

    return ans


def generate_random_reward(rnd_agent_num=0):
    # debug on pc
    # data structure reward_list:
    # 'uid' : [1...N] type long
    # 'HR@5' :[1..N] type bool
    # 'HR@10' :[1..N] type bool
    # 'HR@20' :[1..N] type bool
    # 'HR@50' :[1..N] type bool
    # 'HR@100' :[1..N] type bool

    # 'NDCG@5' :[1..N] type bool
    # 'NDCG@10' :[1..N] type bool
    # 'NDCG@20' :[1..N] type bool
    # 'NDCG@50' :[1..N] type bool
    # 'NDCG@100' :[1..N] type bool
    reward_list = defaultdict(list)
    uid = [i + 1 for i in range(rnd_agent_num)]

    HR = [random.random() for i in range(rnd_agent_num)]
    ndcg = [random.random() for i in range(rnd_agent_num)]

    # print(HR)
    # print(ndcg)
    metric_list = ['@5', '@10', '@20', '@50', '@100']
    p = 1.0 / len(metric_list)
    cnt = 1.0
    #
    reward_list['uid'] += uid

    for metric in metric_list:
        reward_list['HR' + metric] = [j * cnt > 1.8 for j in HR]
        reward_list['NDCG' + metric] = [j * cnt * p for j in ndcg]

        cnt = cnt + 1

    return reward_list


def compute_policy_reward(uid=0, action=3, action_split_len=5,
                          reward_list=[], rec_reward_name='NDCG@100',
                          alpha=0.5, user_prefer=1, continues_setting=False,
                          user_ori_data_len=[], user_polic_data_len=[],
character_feature_len=4, open_usr_feature=False,enhanced=False,w=1,profile_combined=False
                          ):
    ##
    # user id start from [1,N], 0 is empty user without any data
    # id list = reward_list['uid']
    # uid = privacy_user_id_list[cnt]
    # returned ndcg reward id start from 0 !! [0,N-1]
    ##
    # # get the mask by action
    # if (continues_setting == False):
    #     cnt = 0
    #     tmp = action
    #     while (tmp):
    #         cnt = cnt + (tmp & 1)
    #         tmp = tmp >> 1
    # #
    # else:
    #     cnt = action

    # get uid in rec_reward
    rewards_list_id = reward_list['uid'].index(uid)

    rec_reward = reward_list[rec_reward_name][rewards_list_id]

    # print(rec_reward)
    if open_usr_feature==True:

        if profile_combined==True:
            #history_action = action % 2
            #attribute_action_coded = int(action / 2)
            history_action = int (action / 2)
            attribute_action_coded = action % 2

            if attribute_action_coded ==1:
                attribute_action= (2 ** character_feature_len)-1
            else:
                attribute_action =0

        else:
            history_action = int(action / (2 ** character_feature_len))
            attribute_action = action % (2 ** character_feature_len)


        shared_attribute_action = bin(attribute_action).count('1')
        print( bin(attribute_action) )

        if user_polic_data_len[uid]==0 and shared_attribute_action>0 and rec_reward>0.2:
            print('the agent '+str(uid)+' share no history with attribute' +str(bin(attribute_action)) +'with rec reward' + str(rec_reward) )

        if enhanced:
            # history_action = int ( action /  (2 ** character_feature_len) )
            if continues_setting==False:
                history_action=bin(history_action).count('1')


            #privacy_cost = -1.0 * ( (history_action + shared_attribute_action)*1.0 / (character_feature_len+action_split_len ) )

            beta=w*1.0 / alpha
            #tmp =  beta * (shared_attribute_action*1.0) / character_feature_len
            #print(tmp)
            privacy_cost = -1.0 * ( (user_polic_data_len[uid] / user_ori_data_len[uid]) + \
                                    beta * (shared_attribute_action*1.0) / character_feature_len
                                    )

        else:
            privacy_cost = -1.0 * ( (user_polic_data_len[uid] / user_ori_data_len[uid])+ shared_attribute_action*1.0 /character_feature_len  )
    else:
        privacy_cost = -1.0 * user_polic_data_len[uid] / user_ori_data_len[uid]

    return user_prefer * rec_reward + alpha * privacy_cost , rec_reward, privacy_cost

    # return alpha * rec_reward + (1 - alpha) * user_prefer * privacy_cost


def int_to_binary_list(action_split_len=5, action=0):
    ans = []
    tmp = int(action)
    if (tmp == 0):
        ans.append(0)

    while (tmp > 0):
        ans.append(int(tmp % 2))
        tmp = int(tmp / 2)

    while (len(ans) < action_split_len):
        ans.append(0)

    assert len(ans) == action_split_len

    # latest upload first
    # eg action = 1 -> [0,0,0,0,1] then the last part upload
    ans.reverse()

    return ans


def save_agent_results(args,agent_list, step='0',exp_id=0,result_list=None,policy_list=None):

    if args.continues ==True:
        results_file='rl_cnt_record'
    else:
        results_file = 'rl_record'

    save_dir='./results/exp'+str(exp_id)+'/'+results_file+'/'+ args.rl_agent_type + '/' + args.dataloader_mode + '/'

    if (save_dir is None):
        print('you for get input filename')
        return
    if os.path.exists(save_dir) == False:
        print('making dir ' + str(save_dir))
        os.makedirs(save_dir)
        #os.makedirs(save_path)

    final_name = save_dir +  str(args.version) + '_epoch_' + step + '.pickle'
    print('begin save at '+final_name)

    file = open(final_name, 'wb')
    pickle.dump(agent_list, file)
    file.close()

    if result_list is not None:
        result_list_file = save_dir +  str(args.version) + '_epoch_' + step + 'results_list.pickle'
        file = open(result_list_file, 'wb')
        pickle.dump(result_list, file)
        file.close()
    if policy_list is not None:
        policy_list_file = save_dir + str(args.version) + '_epoch_' + step + 'policy_list.pickle'
        file = open(policy_list_file, 'wb')
        pickle.dump(policy_list, file)
        file.close()
    return


def load_agent_result(save_dir=None, version='0', step=0):
    if (save_dir is None):
        print('you for get input filename')
        return
    final_name = save_dir + str(version) + '_epoch_' + str(step) + '.pickle'
    result_list_file = save_dir + str(version) + '_epoch_latestresults_list.pickle'
    with open(result_list_file, 'rb') as file:
        rec_list = pickle.load(file)

    with open(final_name, 'rb') as file:
        agent_list = pickle.load(file)

    return agent_list,rec_list[0:step+1]




def inital_agent_list(args, privacy_user_id_list=[]):
    # if args.open_usr_feature==True:
    #     action_split_len = args.action_split_len + args.character_feature_len
    # else:
    action_split_len = args.action_split_len

    # action_space = 2 ** action_split_len
    if args.continues == False:
        action_space = 2 ** action_split_len
    else:
        action_space = action_split_len + 1

    if args.open_usr_feature:
        if args.profile_combined==True:
            action_space = action_space * 2
        else:
            action_space = action_space * (2** args.character_feature_len)

    solvers_list = [
        EpsilonGreedy(action_space, eps=0.5),
        UCB1(action_space),
        BayesianUCB(action_space, std_dev=3, Beta_a=1, Beta_b=1),
        ThompsonSampling(action_space, Beta_a=1, Beta_b=1)
    ]
    solvers_id_list = ['EpsilonGreedy', 'UCB', 'BayesianUCB', 'ThompsonSampling']
    solver_id = solvers_id_list.index(args.rl_agent_type)

    print('agent type is ' + args.rl_agent_type)
    print('agent solver id is ' + str(solver_id))
    # initail
    agent_list = []
    for i,agt_id in enumerate(privacy_user_id_list):
        agent_list.append(deepcopy(solvers_list[solver_id]))
        agent_list[i].set_uid(agt_id)

    #
    start_step=0
    record_reward_list = []
    if args.rl_reload_path is not None:
        agent_list,record_reward_list = load_agent_result(
            save_dir=args.rl_reload_path,
            # '/Users/eric.czq/Downloads/home/eric.czq/eric/privacy/privacy/src/rl_record/UCB/',
            version=args.rl_reload_version, step=args.rl_reload_step)  # 'rl_no_usrfeaturerl_epoch30'
        print('reload rl agt list success')
        start_step=args.rl_reload_step+1
        print('reload rec reward list with len: ' +str(len(record_reward_list)))

    return agent_list, action_space,start_step,record_reward_list


def rl_agent_train(args, rl_epoch, agent_list, reward_list, privacy_user_id_list,exp_id=0,save_list=[],
                   user_ori_data_len=[],user_polic_data_len=[]):
    ## end for model training
    for cnt, agt in enumerate(agent_list):
        agt_id = agt.get_uid()
        action = agt.get_latest_action()
        uud=privacy_user_id_list[cnt]
        print('cnt id ' + str(cnt) + 'uid is ' + str(privacy_user_id_list[cnt])+ 'compute privacy cost act is : ' + str(agt.get_latest_action()) )

        total_reward,rec_reward, privacy_cost = compute_policy_reward(uid=privacy_user_id_list[cnt], action=agt.get_latest_action(),
                                           reward_list=reward_list, rec_reward_name='NDCG@100',
                                           action_split_len=args.action_split_len,
                                           alpha=agt.get_gamma(), continues_setting=args.continues,
                                           user_prefer=1,  # each user treat privacy may differ,
        user_ori_data_len = user_ori_data_len, user_polic_data_len = user_polic_data_len, enhanced=args.enhanced,w=agt.get_w(),profile_combined=args.profile_combined,
        character_feature_len=args.character_feature_len, open_usr_feature=args.open_usr_feature #according to the user feature optimize
                                           )
        #
        # print(new_reward)
        agt.record_rec(rec_reward)
        agt.record_reward(total_reward)
        agt.record_cost(privacy_cost)
        agt.update_policy(agt.get_latest_action())

    print('-----begin saving latest results -----')
    save_agent_results(args,agent_list=agent_list,step='latest',exp_id=exp_id,result_list=save_list,policy_list=user_polic_data_len)


    if (rl_epoch> 100 and (rl_epoch % 100) == 0) or rl_epoch + 1 == args.rl_working_step:
        print('saving agent list results at ' + str(rl_epoch))
        save_agent_results(args, agent_list=agent_list, step=str(rl_epoch), exp_id=exp_id)

def rl_generate_new_action(mask_user,rl_epoch,agent_list,privacy_user_id_list):
    # 生成隐私策略
    # mask_user.set_random_mask()
    # debug for check

    old_mask_list = mask_user.get_policy_user_action_except_profile()
    print('now is rl_epoch :' + str(rl_epoch) + ' and the old mask is ')
    print(old_mask_list)

    for cnt, agt in enumerate(agent_list):
        new_action = agt.generate_action()
        agt.record_action(new_action)
        # print(agt.get_latest_action())
        mask_user.set_policy_user_action_except_profile(uid=privacy_user_id_list[cnt], action=new_action)

    # update all policy user
    new_mask_list = mask_user.get_policy_user_action_except_profile()
    print(new_mask_list)

def rl_generate_new_action_with_profile(mask_user,rl_epoch,agent_list,privacy_user_id_list,profile_combined=False):
    # 生成隐私策略
    # mask_user.set_random_mask()
    # debug for check

    old_mask_list = mask_user.get_policy_user_action_except_profile()
    print('now is rl_epoch :' + str(rl_epoch) + ' and the old mask is ')
    print(old_mask_list)

    #
    old_profile_mask = mask_user.get_policy_user_action_only_profile()
    print('---on the rl_epoch :' + str(rl_epoch) + ' and the old profile mask is ---')
    print(old_profile_mask)


    for cnt, agt in enumerate(agent_list):
        new_action = agt.generate_action() #
        agt.record_action(new_action)
        print('cnt id ' + str(cnt) + 'uid is ' + str(privacy_user_id_list[cnt])+ ' act is : ' +str(agt.get_latest_action()) + 'mask record act is '+ str(new_action))


        mask_user.set_policy_user_action_with_profile(uid=privacy_user_id_list[cnt], action=new_action, profile_combined=profile_combined)

    # update all policy user
    new_mask_list = mask_user.get_policy_user_action_except_profile()
    print(new_mask_list)
    new_profile_mask= mask_user.get_policy_user_action_only_profile()
    print('---on the rl_epoch :' + str(rl_epoch) + ' and the new profile mask is ---')
    # 所有mask user的 dataset上的mask
    for data in new_profile_mask:
        print(data)
    #print(new_profile_mask)


def init_agt_preference(agent_list,init_reward_lists,rec_reward_name='NDCG@100',risk_user_list=[],risky_w=10,most_privacy_cost=1.0,zero_reward_list=None):


    cnt=0
    for i,agt in enumerate(agent_list):
        uid = agt.get_uid()

        if uid in risk_user_list:
            # user is severe risk aware user
            agt.set_w_value(risky_w)
        else:
            #normal user
            agt.set_w_value(1)

        best_rec_reward = init_reward_lists[rec_reward_name][init_reward_lists['uid'].index(uid)]
        if zero_reward_list is None:
            worst_reward=0.0
        else:
            worst_reward = zero_reward_list[rec_reward_name][init_reward_lists['uid'].index(uid)]
        agt.set_gamma_value(best_rec_reward=best_rec_reward,worst_reward=worst_reward,
                            most_privacy_cost=most_privacy_cost,least_privacy_cost=0.0,min_value=1e-6)

        if agt.get_gamma()==1e-6:
            cnt+=1
    print('gamma num' + str(cnt)+'!!!')

    return