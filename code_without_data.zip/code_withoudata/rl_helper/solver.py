from __future__ import division

import numpy as np
import time
from scipy.stats import beta
import random

class Solver(object):
    def __init__(self, bandit_n):
        """
        bandit (Bandit): the target bandit to solve.
        """

        self.bandit_n = bandit_n

        self.counts = [0] * self.bandit_n
        self.actions = []  # A list of machine ids, 0 to bandit.n-1.
        self.regret = 0.  # Cumulative regret.
        self.regrets = [0.]  # History of cumulative regret.
        self.reward = 0.
        self.reward_list = []
        self.rec_reward_list=[]
        self.cost_list=[]

        self.gamma=1
        self.w=1

        self.uid=-1

    def update_regret(self, i):
        # i (int): index of the selected machine.
        self.regret += self.bandit.best_proba - self.bandit.probas[i]
        self.regrets.append(self.regret)

    @property
    def estimated_probas(self):
        raise NotImplementedError

    def run_one_step(self):
        """Return the machine index to take action on."""
        raise NotImplementedError

    def run(self, num_steps):
        for _ in range(num_steps):
            i = self.run_one_step()

            self.counts[i] += 1
            self.actions.append(i)
            self.update_regret(i)

    # eric
    ## record result
    def record_rec(self,rec_reward):
        self.rec_reward_list.append(rec_reward)
        return

    def record_cost(self,cost):
        self.cost_list.append(cost)
        return

    def record_reward(self, reward):

        self.reward = reward

        self.reward_list.append(reward)
    def record_action(self, i):

        self.counts[i] += 1
        self.actions.append(i)

    def set_uid(self,uid):
        self.uid=uid
        return

    def set_w_value(self,w):
        self.w=w
        return
    def set_gamma_value(self,best_rec_reward=1.0,worst_reward=0.0,most_privacy_cost=1.0,
                        least_privacy_cost=0.0,min_value=1e-6):

        self.gamma = max(min_value*self.w ,self.w * abs( (best_rec_reward - worst_reward) / (most_privacy_cost -least_privacy_cost )))
        return
    ##
    def update_reward(self, reward):
        self.reward = reward
        return

    def generate_action(self):
        raise NotImplementedError

    def update_policy(self):
        raise NotImplementedError

    def get_w(self):
        return self.w

    def get_gamma(self):
        return self.gamma

    def get_uid(self):
        return self.uid
    def get_latest_action(self):
        if len(self.actions) == 0:
            return -1
        else:
            return self.actions[-1]



    def get_latest_reward(self):
        if len(self.reward_list) == 0:
            return -1
        else:
            return self.reward_list[-1]




class EpsilonGreedy(Solver):
    def __init__(self, bandit_n, eps, init_proba=0.0):
        """
        eps (float): the probability to explore at each time step.
        init_proba (float): default to be 1.0; optimistic initialization
        """
        super(EpsilonGreedy, self).__init__(bandit_n)

        assert 0. <= eps <= 1.0
        self.eps = eps
        self.t=0

        self.decay = 0.5 #3 * self.bandit_n #ori: 10

        self.estimates = [init_proba] * self.bandit_n  # Optimistic initialization
        # list len = n

    @property
    def estimated_probas(self):
        return self.estimates

    def run_one_step(self):
        if np.random.random() < self.eps:
            # Let's do random exploration!
            i = np.random.randint(0, self.bandit_n)
        else:
            # Pick the best one.
            i = max(range(self.bandit_n), key=lambda x: self.estimates[x])

        # get reward
        r = self.bandit.generate_reward(i)
        #

        self.estimates[i] += 1. / (self.counts[i] + 1) * (r - self.estimates[i])

        return i

    # eric

    def generate_action(self):

        if np.random.random() < self.eps:
            # Let's do random exploration!
            #i = np.random.randint(0, self.bandit_n)
            # updated to the m
            action_possibility = np.array([ 1/(num+1e-6) for num in self.counts])
            action_possibility /=  sum(action_possibility)
            i = np.random.choice([i for i in range(self.bandit_n)], p=action_possibility.ravel())
        else:
            # Pick the best one.
            #i = max(range(self.bandit_n), key=lambda x: self.estimates[x])

            # with shuffle
            max_act_list = [k for k, v in enumerate(self.estimates) if v == max(self.estimates)]
            random.shuffle(max_act_list)
            i=max_act_list[0]
        # record
        # self.record_action(i)

        return i

    def update_policy(self, i):  # do  record_action(self,i) before update policy

        # self.estimates[i] += 1. / (self.counts[i] + 1) * (self.reward - self.estimates[i])
        # old version as cnt+1 after update policy

        self.estimates[i] += 1. / (self.counts[i] + 1) * (self.reward - self.estimates[i])

        self.t+=1

        self.eps=0.5 **(self.t /  (3 * self.bandit_n))


class UCB1(Solver):
    def __init__(self, bandit_n, init_proba=1.0):
        super(UCB1, self).__init__(bandit_n)
        self.t = 0
        self.estimates = [init_proba] * self.bandit_n

    @property
    def estimated_probas(self):
        return self.estimates

    def run_one_step(self):
        self.t += 1

        # Pick the best one with consideration of upper confidence bounds.
        i = max(range(self.bandit.n), key=lambda x: self.estimates[x] + np.sqrt(
            2 * np.log(self.t) / (1 + self.counts[x])))

        r = self.bandit.generate_reward(i)

        self.estimates[i] += 1. / (self.counts[i] + 1) * (r - self.estimates[i])

        return i

    # eric
    def generate_action(self):
        self.t+=1
        i = max(range(self.bandit_n), key=lambda x: self.estimates[x] + np.sqrt(
            2 * np.log(self.t) / (1 + self.counts[x])))
        return i

    def update_policy(self, i):  # do  record_action(self,i) before update policy

        # self.estimates[i] += 1. / (self.counts[i] + 1) * (self.reward - self.estimates[i])
        # old version as cnt+1 after update policy
        #print(self.reward)

        self.estimates[i] += 1. / (self.counts[i]) * (self.reward - self.estimates[i])




class BayesianUCB(Solver):
    """Assuming Beta prior."""

    def __init__(self, bandit_n, std_dev=3, Beta_a=1, Beta_b=1):
        """
        c (float): how many standard dev to consider as upper confidence bound.
        init_a (int): initial value of a in Beta(a, b).
        init_b (int): initial value of b in Beta(a, b).
        """
        super(BayesianUCB, self).__init__(bandit_n)
        self.c = std_dev
        self._as = [Beta_a] * self.bandit_n
        self._bs = [Beta_b] * self.bandit_n

    @property
    def estimated_probas(self):
        return [self._as[i] / float(self._as[i] + self._bs[i]) for i in range(self.bandit_n)]

    def run_one_step(self):
        # Pick the best one with consideration of upper confidence bounds.
        i = max(
            range(self.bandit_n),
            key=lambda x: self._as[x] / float(self._as[x] + self._bs[x]) + beta.std(
                self._as[x], self._bs[x]) * self.c
        )
        r = self.bandit.generate_reward(i)

        # Update Gaussian posterior
        self._as[i] += r
        self._bs[i] += (1 - r)

        return i

    # eric
    def generate_action(self):
        i = max(
            range(self.bandit_n),
            key=lambda x: self._as[x] / float(self._as[x] + self._bs[x]) + beta.std(
                self._as[x], self._bs[x]) * self.c
        )

        return i

    def update_policy(self, i):  # do  record_action(self,i) before update policy

        # self.estimates[i] += 1. / (self.counts[i] + 1) * (self.reward - self.estimates[i])
        # old version as cnt+1 after update policy
        self._as[i] += self.reward
        self._bs[i] += (1 - self.reward)


class ThompsonSampling(Solver):
    def __init__(self, bandit_n, Beta_a=1, Beta_b=1):
        """
        init_a (int): initial value of a in Beta(a, b).
        init_b (int): initial value of b in Beta(a, b).
        """
        super(ThompsonSampling, self).__init__(bandit_n)

        self._as = [Beta_a] * self.bandit_n
        self._bs = [Beta_b] * self.bandit_n

    @property
    def estimated_probas(self):
        return [self._as[i] / (self._as[i] + self._bs[i]) for i in range(self.bandit_n)]

    def run_one_step(self):
        samples = [np.random.beta(self._as[x], self._bs[x]) for x in range(self.bandit_n)]
        i = max(range(self.bandit_n), key=lambda x: samples[x])
        r = self.bandit.generate_reward(i)

        self._as[i] += r
        self._bs[i] += (1 - r)

        return i

    # eric
    def generate_action(self):
        samples = [np.random.beta(self._as[x], self._bs[x]) for x in range(self.bandit_n)]
        i = max(range(self.bandit_n), key=lambda x: samples[x])

        return i

    def update_policy(self, i):  # do  record_action(self,i) before update policy

        # self.estimates[i] += 1. / (self.counts[i] + 1) * (self.reward - self.estimates[i])
        # old version as cnt+1 after update policy
        self._as[i] += self.reward
        self._bs[i] += (1 - self.reward)
