# -*- coding: UTF-8 -*-

import os
import time
import pickle
import argparse
import logging
import numpy as np
from collections import defaultdict 


def most_recent(user_hist, K = 10):
    begin_ts = 970329600
    train_min = {}
    
    for u, hist in user_hist.items():
        early_data = [i for i, t in hist if t < begin_ts]
        
        law_idx = 0
        for idx, par in enumerate(hist):
            if par[1] >= begin_ts:
                law_idx = idx
                break
        
        early_data = hist[:law_idx]
        recent_data = hist[law_idx:][-K:]
        
        train_min[u] = early_data + recent_data
        
    return train_min


# expand raw data to training samples
def build_samples(raw_train, raw_test):
    # make sure raw_train was worted by timestamp
    user_clicked_set = {}
    
    train = dict()
    u_id = []
    target_id = []
    i_hist = []
    test_u_id = []
    test_target_id = []
    test_i_hist = []
    for u, hist in raw_train.items():
        user_clicked_set[u] = set([x[0] for x in hist])
        for idx, (i, t) in enumerate(hist):
            u_id.append(u)
            target_id.append(i)
            i_hist.append([x[0] for x in hist[:idx]])
            
        if isinstance(raw_test[u][0], list):
            for idx, (i, t) in enumerate(raw_test[u]):
                test_u_id.append(u)
                test_target_id.append(i)
                test_i_hist.append([x[0] for x in hist + raw_test[u][:idx]])
        elif isinstance(raw_test[u][0], int):
            test_u_id.append(u)
            test_target_id.append(raw_test[u][0])
            test_i_hist.append([x[0] for x in hist])
            
    train = {'user_id': u_id,
            'item_id': target_id,
            'item_his': i_hist}
    test = {'user_id': test_u_id,
            'item_id': test_target_id,
            'item_his': test_i_hist}
        
    return train, test
