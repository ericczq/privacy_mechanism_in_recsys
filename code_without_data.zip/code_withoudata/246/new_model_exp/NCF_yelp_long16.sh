cd ..
cd ..


python main_rl.py --regenerate 1 --model_name NCF --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset yelp --eval_on_sampling 1000 \
        --gpu 6 --exp_id 13 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version NCF_yelp_cnt16_sn5558_rn2779_w10 \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16 --dataloader_mode longest \
        --specific_num 5558 --risk_policy_agt_num 2779 --continues True \
       --risky_w 10 \
        --reload_init_rec_reward 1 \
         --save_init_rec_reward_path '/mnt/eric.czq/privacy_clean/src/yelp_sep4_sn5558_rn2779_gru_result.pkl'



python main_rl.py --regenerate 1 --model_name NCF --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset yelp --eval_on_sampling 1000 \
        --gpu 6 --exp_id 13 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version NCF_yelp_cnt16_sn5558_rn2779_w10 \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16  \
        --specific_num 5558 --risk_policy_agt_num 2779 --continues True \
       --risky_w 10 \
        --reload_init_rec_reward 1 \
         --save_init_rec_reward_path '/mnt/eric.czq/privacy_clean/src/yelp_sep4_sn5558_rn2779_gru_result.pkl'

python main_rl.py --regenerate 1 --model_name NCF --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset yelp --eval_on_sampling 1000 \
        --gpu 6 --exp_id 13 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version NCF_yelp_sep4_sn5558_rn2779_w10 \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 4  \
        --specific_num 5558 --risk_policy_agt_num 2779  \
        --reload_init_rec_reward 1 \
         --save_init_rec_reward_path '/mnt/eric.czq/privacy_clean/src/yelp_sep4_sn5558_rn2779_gru_result.pkl'


#python3 main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
# --emb_size 128 --hidden_size 128 --num_neg 16 \
#  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
#       --dataset yelp --eval_on_sampling 1000 \
#        --gpu 4 --exp_id 9 \
#        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
#        --random_seed 42 \
#        --version yelp_cnt4_sn5558_rn2779_w10 \
#        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
#       --action_split_len 4  --dataloader_mode longest \
#        --specific_num 5558 --risk_policy_agt_num 2779 --continues True \
#        --reload_init_rec_reward 0 \
#        --reload_init_rec_reward 1 \
#         --save_init_rec_reward_path '/mnt/eric.czq/privacy_clean/src/yelp_sep4_sn5558_rn2779_gru_result.pkl'
#

