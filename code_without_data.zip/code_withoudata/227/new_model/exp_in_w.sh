cd ..
cd ..
## w=2
python main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset ml-100k \
        --gpu 1 --exp_id 15 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version cnt_act16_sn424_rn212_w2 \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16  \
        --specific_num 424 --risk_policy_agt_num 212 --continues True --risky_w 2 \
        --reload_init_rec_reward 0 \
        --save_init_rec_reward_path '/mnt1/eric.czq/privacy_clean/src/w_model/mvlen100k_sn424_gru_w2_result.pkl'


python main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset ml-100k \
        --gpu 1 --exp_id 15 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version cnt_act16_sn424_rn212_w2 --dataloader_mode longest \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16  \
        --specific_num 424 --risk_policy_agt_num 212 --continues True --risky_w 2 \
        --reload_init_rec_reward 1 \
        --save_init_rec_reward_path '/mnt1/eric.czq/privacy_clean/src/w_model/mvlen100k_sn424_gru_w2_result.pkl'

## w=5

python main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset ml-100k \
        --gpu 1 --exp_id 11 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version cnt_act16_sn424_rn212_w5 \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16  \
        --specific_num 424 --risk_policy_agt_num 212 --continues True --risky_w 5 \
        --reload_init_rec_reward 0 \
       --save_init_rec_reward_path '/mnt/eric.czq/privacy_clean/src/w_model/mvlen100k_sn424_gru_w5_result.pkl'


python main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset ml-100k \
        --gpu 1 --exp_id 11 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version cnt_act16_sn424_rn212_w5 --dataloader_mode longest \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16  \
        --specific_num 424 --risk_policy_agt_num 212 --continues True --risky_w 5 \
        --reload_init_rec_reward 1 \
         --save_init_rec_reward_path '/mnt/eric.czq/privacy_clean/src/w_model/mvlen100k_sn424_gru_w5_result.pkl'

### w=20

python main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset ml-100k \
        --gpu 1 --exp_id 15 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version cnt_act16_sn424_rn212_w20 \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16  \
        --specific_num 424 --risk_policy_agt_num 212 --continues True --risky_w 20 \
        --reload_init_rec_reward 0 \
        --save_init_rec_reward_path '/mnt1/eric.czq/privacy_clean/src/w_model/mvlen100k_sn424_gru_w20_result.pkl'


python main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset ml-100k \
        --gpu 1 --exp_id 15 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version cnt_act16_sn424_rn212_w20 --dataloader_mode longest \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16  \
        --specific_num 424 --risk_policy_agt_num 212 --continues True --risky_w 20 \
        --reload_init_rec_reward 1 \
        --save_init_rec_reward_path '/mnt1/eric.czq/privacy_clean/src/w_model/mvlen100k_sn424_gru_w20_result.pkl'

##w =50

python main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset ml-100k \
        --gpu 1 --exp_id 11 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version cnt_act16_sn424_rn212_w50 \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16  \
        --specific_num 424 --risk_policy_agt_num 212 --continues True --risky_w 50 \
        --reload_init_rec_reward 0 \
       --save_init_rec_reward_path '/mnt/eric.czq/privacy_clean/src/w_model/mvlen100k_sn424_gru_w50_result.pkl'


python main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset ml-100k \
        --gpu 1 --exp_id 11 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version cnt_act16_sn424_rn212_w50 --dataloader_mode longest \
        --rl_working_step 600 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 16  \
        --specific_num 424 --risk_policy_agt_num 212 --continues True --risky_w 50 \
        --reload_init_rec_reward 1 \
         --save_init_rec_reward_path '/mnt/eric.czq/privacy_clean/src/w_model/mvlen100k_sn424_gru_w50_result.pkl'
