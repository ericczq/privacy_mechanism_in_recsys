cd ..
cd ..


## GRU


python main_rl.py --regenerate 1 --model_name GRU4Rec --loss softmax_cross_entropy \
 --emb_size 128 --hidden_size 128 --num_neg 16 \
  --lr 1e-3 --l2 1e-4 --dropout 0.2 --history_max 50 \
       --dataset ml-100k \
        --gpu 3 --exp_id 80 \
        --topk [5,10,20,50,100] --min_strategy all --epoch 30 \
        --random_seed 42 \
        --version New_his_added_Div4_Use_user_fearture_profile_cnt_GRU_cnt_act1_sn637_rn0_w10 \
        --rl_working_step 400 --rl_agent_type EpsilonGreedy --test_epoch 5 \
       --action_split_len 1  \
        --specific_num 637 --risk_policy_agt_num 0 --continues True --risky_w 10 \
        --reload_init_rec_reward 0 \
        --save_init_rec_reward_path '/mnt1/eric.czq/privacy_clean/src/New_his_added_user_div4_feature_mvlen100k_sn637_gru_result.pkl' \
        --open_usr_feature True --user_feature_train True \
        --profile_combined True