import os.path
import pickle
from rl_helper import *
from rl_helper.rl_utils import int_to_binary_list
import matplotlib.pyplot as plt
from collections import Counter
import torch
import numpy



class Save_logs(object):
    def __init__(self, exp_id=0, continues=True, dataloader_mode='latest', action_split=3,
                 epoch='latest', version='act3_sn630_rn300', specific_num=630, risk_policy_agt_num=300, save_dir='',
                 dataset='ml-100k', rl_agent_type='EpsilonGreedy'):
        self.exp_id = exp_id
        self.continues = continues
        self.dataloader_mode = dataloader_mode
        self.rl_agent_type = rl_agent_type
        self.dataset = dataset
        self.action_split = action_split
        self.action_space = -1

        self.epoch = epoch
        self.version = version

        self.policy_agent_num = specific_num
        self.risk_policy_agt_num = risk_policy_agt_num

        self.save_dir = save_dir
        self.model_file = ''
        self.model = None

        # sensitive users
        self.sensitive_w = 10
        # normal users
        self.normal_w = 1
        self.train_epoch = 0
        #
        self.figure_name_list=['action','privacy_cost','rec_reward','utility','gamma','estimation',
                               'non_zero_privacy_cost','non_zero_action',
                               'last_action']

    def set_model_file(self, path):
        self.model_file = path

    def set_action_space(self):
        if self.continues:
            self.action_space = self.action_split+1
        else:
            self.action_space = 2 ** self.action_split

    def init_results_list(self):
        self.normal_user_his = torch.zeros([4, self.policy_agent_num - self.risk_policy_agt_num, self.train_epoch])
        self.normal_user_id = []
        self.normal_user_gamma = []
        self.normal_user_define = "[4* normal_user_num * train_epoch] :u ser_action_list;user_cost_list;rec_reward_list;user_utility_list"
        self.normal_user_estimate = torch.zeros(self.policy_agent_num - self.risk_policy_agt_num,self.action_space)

        self.privacy_risk_user_his = torch.zeros([4, self.risk_policy_agt_num, self.train_epoch])
        self.privacy_risk_user_id = []
        self.privacy_risk_user_gamma = []
        self.privacy_risk_user_define = "[4* privacy_risk_num * train_epoch] :u ser_action_list;user_cost_list;rec_reward_list;user_utility_list"
        self.privacy_risk_user_estimate = torch.zeros(self.risk_policy_agt_num,self.action_space)

    def add_normal_user_result(self, users, list_id):

        self.normal_user_his[0][list_id] = torch.tensor(users.actions)
        self.normal_user_his[1][list_id] = torch.tensor(users.cost_list) *-1
        self.normal_user_his[2][list_id] = torch.tensor(users.rec_reward_list)
        self.normal_user_his[3][list_id] = torch.tensor(users.reward_list)
        self.normal_user_gamma.append(users.gamma)
        self.normal_user_id.append(users.uid)
        self.normal_user_estimate[list_id]=torch.tensor(users.estimates)  # list N *[action space]


    def add_privacy_risk_user_results(self, users, list_id):
        self.privacy_risk_user_his[0][list_id] = torch.tensor(users.actions)
        self.privacy_risk_user_his[1][list_id] = torch.tensor(users.cost_list) * -1
        self.privacy_risk_user_his[2][list_id] = torch.tensor(users.rec_reward_list)
        self.privacy_risk_user_his[3][list_id] = torch.tensor(users.reward_list)
        self.privacy_risk_user_gamma.append(users.gamma)
        self.privacy_risk_user_id.append(users.uid)
        self.privacy_risk_user_estimate[list_id]=torch.tensor(users.estimates)   # list N *[action space]


    def load_model_file(self):
        with open(self.model_file, 'rb') as file:
            user_list = pickle.load(file)

            self.set_action_space()
            self.train_epoch = user_list[0].t

            self.init_results_list()
            cnt=0
            for i, users in enumerate(user_list):
                if users.w == self.normal_w:
                    self.add_normal_user_result(users=users, list_id=i-cnt)
                else:
                    self.add_privacy_risk_user_results(users=users, list_id=cnt)
                    cnt+=1

    def get_data(self,data_tensor,id='avg'):

        if id =='non_zero':
            results=torch.sum(data_tensor,dim=0) / torch.sum(data_tensor>0,dim=0)
            return results

        if id !='avg':
            id_num = int(id)
            if(id_num< data_tensor.size()[0]):
                return data_tensor[id].tolist()
            else:
                print('error key with id =  '+id)

        else:
            # deal with avg results
            results = torch.sum(data_tensor,dim=0) / data_tensor.size()[0]
            return results.tolist()

    def get_action_axis(self, ylabel=[]):
        if self.continues:
            return [i/self.action_split for i in range(self.action_split+1)]
        else:
            x_new_label = []
            # act = 0->2**N-1
            for i, y_ans in enumerate(ylabel):
                action = compute_action(i) / self.action_split
                x_new_label.append(action)

            return x_new_label

    def get_epoch_data(self,data_tensor,epoch=-1,figure_name='last_action',gamma=[]):

        epoch_data = data_tensor[:,epoch]

        if figure_name == 'non_zero_action':
            epoch_data3 = []
            for i,data in enumerate(epoch_data):

                if(gamma[i]>1e-6):
                    if self.continues:
                        epoch_data3.append(int(data) *1.0 /self.action_split)
                    else:
                        epoch_data3.append(compute_action(int(data))*1.0/self.action_split )
            return epoch_data3

        # deal with data distrbution
        if 'action' in figure_name:
            if self.continues:
                return (epoch_data*1.0/self.action_split).tolist()
            else:
                epoch_data2 = []

                for data in (epoch_data):
                    # print(data)
                    epoch_data2.append(compute_action(int(data))*1.0/self.action_split )
                    # print(epoch_data2[i])
                    # print('----')
                return epoch_data2

        return  epoch_data.tolist()







    def plot_result(self,figure_name,label,id='avg',normal_user=True,cnt=0):

        if(figure_name not in self.figure_name_list):
            print('figure name is '+figure_name +' not in the figure list '+str(self.figure_name_list))
            return

        if figure_name == 'gamma':
            plot_data = self.normal_user_gamma if normal_user else self.privacy_risk_user_gamma # gamma list
            plt.hist(plot_data,label=label)
            return plot_data

        elif figure_name =='estimation':
            plot_data = self.get_data(data_tensor=self.normal_user_estimate, id=id) if normal_user else self.get_data(
                data_tensor=self.privacy_risk_user_estimate, id=id)
            new_x = self.get_action_axis(ylabel=plot_data)
            if self.continues:
                plt.plot(new_x,plot_data,label=label)
            else:
                plt.scatter(new_x,plot_data,label=label)
            return plot_data
        elif figure_name =='last_action':
            # get the action distribution
            plot_data =self.get_epoch_data(data_tensor=self.normal_user_his[0],epoch=-1,figure_name=figure_name) if normal_user else self.get_epoch_data(
                data_tensor=self.privacy_risk_user_his[0], epoch=-1,figure_name=figure_name)
            #return by N agent * 1 behavior
            #plt.hist(plot_data+cnt*0.05, label=label,rwidth=0.5)
            import numpy as np
            uni_data =[da+cnt*0.1/6 for da in plot_data ]
            weights = np.ones_like(uni_data) / float(len(uni_data))
            plt.hist([da + cnt * 0.1 / 6 for da in plot_data], weights=weights, label=label, rwidth=0.1,bins=16)
            #plt.hist([da+cnt*0.1/6 for da in plot_data ],label=label,rwidth=0.1)

            return plot_data
        elif figure_name =='non_zero_action':
            plot_data = self.get_epoch_data(data_tensor=self.normal_user_his[0], epoch=-1,
                                            figure_name=figure_name,gamma=self.normal_user_gamma) if normal_user else self.get_epoch_data(
                data_tensor=self.privacy_risk_user_his[0], epoch=-1, figure_name=figure_name,gamma=self.privacy_risk_user_gamma)
            # return by N agent * 1 behavior
            plt.hist([da+cnt*0.1/6 for da in plot_data ], label=label,rwidth=0.2,bins=self.action_split)
            return plot_data
        elif figure_name =='non_zero_privacy_cost':

            his_index = self.figure_name_list.index('privacy_cost')
            plot_data = self.get_data(data_tensor = self.normal_user_his[his_index],id='non_zero')if normal_user else self.get_data(
                data_tensor=self.privacy_risk_user_his[his_index], id='non_zero')

            print(label + ' :' +str(plot_data[-1]))

            plt.plot([i for i in range(self.train_epoch)],plot_data,label=label)
            return plot_data
        else:
            his_index = self.figure_name_list.index(figure_name)
            plot_data = self.get_data(data_tensor = self.normal_user_his[his_index],id=id)if normal_user else self.get_data(
                data_tensor=self.privacy_risk_user_his[his_index], id=id)

            print(label + ' :' +str(plot_data[-1]))

            plt.plot([i for i in range(self.train_epoch)],plot_data,label=label)
            return plot_data




def compute_action(action=5):
    cnt = 0
    while (action):
        cnt = cnt + (action & 1)
        action = action >> 1

    return cnt


def add_result_into_args_list(continues_list=[], dataloader_list=[], action_split_list=[], epoch_list=[],
                              version_name_list=[], exp_id=0, specific_num=630, risk_policy_agt_num_list=[], save_dir='',
                              dataset='ml-100k', rl_agent_type='EpsilonGreedy'):
    args_list = []
    for continues in continues_list:
        for dataloader_mode in dataloader_list:
            for action_split in action_split_list:
                for epoch in epoch_list:
                  for risk_policy_agt_num in risk_policy_agt_num_list:
                    if len(version_name_list) == 0:
                        # construct version name temply (or into by list)
                        version_name = 'cnt_' if continues else ''
                        version_name = version_name + 'act' + str(action_split) + '_sn' + str(
                            specific_num) + '_rn' + str(
                            risk_policy_agt_num)
                    else:
                        version_name = ''

                    args = Save_logs(exp_id, continues, dataloader_mode, action_split, epoch, version_name,
                                     specific_num,
                                     risk_policy_agt_num, save_dir, dataset, rl_agent_type)

                    if args.continues == True:
                        results_file = 'rl_cnt_record'
                    else:
                        results_file = 'rl_record'

                    model_folder = save_dir + str(
                        exp_id) + '/' + results_file + '/' + args.rl_agent_type + '/' + args.dataloader_mode + '/'
                    final_name = model_folder + str(args.version) + '_epoch_' + epoch + '.pickle'

                    args.set_model_file(final_name)
                    # print('begin save at '+final_name)

                    if (os.path.exists(final_name)):
                        print('find model in ' + final_name + '! successful add into plot list')
                        args.load_model_file()
                        args_list.append(args)
                    else:
                        print('no model file in : ' + final_name + '! jumped')
                    #

    return args_list


def plot_summary(args_list,label_list=[],figure_name='privacy_cost',id='avg',normal_user=True):
    data_list=[]
    for i,args in enumerate(args_list):
        # figure_name=['action','privacy_cost','rec_reward','utility','gamma','estimation']

        data=args.plot_result(figure_name=figure_name,label=label_list[i],
                              id=id,normal_user=normal_user,cnt=i)
        #
        data_list.append(data)
        #


    return data_list
def plot_show(xlabel='epoch',title='avg privacy choice'):
    plt.legend()
    plt.xlabel(xlabel)
    plt.title(title)
    plt.show()
    return

def dealer(saved_pkl_name='tmp.pkl'):
    # inital
    args_list = []

    # parameter fixed

    exp_id = 1
    save_dir = './results/exp'
    dataset = 'ml-100k'
    rl_agent_type = 'EpsilonGreedy'

    specific_num = 630 #943
    risk_policy_agt_num =[300,0,100,200]
    #[0,100,200,400,600,800,943] expid=2

    # parameter list
    continues_list = [False, True]
    dataloader_list = ['latest', 'longest', 'random']
    action_split_list = [1,2,3, 4,8,16]  # [3,5]
    epoch_list = ['latest']
    version_name_list = []
    cnt = 0

    args_list=add_result_into_args_list(continues_list=continues_list, dataloader_list=dataloader_list,
                              action_split_list=action_split_list, epoch_list=epoch_list,
                              version_name_list=version_name_list,
                              exp_id=exp_id, specific_num=specific_num, risk_policy_agt_num_list=risk_policy_agt_num,
                              save_dir=save_dir, dataset=dataset, rl_agent_type=rl_agent_type)

    # display args_list or the model list
    print('-----------' + 'total model num is ' + str(len(args_list)) + '-------')


    #saved on pkl
    f = open(saved_pkl_name, 'wb')
    pickle.dump(args_list, f)
    #
    return args_list

def write_multi_list_into_txt(file_name='data.txt',data_list=[]):
   import numpy
   numpy.savetxt(file_name,numpy.array(data_list))

def read_from_disk(path):

    with open(path, 'rb') as file:
        args_list = pickle.load(file)
    return args_list

##
# main: load data from model or saved pkl
# then call the function in plot_summary  or args.plot()
# detailed in plot_summary
##
load_from_raw_model=False
if load_from_raw_model:
    args_list=dealer(saved_pkl_name='tmp.pkl')
else:
    args_list=read_from_disk('tmp.pkl')


# id ='avg' or 'any int' ('1')
# observe normal user (w=1) or privacy_risky set to True


for args in args_list:
    print(args.model_file)

#label_list=['sep_3','sep5','sep_ln_3','cnt_3','cnt_5','cnt_ln_3']

#手动改label list， 名称见print结果
label_list=['sep_3','sep4','cnt_3','cnt_4','cnt_ln_4']
# exp_id =0
# 0 3 ->sep 3 vs cnt3
# 1 4 ->sep5 vs cnt5
# 0 2 ->ln sep
# 3 5 ->ln cnt

label_list=['sep_3','sep4','sep8', # 0 1 2
            'cnt1','cnt2', 'cnt3','cnt4', # cnt4=rn300
            # 3     4       5      6
            'rn0','rn100','rn200',
            #7      8       9

            'cnt8','cnt16',
            #10 11
            'long_4','long_8','random4','random_8'
            #12      13      14       15
            ]

# exp_id=1
# 0   4 ->sep 3 vs cnt 3
# 1   5 8->sep 4 vs cnt 4 vs long 4
# 2,3,5,6,7 cnt 1,2,4,8,16
# 6 9 10

#######
# exp_id =2
#label_list=['rn0','rn100','rn200','rn400','rn600','rn800','rn943']

####

selected_list =[6,1,10,2] #3,4,6,7,8
#selected_list =[0,1,2,3,4,5,6]#[11,3,4,6,10] #3,4,6,7,8

figure_name='rec_reward'
# figure_name=['action','privacy_cost','rec_reward','utility',
# 'gamma','estimation','last_action','non_zero_privacy_cost','non_zero_action']

args_list=[args_list[i] for i in selected_list] #取几个画图
label_list=[label_list[i] for i in selected_list]

label_list1=[ label +'normal_user' for label in label_list]
label_list2=[ label +'risky_user' for label in label_list]

#data_list = plot_summary(args_list=args_list,label_list=label_list1,figure_name=figure_name,id='avg',normal_user=True)
data_list2 = plot_summary(args_list=args_list,label_list=label_list2,figure_name=figure_name,id='avg',normal_user=False)

#write_multi_list_into_txt(file_name='data.txt',data_list=data_list)




plot_show(xlabel='',title='avg '+figure_name) #use plot show to show figure and add figure configuration
