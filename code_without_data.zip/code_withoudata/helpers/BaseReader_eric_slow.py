# -*- coding: UTF-8 -*-
import os
import gc
import time
import pickle
import operator
import functools
import argparse
import logging
import numpy as np
from collections import defaultdict

from helpers.sampler import *
from preprocessing.Masked_User import *
from preprocessing.eric_dataloader import *
import copy


class BaseReader_eric(object):
    @staticmethod
    def parse_data_args(parser):
        parser.add_argument('--path', type=str, default='./data/',
                            help='Input data dir.')
        parser.add_argument('--dataset', type=str, default='Grocery_and_Gourmet_Food',
                            help='Choose a dataset.')
        parser.add_argument('--sep', type=str, default='\t',
                            help='sep of csv file.')
        parser.add_argument('--min_strategy', type=str, default='most_recent',
                            help='sampling strategy for data minimization.')
        parser.add_argument('--init_ratio', type=float, default=0.5,
                            help='The ratio of number of samples for data minimization: [0, 1].')
        parser.add_argument('--min_ratio', type=float, default=0.5,
                            help='The ratio of number of samples for data minimization: [0, 1].')
        parser.add_argument('--init_k', type=int, default=0,
                            help='The initial number of samples before data minimization.')
        parser.add_argument('--history_max', type=int, default=20,
                            help='Maximum length of history.')
        return parser

    def __init__(self, args, mask_user=None, history_split_mode='sequential', action_split_len=1):
        self.sep = args.sep
        self.prefix = args.path
        self.min_strategy = args.min_strategy
        self.min_ratio = args.min_ratio
        self.init_ratio = args.init_ratio
        self.init_k = args.init_k
        self.dataset = args.dataset
        self.history_max = args.history_max
        self.data_df = dict()
        self.user_clicked_set = dict()

        # eric added for mask_user
        self.history_split_mode = history_split_mode
        self.action_split_len = action_split_len

        self.mask_user = mask_user
        if mask_user is None:
            print('no mask user is loaded')
        else:
            print('success load for user privacy info')
        #

        assert self.min_ratio >= 0 and self.min_ratio <= 1, 'min_ration must be in [0, 1] !'

        t0 = time.time()
        self._read_data()
        # self._append_info()
        logging.info('Done! [{:<.2f} s]'.format(time.time() - t0) + os.linesep)

    def build_init_data(self, data, init_ratio, init_k):
        if init_ratio == 1.0:
            return data, {}

        total_num = sum([len(seq) for u, seq in data.items()])
        init_data = {u: seq[: init_k] for u, seq in data.items()}
        remain_data = {u: seq[init_k:] for u, seq in data.items()}
        idx = int(total_num * init_ratio + 0.5) - init_k * len(data)

        # remain_seq = sum(remain_data.values(), []) # too slow
        # remain_seq = []
        # for seq in remain_data.values():
        #     remain_seq += seq
        remain_seq = functools.reduce(operator.iconcat, remain_data.values(), [])
        remain_seq.sort(key=lambda x: x[1])
        timestamp = remain_seq[idx - 1][1]
        logging.info(
            'Finding timestamp \"{}\", for \"{}\" training data'.format(
                timestamp, init_ratio))

        for u, seq in remain_data.items():
            init_data[u] += [x for x in seq if x[1] < timestamp]
            remain_data[u] = [x for x in seq if x[1] >= timestamp]

        init_len = [len(v) for k, v in init_data.items()]
        logging.info('# init traing samples: {}'.format(np.sum(init_len)))
        logging.info('max user behavior seq len in init traing data: {}'.format(
            np.max(init_len)))
        logging.info('min user behavior seq len in init traing data: {}'.format(
            np.min(init_len)))
        logging.info('avg user behavior seq len in init traing data: {}'.format(
            np.mean(init_len)))
        logging.info(
            'median user behavior seq len in init traing data: {}'.format(
                np.median(init_len)))
        remain_len = [len(v) for k, v in remain_data.items()]
        logging.info('# empty users in remaining data: {}'.format(
            len([x for x in remain_len if x == 0])))

        return init_data, remain_data

    def build_test(self, init_data, test_data):
        valid_item = set()
        for hist in init_data.values():
            valid_item = valid_item.union(set([x[0] for x in hist]))

        # Note: right now, the format of test {u: i}
        logging.info('# items in init training data: {}'.format(len(valid_item)))
        logging.info('before filtering, # of test: {}'.format(len(test_data)))
        test_data = {k: v for k, v in test_data.items() if v[0] in valid_item}
        logging.info('after filtering, # of test: {}'.format(len(test_data)))

        return test_data

    def _read_data(self):
        self.n_users = 0
        self.n_items = 0

        logging.info('Reading data from \"{}\", dataset = \"{}\" '.format(self.prefix, self.dataset))
        data = defaultdict(list)
        with open(os.path.join(self.prefix, self.dataset, self.dataset + '.csv')) as f:
            next(f)
            for line in f:
                u, i, t = line.strip().split(self.sep)
                data[int(u)].append((int(i), int(t)))
                self.n_users = max(self.n_users, int(u))
                self.n_items = max(self.n_items, int(i))

        train, test = {}, {}
        for u, seq in data.items():
            # make sure the behavior seq is sorted by timestamp
            seq = sorted(seq, key=lambda x: x[1])
            train[u], test[u] = seq[:-1], seq[-1]
            self.user_clicked_set[u] = set([x[0] for x in train[u]])

        if self.min_strategy != 'all':
            try:
                # Note: here, right now, we just use fixed nnumber of init samples to test the systems.
                train = eval(self.min_strategy)(train, min_ratio=self.min_ratio, init_k=self.init_k, begin_ts=-1)
            except Exception as e:
                raise e

        self.data_df['train'], self.data_df['dev'], self.data_df['test'] = self.build_samples_eric(train, test)
        logging.info('Counting dataset statistics...')
        self.n_users += 1
        self.n_items += 1
        logging.info('"# user": {}, "# item": {}'.format(self.n_users, self.n_items))
        logging.info('"# train entry": {}'.format(len(self.data_df['train']['user_id'])))
        logging.info('"# dev entry": {}'.format(len(self.data_df['dev']['user_id'])))
        logging.info('"# test entry": {}'.format(len(self.data_df['test']['user_id'])))

    def build_samples(self, raw_train, raw_test, dev_num=1):
        # make sure raw_train was worted by timestamp
        u_id, target_id, i_hist, his_len = [], [], [], []
        dev_u_id, dev_target_id, dev_i_hist, dev_his_len = [], [], [], []
        test_u_id, test_target_id, test_i_hist, test_his_len = [], [], [], []

        for u, hist in raw_train.items():
            for idx, (i, t) in enumerate(hist[:-dev_num]):
                u_id.append(u)
                target_id.append(i)
                i_hist.append([x[0] for x in hist[:idx]])

            for idx, (i, t) in enumerate(hist[-dev_num:]):
                dev_u_id.append(u)
                dev_target_id.append(i)
                dev_i_hist.append([x[0] for x in hist[:-dev_num + idx]])

            if isinstance(raw_test[u][0], list):
                for idx, (i, t) in enumerate(raw_test[u]):
                    test_u_id.append(u)
                    test_target_id.append(i)
                    test_i_hist.append([x[0] for x in hist + raw_test[u][:idx]])
            elif isinstance(raw_test[u][0], int):
                test_u_id.append(u)
                test_target_id.append(raw_test[u][0])
                test_i_hist.append([x[0] for x in hist])

        if self.history_max > 0:
            i_hist = [x[-self.history_max:] for x in i_hist]
            dev_i_hist = [x[-self.history_max:] for x in dev_i_hist]
            test_i_hist = [x[-self.history_max:] for x in test_i_hist]

        his_len = [len(x) for x in i_hist]
        dev_his_len = [len(x) for x in dev_i_hist]
        test_his_len = [len(x) for x in test_i_hist]

        train = {'user_id': u_id,
                 'item_id': target_id,
                 'item_his': i_hist,
                 'his_length': his_len}

        dev = {'user_id': dev_u_id,
               'item_id': dev_target_id,
               'item_his': dev_i_hist,
               'his_length': dev_his_len}

        test = {'user_id': test_u_id,
                'item_id': test_target_id,
                'item_his': test_i_hist,
                'his_length': test_his_len}

        return train, dev, test

    def build_samples_eric(self, raw_train, raw_test, dev_num=1):
        # make sure raw_train was worted by timestamp
        u_id, target_id, i_hist, his_len = [], [], [], []
        dev_u_id, dev_target_id, dev_i_hist, dev_his_len = [], [], [], []
        test_u_id, test_target_id, test_i_hist, test_his_len = [], [], [], []

        # user privacy info loaded

        print('using latest upload data loader')

        privacy_user_id_list = self.mask_user.get_policy_user_index_list()
        history_split_mask = self.mask_user.get_policy_user_action_except_profile()

        # privacy_delete_percentage = 1 / (self.action_split_len + 1)  # eg. 33% | 50%

        # privacy_delete_percentage = 1 / (self.action_split_len-1 )  # eg. 33% | 50%  RL version

        # cut into 5 then-> 204 -> 50 100 150 200 204
        # cut into 5 then 200->
        action_split_len = self.action_split_len

        # len=1 ===> 50%

        u_feature, dev_u_feature, test_u_feature = [], [], []

        #
        max_len = -1
        privacy_ori_factor_list = []

        for u, hist_all in raw_train.items():

            #  hist 为user 的所有hist
            #  remove for given policy

            hist = []
            #  process for history space
            if u in privacy_user_id_list:  # u has privacy option
                # added for user prefer
                privacy_ori_factor_list.append(len(hist_all))
                list_u_id = privacy_user_id_list.index(u)
                user_action_privacy_mask = history_split_mask[list_u_id]

                if self.history_split_mode == 'longest':
                    hist_all.reverse()


                if (len(hist_all) % action_split_len == 0):  # 正好整除
                    # print(len(hist_all))
                    privacy_delete_percentage = 1 / (action_split_len)
                else:
                    privacy_delete_percentage = 1 / (action_split_len - 1)

                stop_num = int(len(hist_all) * privacy_delete_percentage)

                # debug

                ll = len(hist_all)

                #
                # if random
                if (self.history_split_mode == 'random'):

                    # get persentage
                    res_num = int(len(hist_all) * (user_action_privacy_mask.sum().cpu().__int__()) / action_split_len)

                    if (res_num > 0):
                        id_index = [idd for idd in range(ll)]
                        random.shuffle(id_index)
                        id_index = id_index[:res_num]

                        for i in range(ll):
                            if i in id_index:
                                hist.append(hist_all[i])

                    # print(0)
                elif (self.history_split_mode == 'longest' or self.history_split_mode == 'latest'):
                    cnt = 0
                    for permission in user_action_privacy_mask:
                        if (int(permission) == 1):
                            # added for the first part   50 100 150 200 204
                            # 205 = 41 82 123 164 205
                            # for i in range(stop_num):
                            # print(' under such permission is '+str(cnt*stop_num) + ' to ' + str((cnt+1)*stop_num) + ' and '+ str(len(hist_all)))

                            for i in range(cnt * stop_num, min((cnt + 1) * stop_num, len(hist_all))):  # debug version
                                hist.append(hist_all[i])
                        cnt = cnt + 1

                    if self.history_split_mode == 'longest':
                        hist.reverse()

                else:
                    print('no found split mode:  ' + str(self.history_split_mode))
                    return
            else:
                hist = hist_all

            max_len = max(max_len, len(hist))

            #
            if (len(hist) > 0):
                for idx, (i, t) in enumerate(hist[:-dev_num]):
                    u_id.append(u)
                    target_id.append(i)
                    i_hist.append([x[0] for x in hist[:idx]])

                    u_feature.append(self.mask_user.data[u] * self.mask_user.mask[u])

                for idx, (i, t) in enumerate(hist[-dev_num:]):
                    dev_u_id.append(u)
                    dev_target_id.append(i)
                    dev_i_hist.append([x[0] for x in hist[:-dev_num + idx]])

                    dev_u_feature.append(self.mask_user.data[u] * self.mask_user.mask[u])

            # added for test
            if (len(hist) == 0):
                hist.append((0, 0))
            #
            if isinstance(raw_test[u][0], list):
                for idx, (i, t) in enumerate(raw_test[u]):
                    test_u_id.append(u)
                    test_target_id.append(i)
                    test_i_hist.append([x[0] for x in hist + raw_test[u][:idx]])
            elif isinstance(raw_test[u][0], int):
                test_u_id.append(u)
                test_target_id.append(raw_test[u][0])
                test_i_hist.append([x[0] for x in hist])

            test_u_feature.append(self.mask_user.data[u] * self.mask_user.mask[u])

        if self.history_max > 0:
            i_hist = [x[-self.history_max:] for x in i_hist]
            dev_i_hist = [x[-self.history_max:] for x in dev_i_hist]
            test_i_hist = [x[-self.history_max:] for x in test_i_hist]

        his_len = [len(x) for x in i_hist]
        dev_his_len = [len(x) for x in dev_i_hist]
        test_his_len = [len(x) for x in test_i_hist]

        train = {'user_id': u_id,
                 'item_id': target_id,
                 'item_his': i_hist,
                 'user_feature': u_feature,
                 'his_length': his_len}

        dev = {'user_id': dev_u_id,
               'item_id': dev_target_id,
               'item_his': dev_i_hist,
               'user_feature': dev_u_feature,
               'his_length': dev_his_len}

        test = {'user_id': test_u_id,
                'item_id': test_target_id,
                'item_his': test_i_hist,
                'user_feature': test_u_feature,
                'his_length': test_his_len}

        # added
        #self.mask_user.set_privacy_ori_factor_list(privacy_ori_factor_list=privacy_ori_factor_list, max_len=max_len)
        #

        return train, dev, test
