# -*- coding: UTF-8 -*-

# todo: split data into train & test
# todo: sub sample data in train to minimize the data usage


import os
import time
import numpy as np
from collections import defaultdict

def most_recent(user_hist, min_ratio = 0.5, init_k = 5, begin_ts = 970329600):
    train_min = {}
    
    for u, hist in user_hist.items():
        init_data = [x for idx, x in enumerate(hist) if x[1] < begin_ts or idx < init_k]

        recent_data = [x for x in hist[len(init_data):] if x[1] >= begin_ts]
        K = int(len(recent_data) * min_ratio)
        if K > 0:
            train_min[u] = init_data + recent_data[-K:]
        else:
            train_min[u] = init_data
        
    return train_min


def calc_item_freq(user_hist, begin_ts, init_k):
    # build item freq using the data before the begining timestamp begin_ts
    i_freq = defaultdict(int)
    for u, hist in user_hist.items():
        for idx, (i, t) in enumerate(hist):
            if t < begin_ts or idx < init_k:
                i_freq[i] += 1
            else:
                break

    return i_freq

def most_pop(user_hist, min_ratio = 0.5, init_k = 5, begin_ts = 970329600):
    # build item freq using the data before the begining timestamp begin_ts
    i_freq = calc_item_freq(user_hist, begin_ts, init_k)

    train_min = {}
    for u, hist in user_hist.items():
        init_data = [x for idx, x in enumerate(hist) if x[1] < begin_ts or idx < init_k]
        recent_data = [x for x in hist[len(init_data):] if x[1] >= begin_ts]
        # sort index 
        K = int(len(recent_data) * min_ratio)
        recent_data = sorted(recent_data, key=lambda x: i_freq[x[0]], reverse=True)[:K]  # top freq
        recent_data = sorted(recent_data, key=lambda x: x[1])   # rebuild seq by timestamp
        train_min[u] = init_data + recent_data

    return train_min


def most_cold(user_hist, min_ratio = 0.5, init_k = 5, begin_ts = 970329600):
    # build item freq using the data before the begining timestamp begin_ts
    i_freq = calc_item_freq(user_hist, begin_ts, init_k)

    train_min = {}
    for u, hist in user_hist.items():
        init_data   = [x for idx, x in enumerate(hist) if x[1] < begin_ts or idx < init_k]
        recent_data = [x for x in hist[len(init_data):] if x[1] >= begin_ts]

        K = int(len(recent_data) * min_ratio)
        recent_data = sorted(recent_data, key=lambda x: i_freq[x[0]], reverse=True)[:K]  # top freq
        recent_data = sorted(recent_data, key=lambda x: x[1])   # rebuild seq by timestamp
        train_min[u] = init_data + recent_data

    return train_min


def pop_rand(user_hist, min_ratio = 0.5, init_k = 5, begin_ts = 970329600):
    # build item freq using the data before the begining timestamp begin_ts
    i_freq = calc_item_freq(user_hist, begin_ts, init_k)

    train_min = {}
    for u, hist in user_hist.items():
        init_data   = [x for idx, x in enumerate(hist) if x[1] < begin_ts or idx < init_k]
        recent_data = [x for x in hist[len(init_data):] if x[1] >= begin_ts]

        K = int(len(recent_data) * min_ratio)
        recent_data_p = np.array([i_freq[x[0]] for x in recent_data]) + 1e-10
        recent_data_p = recent_data_p / recent_data_p.sum()
        idx = np.random.choice(np.arange(len(recent_data)), K, replace=False, p=recent_data_p)
        recent_data = [recent_data[i] for i in idx]
        recent_data = sorted(recent_data, key=lambda x: x[1])  # rebuild seq by timestamp
        train_min[u] = init_data + recent_data

    return train_min


def cold_rand(user_hist, min_ratio = 0.5, init_k = 5, begin_ts = 970329600):
    i_freq = calc_item_freq(user_hist, begin_ts, init_k)
    train_min = {}
    for u, hist in user_hist.items():
        init_data   = [x for idx, x in enumerate(hist) if x[1] < begin_ts or idx < init_k]
        recent_data = [x for x in hist[len(init_data):] if x[1] >= begin_ts]

        K = int(len(recent_data) * min_ratio)
        recent_data_p = np.array([1.0/i_freq[x[0]] for x in recent_data]) + 1e-10
        recent_data_p = recent_data_p / recent_data_p.sum()
        idx = np.random.choice(np.arange(len(recent_data)), K, replace=False, p=recent_data_p)
        recent_data = [recent_data[i] for i in idx]
        recent_data = sorted(recent_data, key=lambda x: x[1])  # rebuild seq by timestamp
        train_min[u] = init_data + recent_data

    return train_min


def mmr(user_hist, min_ratio = 0.5, init_k = 5, begin_ts = 970329600):
    pass

    
     

