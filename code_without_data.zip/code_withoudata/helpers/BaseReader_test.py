import os
import logging
import argparse
from BaseReader import BaseReader

logging.basicConfig(level=logging.INFO)
parser = argparse.ArgumentParser()
parser = BaseReader.parse_data_args(parser)
args, extras = parser.parse_known_args()

args.history_max = 50
args.sep = '\t'
args.dataset = 'Sports'

args.path = '../../data/'
corpus = BaseReader(args)

train = corpus.data_df['train']
