# -*- coding: UTF-8 -*-

import os
import time
import pickle
import argparse
import logging
import numpy as np
import pandas as pd
from collections import defaultdict

from helpers.sampler import *

class BaseReader(object):
    @staticmethod
    def parse_data_args(parser):
        parser.add_argument('--path', type=str, default='./data/',
                            help='Input data dir.')
        parser.add_argument('--dataset', type=str, default='Grocery_and_Gourmet_Food',
                            help='Choose a dataset.')
        parser.add_argument('--sep', type=str, default='\t',
                            help='sep of csv file.')
        parser.add_argument('--min_strategy', type=str, default='most_recent',
                            help='sampling strategy for data minimization.')
        parser.add_argument('--min_ratio', type=float, default=0.5,
                            help='The ratio of number of samples for data minimization: [0, 1].')
        parser.add_argument('--init_k', type=int, default=0,
                            help='The initial number of samples before data minimization.')
        parser.add_argument('--history_max', type=int, default=20,
                            help='Maximum length of history.')
        return parser

    def __init__(self, args):
        self.sep              = args.sep
        self.prefix           = args.path
        self.min_strategy     = args.min_strategy
        self.min_ratio        = args.min_ratio
        self.init_k           = args.init_k
        self.dataset          = args.dataset
        self.history_max      = args.history_max
        self.data_df          = dict()
        self.user_clicked_set = dict()

        assert self.min_ratio >= 0 and self.min_ratio <= 1, 'min_ration must be in [0, 1] !'

        t0 = time.time()
        self._read_data()
        # self._append_info()
        logging.info('Done! [{:<.2f} s]'.format(time.time() - t0) + os.linesep)

    def _read_data(self):
        self.n_users = 0
        self.n_items = 0

        logging.info('Reading data from \"{}\", dataset = \"{}\" '.format(self.prefix, self.dataset))
        data = defaultdict(list)
        with open(os.path.join(self.prefix, self.dataset, self.dataset + '.csv')) as f:
            next(f)
            for line in f:
                u, i, t = line.strip().split(self.sep)
                data[int(u)].append((int(i), int(t)))
                self.n_users = max(self.n_users, int(u))
                self.n_items = max(self.n_items, int(i))

        train, test = {}, {}
        for u, seq in data.items():
            # make sure the behavior seq is sorted by timestamp
            seq = sorted(seq, key=lambda x: x[1])  
            train[u], test[u] = seq[:-1], seq[-1]
            self.user_clicked_set[u] = set([x[0] for x in train[u]])
        
        if self.min_strategy != 'all':
            try:
                # Note: here, right now, we just use fixed nnumber of init samples to test the systems.
                train = eval(self.min_strategy)(train, min_ratio=self.min_ratio, init_k=self.init_k, begin_ts=-1)
            except Exception as e:
                raise e

        self.data_df['train'], self.data_df['dev'], self.data_df['test'] = self.build_samples(train, test)
        logging.info('Counting dataset statistics...')
        self.n_users += 1
        self.n_items += 1
        logging.info('"# user": {}, "# item": {}'.format(self.n_users, self.n_items))
        logging.info('"# train entry": {}'.format(len(self.data_df['train']['user_id'])))
        logging.info('"# dev entry": {}'.format(len(self.data_df['dev']['user_id'])))
        logging.info('"# test entry": {}'.format(len(self.data_df['test']['user_id'])))


    def build_samples(self, raw_train, raw_test, dev_num=1):
        # make sure raw_train was worted by timestamp
        u_id, target_id, i_hist, his_len = [], [], [], []
        dev_u_id, dev_target_id, dev_i_hist, dev_his_len = [], [], [], []
        test_u_id, test_target_id, test_i_hist, test_his_len = [], [], [], []

        for u, hist in raw_train.items():
            for idx, (i, t) in enumerate(hist[:-dev_num]):
                u_id.append(u)
                target_id.append(i)
                i_hist.append([x[0] for x in hist[:idx]])
            
            for idx, (i, t) in enumerate(hist[-dev_num:]):
                dev_u_id.append(u)
                dev_target_id.append(i)
                dev_i_hist.append([x[0] for x in hist[:-dev_num+idx]])
                
            if isinstance(raw_test[u][0], list):
                for idx, (i, t) in enumerate(raw_test[u]):
                    test_u_id.append(u)
                    test_target_id.append(i)
                    test_i_hist.append([x[0] for x in hist + raw_test[u][:idx]])
            elif isinstance(raw_test[u][0], int):
                test_u_id.append(u)
                test_target_id.append(raw_test[u][0])
                test_i_hist.append([x[0] for x in hist])
        
        if self.history_max > 0:
            i_hist = [x[-self.history_max:] for x in i_hist]
            dev_i_hist = [x[-self.history_max:] for x in dev_i_hist]
            test_i_hist = [x[-self.history_max:] for x in test_i_hist]
        
        his_len = [len(x) for x in i_hist]
        dev_his_len = [len(x) for x in dev_i_hist]
        test_his_len = [len(x) for x in test_i_hist]

        train = {'user_id': u_id,
                'item_id': target_id,
                'item_his': i_hist,
                'his_length': his_len}
        dev = {'user_id': dev_u_id,
                'item_id': dev_target_id,
                'item_his': dev_i_hist,
                'his_length': dev_his_len}
        test = {'user_id': test_u_id,
                'item_id': test_target_id,
                'item_his': test_i_hist,
                'his_length': test_his_len}
            
        return train, dev, test



# if __name__ == '__main__':
#     logging.basicConfig(level=logging.INFO)
#     parser = argparse.ArgumentParser()
#     parser = BaseReader.parse_data_args(parser)
#     args, extras = parser.parse_known_args()

#     args.path = '../../data/'
#     corpus = BaseReader(args)

#     corpus_path = os.path.join(args.path, args.dataset, 'Corpus.pkl')
#     logging.info('Save corpus to {}'.format(corpus_path))
#     pickle.dump(corpus, open(corpus_path, 'wb'))
