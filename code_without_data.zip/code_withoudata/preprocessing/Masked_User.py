import io
import torch
import numpy
import os.path
import random
from rl_helper import rl_utils
import json

class Masked_User(object):

    def __init__(self, user_vocab=None,
                 character_feature_file=None, action_feature_file=None,
                 character_feature_len=None, action_split_len=None,
                 device='cpu', min_all_information_num=0, dataset='ml-1m', continues_setting=True,
                 open_usr_feature=False
                 ):
        self.user_vocab = user_vocab
        self.dataset = dataset
        self.character_feature_file = character_feature_file
        self.action_feature_file = action_feature_file

        self.character_feature_len = character_feature_len

        self.continues_setting = continues_setting

        self.action_split_len = action_split_len
        self.open_usr_feature = open_usr_feature
        if (self.user_vocab is not None):
            self.user_num = len(self.user_vocab)
        else:
            self.user_num = 0
        self.device = device

        # init

        self.privacy_ori_factor_list = []
        self.max_factor_len = -1
        # 
        self.data = torch.zeros(
            [self.user_num + 1, self.character_feature_len + self.action_split_len]).long()  # strat from 1
        self.mask = torch.ones(
            [self.user_num + 1, self.character_feature_len + self.action_split_len]).long()  # strat from 1
        # information processing
        self.minimal_all_user_num = min_all_information_num
        self.all_data_user_num = None  # all_information_user_num
        self.all_data_user_index = None  # all_information_user_index
        self.policy_user_num = None  # rnd_information_user_num
        self.policy_user_index = None  # rnd_information_user_index

        self.risk_policy_user_index=None
        self.risk_policy_user_num=None
        # user int

        self.character_feature_embedding_dim = []

        # init feature
        if (self.open_usr_feature):
            print('open user feature')
            if os.path.exists(self.character_feature_file):
                self.feature_load()
            else:
                print('feature list is not exist! on ' + self.character_feature_file)

    def feature_load(self):
        if self.dataset == 'ml-1m':

            age_index = [1, 18, 25, 35, 45, 50, 56]
            tmp_list = []
            with open(self.character_feature_file) as f:
                for line in f:
                    u_id, sex, age, f3, f4 = line.strip().split('::')
                    f4 = f4[0:5]
                    if f4 not in tmp_list:
                        tmp_list.append(f4)
            # print(len(tmp_list))
            self.zip_code_hash = tmp_list

            # add for feauture_embedding len
            self.character_feature_embedding_dim.append(1 + 2)
            self.character_feature_embedding_dim.append(1 + len(age_index))
            self.character_feature_embedding_dim.append(1 + 20)
            self.character_feature_embedding_dim.append(1 + len(tmp_list))

            with open(self.character_feature_file) as f:

                for line in f:
                    u_id, sex, age, f3, zip_code = line.strip().split('::')
                    if str(sex) == 'F':
                        f1 = 1
                    elif str(sex) == 'M':
                        f1 = 2
                    else:
                        f1 = 0
                    # f2

                    f2 = age_index.index(int(age)) + 1  # padding 0 for unknown

                    # normalize f4 feature to at most 5 len
                    zip_code = zip_code[0:5]

                    f4 = self.zip_code_hash.index(zip_code) + 1

                    # example:
                    # 661: 1 ->  user 661 in voacb is id=1
                    # make feature
                    if u_id in self.user_vocab:
                        vocab_id = self.user_vocab[u_id]

                        # 1 xx

                        tmp = torch.cat([torch.tensor([int(f1), int(f2), int(f3), int(f4)]).long(),
                                         torch.ones(self.action_split_len).long()], dim=0)

                        self.data[vocab_id] = tmp
                    else:
                        # print(u_id)
                        continue

        if self.dataset == 'ml-100k':

            #print('100k is not prepare yet')


            tmp_list = []
            job_index=[]
            with open(self.character_feature_file) as f:
                for line in f:
                    u_id,age, sex, job, f4 = line.strip().split('|')


                    if job not in job_index:
                        job_index.append(job)

                    f4 = f4[0:5]
                    if f4 not in tmp_list:
                        tmp_list.append(f4)
            # print(len(tmp_list))
            self.zip_code_hash = tmp_list
            self.job_code_hash = job_index

            # add for feauture_embedding len

            self.character_feature_embedding_dim.append(1 + 99)
            self.character_feature_embedding_dim.append(1 + 2)
            self.character_feature_embedding_dim.append(1 + len(job_index))
            self.character_feature_embedding_dim.append(1 + len(tmp_list))

            with open(self.character_feature_file) as f:

                for line in f:
                    u_id, age,sex, job, zip_code = line.strip().split('|')
                    if str(sex) == 'F':
                        f2 = 1
                    elif str(sex) == 'M':
                        f2 = 2
                    else:
                        f2 = 0
                    # f2

                    f1 = int(age)  # padding 0 for unknown

                    # normalize f4 feature to at most 5 len
                    zip_code = zip_code[0:5]

                    f3 = self.job_code_hash.index(job) + 1
                    f4 = self.zip_code_hash.index(zip_code) + 1

                    # example:
                    # 661: 1 ->  user 661 in voacb is id=1
                    # make feature
                    if u_id in self.user_vocab:
                        vocab_id = self.user_vocab[u_id]

                        # 1 xx

                        tmp = torch.cat([torch.tensor([int(f1), int(f2), int(f3), int(f4)]).long(),
                                         torch.ones(self.action_split_len).long()], dim=0)

                        self.data[vocab_id] = tmp
                    else:
                        # print(u_id)
                        continue

        if self.dataset == 'yelp':

            print('begin load user profile')
            with open(self.character_feature_file) as f:
                user_profile = json.load(f)
                tmp=torch.tensor(user_profile)
                self.data=tmp
                print('load success!')

            # with open(self.character_feature_file) as f:
            #     #user_profile = json.load(f)
            #
            #     # max_f1_dim=0
            #     # max_f2_dim=0
            #     # max_f3_dim=0
            #     # max_f4_dim=0
            #
            #
            #
            #     # for lines in f:
            #     #     line = eval(lines)
            #     #     uid = line['user_id']
            #     #
            #     #     f1=int(line['review_count']/100.0) +1#review_count  mod 100
            #     #     f2=int(line['useful']/100.0) +1#useful
            #     #     friends= line['friends'].split(',')
            #     #     f3 = int(len(friends)/100.0) +1 # the minimal is 0 --> add 1 for remaining 0 for unknown
            #     #     f4=int(line['fans']/100.0) +1 #fans
            #
            #     max_f1_dim=175#max(max_f1_dim,int(f1))
            #     max_f2_dim=2063#max(max_f2_dim,int(f2))
            #     max_f3_dim = 150#max(max_f3_dim, int(f3))
            #     max_f4_dim =125# max(max_f4_dim, int(f4))
            #
            #
            #
            #     self.character_feature_embedding_dim.append(1 + max_f1_dim)
            #     self.character_feature_embedding_dim.append(1 + max_f2_dim)
            #     self.character_feature_embedding_dim.append(1 + max_f3_dim)
            #     self.character_feature_embedding_dim.append(1 + max_f4_dim)
            #     cnt=0
            #     for lines in f:
            #         print(cnt)
            #         cnt+=1
            #
            #         line = eval(lines)
            #         u_id = line['user_id']
            #
            #         f1=int(line['review_count']/100.0) +1#review_count  mod 100
            #         f2=int(line['useful']/100.0) +1#useful
            #         friends= line['friends'].split(',')
            #         f3 = int(len(friends)/100.0) +1 # the minimal is 0 --> add 1 for remaining 0 for unknown
            #         f4=int(line['fans']/100.0) +1 #fans
            #
            #         if u_id in self.user_vocab:
            #             vocab_id = self.user_vocab[u_id]
            #
            #             # 1 xx
            #
            #             tmp = torch.cat([torch.tensor([int(f1), int(f2), int(f3), int(f4)]).long(),
            #                              torch.ones(self.action_split_len).long()], dim=0)
            #
            #             self.data[vocab_id] = tmp
            #         else:
            #             print(u_id)
            #             continue
            #
            #     with open('/mnt1/eric.czq/privacy_clean/src/data/yelp/yelp_user_feature_eric.json', 'w') as f:
            #         import copy,numpy as np
            #         save_result0 =copy.deepcopy(self.data)
            #         save_result=np.array(save_result0).tolist()
            #
            #         json.dump(save_result, f, indent=4)
            #         print('save tmp success!')

    ## set parameter

    def set_privacy_ori_factor_list(self, privacy_ori_factor_list=[], max_len=-2):
        self.privacy_ori_factor_list = privacy_ori_factor_list
        self.max_factor_len = max_len

    def set_policy_user_action_except_profile(self, uid, action):

        if self.continues_setting == True:
            new_mask = torch.Tensor(
                rl_utils.int_to_binary_list_continues(action_split_len=self.action_split_len, action=action))
        else:
            new_mask = torch.Tensor(rl_utils.int_to_binary_list(action_split_len=self.action_split_len, action=action))

        self.mask[uid][self.character_feature_len:self.character_feature_len + self.action_split_len] = new_mask

        return

    def set_policy_user_action_with_profile(self, uid, action,profile_combined=False):


        ## suppose the first four line is set to profile attribute

        # get attribute action:
        if profile_combined==True:
            #history_action = action % 2
            #attribute_action_coded = int(action / 2)

            history_action = int(action / 2)
            attribute_action_coded = action % 2

            if attribute_action_coded == 1:
                attribute_action= (2 ** self.character_feature_len)-1
            else:
                attribute_action = 0

        else:
            history_action = int(action / (2 ** self.character_feature_len))
            attribute_action = action % (2 ** self.character_feature_len)

        #print('action is ' + str(action) + ' | history action is ' + str(history_action) + '| profile action is ' + str(attribute_action))

        # set history data mask
        if self.continues_setting == True:
            new_mask = torch.Tensor(
                rl_utils.int_to_binary_list_continues(action_split_len=self.action_split_len, action=history_action))
        else:
            new_mask = torch.Tensor(rl_utils.int_to_binary_list(action_split_len=self.action_split_len, action=history_action))

        self.mask[uid][self.character_feature_len:self.character_feature_len + self.action_split_len] = new_mask

        # set attribute data mask
        #print(bin(attribute_action))
        new_mask_attribute = torch.Tensor(rl_utils.int_to_binary_list(action_split_len=self.character_feature_len, action=attribute_action))

        #print(new_mask_attribute)
        #print('----')

        self.mask[uid][:self.character_feature_len] = new_mask_attribute
        return


    ## initial

    def initial_random_user_list(self, specific_num=None,risk_policy_user_num=0):

        if specific_num is None:

            self.all_data_user_num = random.randint(max(1, self.minimal_all_user_num),
                                                    self.user_num)  # assign all information
            self.policy_user_num = self.user_num - self.all_data_user_num
        else:

            self.policy_user_num = min(self.user_num, specific_num)
            self.all_data_user_num = self.user_num - self.policy_user_num
        #

        # sample
        self.policy_user_index = random.sample([i + 1 for i in range(self.user_num)],
                                                 self.policy_user_num)
        self.all_data_user_index=[]
        for i in range(self.user_num):
            if i + 1 not in self.policy_user_index:
                self.all_data_user_index.append((i + 1))  # start from [1,N]

        self.risk_policy_user_index = self.policy_user_index[:risk_policy_user_num]
        self.risk_policy_user_num=risk_policy_user_num

        return



    # reset user action with random
    def reset_random_policy_user_action(self):
        for uid in self.policy_user_index:
            self.mask[uid] = torch.randint(0, 2, size=self.mask[uid].size()).to(device=self.device)
        return

    def reset_zero_policy_user_action(self):
        for uid in self.policy_user_index:
            self.mask[uid] = torch.zeros(self.mask[uid].size()).to(device=self.device)
        return
    def reset_zero_risk_policy_user_action(self):
        for uid in self.risk_policy_user_index:
            self.mask[uid] = torch.zeros(self.mask[uid].size()).to(device=self.device)
        return

    def reset_full_policy_user_action(self):
        for uid in self.policy_user_index:
            self.mask[uid] = torch.ones(self.mask[uid].size()).to(device=self.device)
        return

    def reset_full_risky_policy_user_action(self):
        for uid in self.risk_policy_user_index:
            self.mask[uid] = torch.ones(self.mask[uid].size()).to(device=self.device)
        return

    ## get parameter
    def get_policy_user_index_list(self):
        return self.policy_user_index

    def get_risk_policy_user_index_list(self):
        return self.risk_policy_user_index

    def get_action_split_len(self):
        return self.action_split_len

        # get action mask three different types
    def get_policy_user_action(self):
        # return the mask with policy_user_num * action space

        tmp = torch.ones([self.policy_user_num, self.character_feature_len + self.action_split_len]).long()
        for cnt, uid in enumerate(self.policy_user_index):
            tmp[cnt] = self.mask[uid]
        return tmp

    def get_policy_user_action_except_profile(self):
        tmp = torch.ones([self.policy_user_num, self.action_split_len]).long()
        for cnt, uid in enumerate(self.policy_user_index):
            tmp[cnt] = self.mask[uid][self.character_feature_len:self.character_feature_len + self.action_split_len]
        return tmp

    def get_policy_user_action_only_profile(self):

        tmp = torch.ones([self.policy_user_num, self.character_feature_len]).long()
        for cnt, uid in enumerate(self.policy_user_index):
            tmp[cnt] = self.mask[uid][:self.character_feature_len]
        return tmp

    def get_rnd_mask_encoded_list(self):
            encodered_list = []

            encoder = torch.tensor([1 << i for i in range(self.character_feature_len + self.action_split_len)]).long()

            for uid in self.policy_user_index:
                encoder_number = int(torch.sum(self.mask[uid].data.cpu() * encoder).data.cpu())
                encodered_list.append(encoder_number)

            return encodered_list
        # end get action mask
    def get_policy_user_num(self):
        return self.policy_user_num

    def get_risk_policy_user_num(self):
        return self.risk_policy_user_num

    def get_all_user_action(self):
        # return the mask with all user

        return self.mask

    ## print method
    def print_policy_user_action(self, print_num=-1):

        if (print_num == -1):
            print_num = self.policy_user_num

        for i in range(print_num):
            print('user id is ' + str(self.policy_user_index[i]) + ' and his privacy choice is ' + str(
                self.mask[self.policy_user_index[i]].data.cpu()))

    ##

    def action_split(self, cutoff=3, new_file_id=0):  # generate new csv

        if (self.action_split_len == 0):
            print('no action split permission! as action split feature is 0')
            return

        # read train.csv -> split the training uid

        # T.B.Added  for the reading training set
        read_training_set = []

        #
        if self.action_split_len == 1:  # only turn on and off -> cut off specific number

            print(0)


        elif self.action_split_len > 1:
            print(0)

        return

###
