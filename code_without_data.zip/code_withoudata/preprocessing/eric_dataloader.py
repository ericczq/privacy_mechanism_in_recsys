import numpy
import torch
import json
import os.path
from .Masked_User import Masked_User

def mkdataset(dataset='ml-1m', dataset_path='/Users/eric.czq/Downloads/CP4Rec-dev/data/',device='cpu',
              character_feature_len=4,action_split_len=1,continues_setting = False,open_usr_feature=False,
              min_all_information_num=1000):
    dataset_name = dataset
    dataset_path = os.path.join(dataset_path, str(dataset_name)+'/')

    if (dataset_name == 'ml-1m'):
        json_file = dataset_path + str(dataset_name) + '_vocab.json'

        if os.path.exists(json_file):
            with open(json_file, 'r') as f:
                read_vocab = json.load(f)
        else:
            print(json_file + ' is not exist!')
            read_vocab = None
            return
        user_vocab = read_vocab['user_vocab']
        item_vocab = read_vocab['item_vocab']

        character_feature_len =4

        masked_User = Masked_User(
            user_vocab=user_vocab,dataset=dataset,
            character_feature_file=dataset_path + 'users.dat',
            action_feature_file=None,
            character_feature_len=character_feature_len, action_split_len=action_split_len,
            device=device,min_all_information_num=min_all_information_num,continues_setting =continues_setting
        )
        #masked_User.set_random_user()
        #masked_User.set_random_mask()

        #mask = masked_User.get_mask()
        #mask_list = masked_User.get_mask_encoded_list()
        # print random_init test
        # masked_User.print_random_mask()


    #print(masked_User.data)
    #print('end')

    if (dataset_name == 'ml-100k'):

        json_file = dataset_path + str(dataset_name) + '_vocab.json'
        print(json_file)

        if os.path.exists(json_file):
            with open(json_file, 'r') as f:
                read_vocab = json.load(f)
        else:
            print(json_file + ' is not exist!')
            read_vocab = None
            return
        user_vocab = read_vocab['user_vocab']
        item_vocab = read_vocab['item_vocab']

        character_feature_len =4

        print('begin build')

        masked_User = Masked_User(
            user_vocab=user_vocab,dataset=dataset,
            character_feature_file=dataset_path + 'u.user',
            action_feature_file=None,open_usr_feature=open_usr_feature,
            character_feature_len=character_feature_len, action_split_len=action_split_len,
            device=device,min_all_information_num=min_all_information_num,continues_setting =continues_setting
        )
        #masked_User.set_random_user()
        #masked_User.set_random_mask()

        #mask = masked_User.get_mask()
        #mask_list = masked_User.get_mask_encoded_list()
        # print random_init test
        # masked_User.print_random_mask()

    if (dataset_name == 'yelp'):

        json_file = dataset_path + str(dataset_name) + '_vocab.json'
        print(json_file)

        if os.path.exists(json_file):
            with open(json_file, 'r') as f:
                read_vocab = json.load(f)
        else:
            print(json_file + ' is not exist!')
            read_vocab = None
            return
        user_vocab = read_vocab['user_vocab']
        item_vocab = read_vocab['item_vocab']

        character_feature_len =4

        print('begin build')

        masked_User = Masked_User(
            user_vocab=user_vocab,dataset=dataset,
            character_feature_file=dataset_path + 'yelp_user_feature_eric.json',
            action_feature_file=None,open_usr_feature=open_usr_feature,
            character_feature_len=character_feature_len, action_split_len=action_split_len,
            device=device,min_all_information_num=min_all_information_num,continues_setting =continues_setting
        )
        #masked_User.set_random_user()
        #masked_User.set_random_mask()

        #mask = masked_User.get_mask()
        #mask_list = masked_User.get_mask_encoded_list()
        # print random_init test
        # masked_User.print_random_mask()

    print('end')
    return masked_User


#device = 'cuda' if torch.cuda.is_available() else 'cpu'
#mask_user = mkdataset(device=device,min_all_information_num=4000)
