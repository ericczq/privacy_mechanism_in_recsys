# -*- coding: UTF-8 -*-

import os
import sys
import pickle
import logging
import argparse
import numpy as np
import torch
import warnings
import random
from torch.utils.data import DataLoader
import tqdm


 
from models import *
from helpers import *
from utils import utils


def parse_global_args(parser):
    parser.add_argument('--gpu', type=str, default='0',
                        help='Set CUDA_VISIBLE_DEVICES')
    parser.add_argument('--verbose', type=int, default=logging.INFO,
                        help='Logging Level, 0, 10, ..., 50')
    parser.add_argument('--log_file', type=str, default='',
                        help='Logging file path')
    parser.add_argument('--random_seed', type=int, default=2019,
                        help='Random seed of numpy and pytorch.')
    parser.add_argument('--load', type=int, default=0,
                        help='Whether load model and continue to train')
    parser.add_argument('--i_emb_path', type=str, default='',
                        help='The path of pre-trained item embedding file')
    parser.add_argument('--train', type=int, default=1,
                        help='To train the model or not.')
    parser.add_argument('--regenerate', type=int, default=0,
                        help='Whether to regenerate intermediate files.')
    parser.add_argument('--eval_on_sampling', type=int, default=0,
                        help='Eval on random negative samplings or the whole candidate sets.')
    parser.add_argument('--num_layers', type=int, default=2,
                            help='Number of self-attention layers.')
    parser.add_argument('--num_heads', type=int, default=2,
                            help='Number of self-attention heads.')
    parser.add_argument('--inner_times', type=int, default=2,
                            help='times of embedding size.')
    parser.add_argument('--final_print', type=int, default=0,
                            help='whether eval and test at each epoch.')
    parser.add_argument('--version', type=str, default='1',
                            help='to tackle the problem of log that can only run a model a time')
    parser.add_argument('--compo', type=int, default=0,
                            help='to tackle the problem of log that can only run a model a time')
    parser.add_argument('--singleaug', type=int, default=0,
                            help='to tackle the problem of log that can only run a model a time')
    parser.add_argument('--analy', type=int, default=1,
                            help='to tackle the problem of log that can only run a model a time')
    return parser
def predict_evaluate(model, dataa, phase, eval_on_sampling):
        """
        The returned prediction is a 2D-array, each row corresponds to all the candidates,
        and the ground-truth item poses the first.
        Example: ground-truth items: [1, 2], 2 negative items for each instance: [[3,4], [5,6]]
                 predictions order: [[1,3,4], [2,5,6]]
        """
        model.eval()
        total_num = 0.0
        eval_results = dict()
        flag = 0
        final_user, final_emb = None, None
        #predictions = list()
        dl = DataLoader(dataa, batch_size=256, shuffle=False, num_workers=5,
                        collate_fn=dataa.collate_batch, pin_memory=1)
        # for batch in tqdm(dl, leave=False, ncols=100, mininterval=1, desc='Predict'):
        for i, batch in enumerate(dl, 0):
            embs = model(utils.batch_to_gpu(batch), phase, eval_on_sampling).cpu().data.numpy()

            batch_user = batch["user_id"].cpu().data.numpy()
            
            if flag == 0:
                final_user, final_emb = batch_user, embs
                flag += 1
            else:
                final_user = np.concatenate((final_user, batch_user), axis=0)
                final_emb = np.concatenate((final_emb, embs), axis=0)
        user_path = "../data/yelp_cl_user.pkl"
        emb_path = "../data/yelp_cl_emb.pkl"
        with open(user_path, "wb") as fd:
            pickle.dump(final_user, fd)
        with open(emb_path, "wb") as fd:
            pickle.dump(final_emb, fd)

        

        return None

def main():
    logging.info('-' * 45 + ' BEGIN: ' + utils.get_time() + ' ' + '-' * 45)
    exclude = ['check_epoch', 'log_file', 'model_path', 'path', 'pin_memory',
               'regenerate', 'sep', 'train', 'verbose']
    logging.info(utils.format_arg_str(args, exclude_lst=exclude))

    # Random seed
    random.seed(args.random_seed)
    np.random.seed(args.random_seed)
    torch.manual_seed(args.random_seed)
    torch.cuda.manual_seed(args.random_seed)

    # GPU
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu
    logging.info("# cuda devices: {}".format(torch.cuda.device_count()))

    # Read data
    corpus_path = os.path.join(args.path, args.dataset, model_name.reader + '.pkl')
    if not args.regenerate and os.path.exists(corpus_path):
        logging.info('Load corpus from {}'.format(corpus_path))
        corpus = pickle.load(open(corpus_path, 'rb'))
    else:
        corpus = reader_name(args)
        logging.info('Save corpus to {}'.format(corpus_path))
        pickle.dump(corpus, open(corpus_path, 'wb'))

    # Define model
    model = model_name(args, corpus)
    logging.info(model)
    model = model.double()
    model.apply(model.init_weights)
    model.actions_before_train()
    if torch.cuda.device_count() > 0:
        model = model.cuda()
    model.load_model()

    # Run model
    data_dict = dict()
    data_dict["test"] = model_name.Dataset(model, corpus, "test", args.eval_on_sampling, args.aug, args.mask_pro)
    predict_evaluate(model, data_dict["test"], "test", args.eval_on_sampling)        


if __name__ == '__main__':
    
    #warnings.filterwarnings('ignore')
    warnings.filterwarnings("ignore", category=Warning)

    init_parser = argparse.ArgumentParser(description='Model')
    init_parser.add_argument('--model_name', type=str, default='BPR', help='Choose a model to run.')
    init_args, init_extras = init_parser.parse_known_args()
    model_name = eval('{0}.{0}'.format(init_args.model_name))
    reader_name = eval('{0}.{0}'.format(model_name.reader))
    runner_name = eval('{0}.{0}'.format(model_name.runner))

    # Args
    parser = argparse.ArgumentParser(description='')
    parser = parse_global_args(parser)
    parser = reader_name.parse_data_args(parser)
    parser = runner_name.parse_runner_args(parser)
    parser = model_name.parse_model_args(parser)
    args, extras = parser.parse_known_args()

    # Logging configuration
    log_args = [args.version, init_args.model_name, args.dataset, str(args.random_seed)]
    #for arg in ['loss', 'num_neg', 'eval_on_sampling', 'dropout', 'lr', 'l2', 'history_max', 'num_heads', 'inner_times', 'num_layers'] + model_name.extra_log_args:
    for arg in ['num_neg', 'eval_on_sampling', 'dropout', 'lr', 'l2', 'history_max', 'num_heads', 'inner_times', 'num_layers'] + model_name.extra_log_args:
        log_args.append(arg + '=' + str(eval('args.' + arg)))
    if model_name.runner == "MultiTaskRunner":
        for arg in ['aug', 'mask_pro', 'lambda1', 'temperature']:
            log_args.append(arg + '=' + str(eval('args.' + arg)))
    else:
        pass
    log_file_name = '__'.join(log_args).replace(' ', '__')
    if args.i_emb_path != '':
        log_file_name += '__finetune=' + args.i_emb_path[args.i_emb_path.rfind('/')+1:args.i_emb_path.find('__')]
    if args.log_file == '':
        args.log_file = '../log/{}/{}.txt'.format(init_args.model_name, "analy_yelp_cl")
    if args.model_path == '':
        args.model_path = '../model/{}/{}.pt'.format(init_args.model_name, log_file_name)
    args.model_path = "../model/CL_results/fmask__CL_results__Yelp2019__2019__num_neg=16__eval_on_sampling=0__dropout=0.5__lr=0.001__l2=0.0__history_max=50__num_heads=2__inner_times=2__num_layers=2__aug=mask_merge__mask_pro=0.5__lambda1=0.1__temperature=1.0.pt"


    utils.check_dir(args.log_file)
    logging.basicConfig(filename=args.log_file, level=args.verbose)
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(init_args)

    main()
