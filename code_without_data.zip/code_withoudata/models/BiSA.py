# -*- coding: UTF-8 -*-

import os
import torch
import torch.nn as nn
import logging
import numpy as np

from models.GRU4Rec import GRU4Rec
from utils import components
from utils import utils


class BiSA(GRU4Rec):
    """docstring for BiSA."""

    extra_log_args = ['num_layers', 'num_heads']
    @staticmethod
    def parse_model_args(parser):
        parser.add_argument('--num_layers', type=int, default=2,
                            help='Number of self-attention layers.')
        parser.add_argument('--num_heads', type=int, default=4,
                            help='Number of self-attention heads.')
        parser.add_argument('--inner_times', type=int, default=2,
                            help='times of embedding size.')
        parser.add_argument('--bi', type=int, default=1,
                            help='bidirectional attention or not.')
        return GRU4Rec.parse_model_args(parser)

    def __init__(self, args, corpus,user_feature_dim=[], user_feature_train=True):
        self.max_his     = args.history_max
        self.num_layers  = args.num_layers
        self.len_range   = utils.numpy_to_torch(np.arange(self.max_his))
        self.num_heads   = args.num_heads
        self.inner_times = args.inner_times
        self.bi          = args.bi

        if user_feature_train:
            self.user_feature_dim = user_feature_dim

        self.user_feature_train = user_feature_train

        super().__init__(args, corpus,user_feature_dim=user_feature_dim, user_feature_train=user_feature_train)
    
    def _define_params(self):
        self.i_embeddings = torch.nn.Embedding(self.item_num, self.emb_size)
        self.p_embeddings = torch.nn.Embedding(self.max_his + 1, self.emb_size)

        inner_size = self.inner_times * self.emb_size
        logging.info('inner_size is ' + str(inner_size))
        head_emb_size = int(self.emb_size / self.num_heads)
        logging.info('head_emb_size is ' + str(head_emb_size))

        el = nn.TransformerEncoderLayer(d_model=self.emb_size, 
                                        nhead=self.num_heads, 
                                        dim_feedforward=inner_size, 
                                        dropout=self.dropout,
                                        batch_first=True)
        ln = nn.LayerNorm(self.emb_size)
        self.encoder = nn.TransformerEncoder(el, num_layers=self.num_layers, norm=ln)

        if self.user_feature_train:

            self.u_embeddings_1 = torch.nn.Embedding(self.user_feature_dim[0], int(self.emb_size/4))
            self.u_embeddings_2 = torch.nn.Embedding(self.user_feature_dim[1], int(self.emb_size/4))
            self.u_embeddings_3 = torch.nn.Embedding(self.user_feature_dim[2], int(self.emb_size/4))
            self.u_embeddings_4 = torch.nn.Embedding(self.user_feature_dim[3], int(self.emb_size/4))

    def load_pretrained_i_emb(self, i_emb_path):
        if os.path.exists(i_emb_path):
            pre_i_embeddings = torch.load(i_emb_path)
            assert pre_i_embeddings.shape == self.i_embeddings.weight.shape, \
            "pre-trained embedding's shape != item embedding's shape"
            self.i_embeddings = self.i_embeddings.from_pretrained(pre_i_embeddings, freeze=False)
            logging.info('Load pre-trained item embeddings from ' + i_emb_path)
        else:
            raise ValueError("The path for pre-trained item embedding is wrong!")

    def forward(self, feed_dict, phase, eval_on_sampling):
        self.check_list = []
        i_ids   = feed_dict['item_id']     # [batch_size, -1]
        history = feed_dict['item_his']    # [batch_size, history_max]
        lengths = feed_dict['lengths']     # [batch_size]
        batch_size, seq_len = history.shape

        valid_his = (history > 0).byte()
        i_vectors = self.i_embeddings(i_ids)
        his_vectors = self.i_embeddings(history)

        # if phase != 'train':
        #     print('---?---')
        #     print(his_vectors)
        #     print('-.-')
        #     print(valid_his)
        # Position embedding
        # lengths:  [4, 2, 5]
        # position: [[4, 3, 2, 1, 0], [2, 1, 0, 0, 0], [5, 4, 3, 2, 1]]
        position = self.len_range[:seq_len].unsqueeze(0).repeat(batch_size, 1)
        position = (lengths[:, None] - position) * valid_his.long()
        pos_vectors = self.p_embeddings(position)
        his_vectors += pos_vectors

        # Self-attention
        key_pad_mask = (1 - valid_his).bool()
        if phase != 'train':
            # print('old mask is ')
            #set the first be history
            key_pad_mask[:,0]=False

        if self.bi == 1:
            his_vectors = self.encoder(his_vectors, src_key_padding_mask=key_pad_mask)
        else:
            src_mask = (torch.triu(torch.ones(seq_len, seq_len)) == 1).transpose(0, 1).cuda()
            src_mask = src_mask.float().masked_fill(src_mask == 0, float('-inf')).masked_fill(src_mask == 1, float(0.0))
            his_vectors = self.encoder(his_vectors, mask=src_mask, src_key_padding_mask=key_pad_mask)

        last_position = (lengths - 1).unsqueeze(1)

        # if phase != 'train':
        #     print('key_pad_mask ?????')
        #     print(key_pad_mask)
        #     print('??????')
        #     print()

        #print(his_vectors)
        ##
        aux_idx = [torch.LongTensor(range(lengths.shape[0])).unsqueeze(1), last_position]
        # his_vectors = his_vectors * valid_his[:, :, None].double()
        # his_vector = (his_vectors * (position == 1).double()[:, :, None]).sum(1)
        #his_vector = his_vectors.sum(1) / lengths[:, None].double()
        # ↑ average pooling is shown to be more effective than the most recent embedding
        his_vector = his_vectors[aux_idx].squeeze()

        if (len(his_vector.shape) == 1):
            his_vector = his_vector.reshape([1, his_vector.shape[0]])

        if (self.user_feature_train):
            user_feature = feed_dict['user_feature']
            u1_vectors = self.u_embeddings_1(user_feature[:, 0])  # output : [batchsize  ]
            u2_vectors = self.u_embeddings_2(user_feature[:, 1])
            u3_vectors = self.u_embeddings_3(user_feature[:, 2])
            u4_vectors = self.u_embeddings_4(user_feature[:, 3])

            u_vectors = torch.cat((u1_vectors, u2_vectors, u3_vectors, u4_vectors), dim=1)
            mask = (user_feature > 0).repeat(1, int(self.emb_size / 4))
            u_vectors = u_vectors * mask

            normalize_u = torch.nn.functional.normalize(u_vectors, p=2, dim=1) / 4.0

            # only  sum
            his_vector = his_vector + normalize_u#(u1_vectors + u2_vectors + u3_vectors + u4_vectors)/4.0

        #print(his_vector)

        if phase != 'train' and not eval_on_sampling:
            # todo: target score, neg mask
            negs = torch.arange(1, self.item_num).cuda()
            neg_mask = ~negs.eq(i_ids)
            neg_pred = torch.matmul(his_vector, self.i_embeddings(negs).t())
            target_pred = (his_vector[:, None, :] * i_vectors).sum(-1)

            # print('target pred?????')
            # print(target_pred)
            # print('??????')
            neg_pred = torch.where(neg_mask, neg_pred, torch.ones_like(neg_pred)* (-2 ** 32 + 1))
            prediction = torch.cat([target_pred, neg_pred], -1)

            # print('predict?????!!!')
            # print(prediction)
        else:
            #import pickle

            #file = open('tmp_bisa_his_vector.pkl', 'wb')
            #pickle.dump(his_vector, file)
            #file.close()

            #file = open('tmp_bisa_i_vectors.pkl', 'wb')
            #pickle.dump(i_vectors, file)
            #file.close()
            # print('---')
            # print(his_vector)
            # print(his_vector.shape)
            # print(i_vectors.shape)
            # print('-ed-')


            prediction = (his_vector[:, None, :] * i_vectors).sum(-1)

        return prediction.view(batch_size, -1)
