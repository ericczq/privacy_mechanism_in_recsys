# -*- coding: UTF-8 -*-

import os
import torch
import logging
import numpy as np

from models.GRU4Rec import GRU4Rec
from utils import components
from utils import utils


class SASRec(GRU4Rec):
    @staticmethod
    def parse_model_args(parser):
        parser.add_argument('--num_layers', type=int, default=2,
                            help='Number of self-attention layers.')
        parser.add_argument('--num_heads', type=int, default=4,
                            help='Number of self-attention heads.')
        parser.add_argument('--inner_times', type=int, default=2,
                            help='times of embedding size.')
        return GRU4Rec.parse_model_args(parser)

    def __init__(self, args, corpus):
        self.max_his = args.history_max
        self.num_layers = args.num_layers
        self.len_range = utils.numpy_to_torch(np.arange(self.max_his))
        super().__init__(args, corpus)

    def _define_params(self):
        self.i_embeddings = torch.nn.Embedding(self.item_num, self.emb_size)
        self.p_embeddings = torch.nn.Embedding(self.max_his + 1, self.emb_size)

        self.Q = torch.nn.Linear(self.emb_size, self.emb_size, bias=False)
        self.K = torch.nn.Linear(self.emb_size, self.emb_size, bias=False)
        self.V = torch.nn.Linear(self.emb_size, self.emb_size, bias=False)
        self.W1 = torch.nn.Linear(self.emb_size, self.emb_size)
        self.W2 = torch.nn.Linear(self.emb_size, self.emb_size)

        self.dropout_layer = torch.nn.Dropout(p=self.dropout)
        self.layer_norm = torch.nn.LayerNorm(self.emb_size)
    
    def load_pretrained_i_emb(self, i_emb_path):
        if os.path.exists(i_emb_path):
            pre_i_embeddings = torch.load(i_emb_path)
            assert pre_i_embeddings.shape == self.i_embeddings.weight.shape, \
            "pre-trained embedding's shape != item embedding's shape"
            self.i_embeddings = self.i_embeddings.from_pretrained(pre_i_embeddings, freeze=False)
            logging.info('Load pre-trained item embeddings from ' + i_emb_path)
        else:
            raise ValueError("The path for pre-trained item embedding is wrong!")

    def forward(self, feed_dict, phase, eval_on_sampling):
        self.check_list = []
        i_ids = feed_dict['item_id']          # [batch_size, -1]
        history = feed_dict['item_his']  # [batch_size, history_max]
        lengths = feed_dict['lengths']        # [batch_size]
        batch_size, seq_len = history.shape

        valid_his = (history > 0).byte()
        i_vectors = self.i_embeddings(i_ids)
        his_vectors = self.i_embeddings(history)

        # Position embedding
        # lengths:  [4, 2, 5]
        # position: [[4, 3, 2, 1, 0], [2, 1, 0, 0, 0], [5, 4, 3, 2, 1]]
        position = self.len_range[:seq_len].unsqueeze(0).repeat(batch_size, 1)
        position = (lengths[:, None] - position) * valid_his.long()
        pos_vectors = self.p_embeddings(position)
        his_vectors = his_vectors + pos_vectors

        # Self-attention
        attn_mask = (1 - valid_his.unsqueeze(1).repeat(1, seq_len, 1)).bool()
        for i in range(self.num_layers):
            residual = his_vectors
            # self-attention
            query, key, value = self.Q(his_vectors), self.K(his_vectors), self.V(his_vectors)
            scale = self.emb_size ** -0.5
            his_vectors = components.scaled_dot_product_attention(
                query, key, value, scale=scale, attn_mask=attn_mask)
            # mlp forward
            his_vectors = self.W1(his_vectors).relu()
            his_vectors = self.W2(his_vectors)  # [batch_size, history_max, emb_size]
            # dropout, residual and layer_norm
            his_vectors = self.dropout_layer(his_vectors)
            his_vectors = self.layer_norm(residual + his_vectors)
            # ↑ layer norm in the end is shown to be more effective

        his_vectors = his_vectors * valid_his[:, :, None].double()

        # his_vector = (his_vectors * (position == 1).double()[:, :, None]).sum(1)
        his_vector = his_vectors.sum(1) / lengths[:, None].double()
        # ↑ average pooling is shown to be more effective than the most recent embedding
        if phase != 'train' and not eval_on_sampling:
            # todo: target score, neg mask
            negs = torch.arange(1, self.item_num).cuda()
            neg_mask = ~negs.eq(i_ids)
            neg_pred = torch.matmul(his_vector, self.i_embeddings(negs).t())
            target_pred = (his_vector[:, None, :] * i_vectors).sum(-1)
            neg_pred = torch.where(neg_mask, neg_pred, torch.ones_like(neg_pred)* (-2 ** 32 + 1))
            prediction = torch.cat([target_pred, neg_pred], -1)
        else:
            prediction = (his_vector[:, None, :] * i_vectors).sum(-1)

        return prediction.view(batch_size, -1)
