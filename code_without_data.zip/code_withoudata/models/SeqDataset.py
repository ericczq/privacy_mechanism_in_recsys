# -*- coding: UTF-8 -*-

import os
import time
import pickle
import logging
from collections import defaultdict
import numpy as np
import torch
from torch.utils.data import Dataset as BaseDataset
from torch.nn.utils.rnn import pad_sequence

from utils import utils

from models.CFDataset import CFDataset

class SeqDataset(CFDataset):
    def __init__(self, corpus, args):
        super().__init__(corpus, args)

        self._prepare()

    def _prepare(self):
            idx_select = np.array(self.data['his_length']) > 0  # history length must be non-zero
            for key in self.data:
                if key == 'item_his' or key =='user_feature':
                    self.data[key] = np.array(self.data[key], dtype=np.object)[idx_select]
                    # tmp = self.data[key]
                    # print(1)

                elif key =='user_feature':
                    self.data[key] = np.array(self.data[key].numpy(), dtype=np.object)[idx_select]
                    print('load user feature')
                #     #continue
                # #
                #  #   # to be updated for efficiency
                #     tmp2 = np.array(self.data[key], dtype=np.object)[idx_select]
                #     tmp = self.data[key]
                #     new_feature_list=[]
                #     for tmp_id, item in enumerate(tmp):
                #         if(idx_select[tmp_id]):
                #
                #             new_feature_list.append(item)
                #
                #
                #     self.data[key] =np.array(new_feature_list)
                    #print(0)
                else:
                    self.data[key] = np.array(self.data[key])[idx_select]




    def _get_feed_dict(self, index):
        feed_dict = super()._get_feed_dict(index)
        feed_dict['user_id'] = self.data['user_id'][index]
        feed_dict['item_his'] = np.array(self.data['item_his'][index])
        feed_dict['lengths'] = self.data['his_length'][index]

        feed_dict['user_feature'] = self.data['user_feature'][index].numpy()

        return feed_dict
