# -*- coding: UTF-8 -*-

import os
import torch
import logging
import numpy as np

from models.BaseModel import BaseModel


class GRU4Rec(BaseModel):
    @staticmethod
    def parse_model_args(parser):
        parser.add_argument('--emb_size', type=int, default=64,
                            help='Size of embedding vectors.')
        parser.add_argument('--hidden_size', type=int, default=100,
                            help='Size of hidden vectors in GRU.')
        return BaseModel.parse_model_args(parser)

    def __init__(self, args, corpus):
        self.user_num = corpus.n_users
        self.emb_size = args.emb_size
        self.hidden_size = args.hidden_size
        super().__init__(args, corpus)

    def _define_params(self):
        self.i_embeddings = torch.nn.Embedding(self.item_num, self.emb_size)
        self.rnn = torch.nn.GRU(input_size=self.emb_size, hidden_size=self.hidden_size, batch_first=True)
        self.out = torch.nn.Linear(self.hidden_size, self.emb_size, bias=False)
        
    def load_pretrained_i_emb(self, i_emb_path):
        if os.path.exists(i_emb_path):
            pre_i_embeddings = torch.load(i_emb_path)
            assert pre_i_embeddings.shape == self.i_embeddings.weight.shape, \
            "pre-trained embedding's shape != item embedding's shape"
            self.i_embeddings = self.i_embeddings.from_pretrained(pre_i_embeddings, freeze=False)
            logging.info('Load pre-trained item embeddings from ' + i_emb_path)
        else:
            raise ValueError("The path for pre-trained item embedding is wrong!")

    def forward(self, feed_dict, phase, eval_on_sampling):
        self.check_list = []
        i_ids = feed_dict['item_id']          # [batch_size, -1]
        history = feed_dict['item_his']  # [batch_size, history_max]
        lengths = feed_dict['lengths']        # [batch_size]

        i_vectors = self.i_embeddings(i_ids)
        his_vectors = self.i_embeddings(history)

        # Sort and Pack
        sort_his_lengths, sort_idx = torch.topk(lengths, k=len(lengths))
        sort_his_vectors = his_vectors.index_select(dim=0, index=sort_idx)
        history_packed = torch.nn.utils.rnn.pack_padded_sequence(sort_his_vectors, sort_his_lengths.cpu(), batch_first=True)

        # RNN
        output, hidden = self.rnn(history_packed, None)

        # Unsort
        sort_rnn_vector = self.out(hidden[-1])
        unsort_idx = torch.topk(sort_idx, k=len(lengths), largest=False)[1]
        rnn_vector = sort_rnn_vector.index_select(dim=0, index=unsort_idx)

        # Predicts
        if phase != 'train' and not eval_on_sampling:
            # todo: target score, neg mask
            negs = torch.arange(1, self.item_num).cuda()
            neg_mask = ~negs.eq(i_ids)
            neg_pred = torch.matmul(rnn_vector, self.i_embeddings(negs).t())
            target_pred = (rnn_vector[:, None, :] * i_vectors).sum(-1)
            neg_pred = torch.where(neg_mask, neg_pred, torch.ones_like(neg_pred)* (-2 ** 32 + 1))
            prediction = torch.cat([target_pred, neg_pred], -1)
        else:
            prediction = (rnn_vector[:, None, :] * i_vectors).sum(-1)
            
        return prediction.view(feed_dict['batch_size'], -1)

    # class Dataset(BaseModel.Dataset):
    #     def _prepare(self):
    #         idx_select = np.array(self.data['his_length']) > 0  # history length must be non-zero
    #         for key in self.data:
    #             self.data[key] = np.array(self.data[key])[idx_select]
    #         super()._prepare()

    #     def _get_feed_dict(self, index):
    #         feed_dict = super()._get_feed_dict(index)
    #         feed_dict['user_id'] = self.data['user_id'][index]
    #         feed_dict['history_items'] = np.array(self.data['item_his'][index])
    #         feed_dict['lengths'] = self.data['his_length'][index]
    #         return feed_dict
