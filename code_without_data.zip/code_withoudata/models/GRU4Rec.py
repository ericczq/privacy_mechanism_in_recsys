# -*- coding: UTF-8 -*-

import os
import torch
import logging
import numpy as np

from models.BaseModel import BaseModel


class GRU4Rec(BaseModel):
    @staticmethod
    def parse_model_args(parser):
        parser.add_argument('--emb_size', type=int, default=64,
                            help='Size of embedding vectors.')
        parser.add_argument('--hidden_size', type=int, default=100,
                            help='Size of hidden vectors in GRU.')
        return BaseModel.parse_model_args(parser)

    def __init__(self, args, corpus, user_feature_dim=[], user_feature_train=False):
        self.user_num = corpus.n_users
        self.emb_size = args.emb_size
        self.hidden_size = args.hidden_size

        if user_feature_train:
            self.user_feature_dim = user_feature_dim

        self.user_feature_train = user_feature_train

        #print('no implement yet on user_feature_train')

        super().__init__(args, corpus)

    def _define_params(self):
        self.i_embeddings = torch.nn.Embedding(self.item_num, self.emb_size)

        # # to be updated for adaptive
        print('in the define processing')
        if self.user_feature_train:
        #     self.u_embeddings_list=[]
        #     for i in range(len(self.user_feature_dim)):
        #         u_embeddings=torch.nn.Embedding(self.user_feature_dim[i], self.emb_size)
        #         self.u_embeddings_list.append(u_embeddings)

            self.u_embeddings_1 = torch.nn.Embedding(self.user_feature_dim[0], int(self.emb_size/4))
            self.u_embeddings_2 = torch.nn.Embedding(self.user_feature_dim[1], int(self.emb_size/4))
            self.u_embeddings_3 = torch.nn.Embedding(self.user_feature_dim[2], int(self.emb_size/4))
            self.u_embeddings_4 = torch.nn.Embedding(self.user_feature_dim[3], int(self.emb_size/4))
            #print(11111)

        #

        self.rnn = torch.nn.GRU(input_size=self.emb_size, hidden_size=self.hidden_size, batch_first=True)
        self.out = torch.nn.Linear(self.hidden_size, self.emb_size, bias=False)

    def load_pretrained_i_emb(self, i_emb_path):
        if os.path.exists(i_emb_path):
            pre_i_embeddings = torch.load(i_emb_path)
            assert pre_i_embeddings.shape == self.i_embeddings.weight.shape, \
                "pre-trained embedding's shape != item embedding's shape"
            self.i_embeddings = self.i_embeddings.from_pretrained(pre_i_embeddings, freeze=False)
            logging.info('Load pre-trained item embeddings from ' + i_emb_path)
        else:
            raise ValueError("The path for pre-trained item embedding is wrong!")

    def forward(self, feed_dict, phase, eval_on_sampling):
        self.check_list = []
        i_ids = feed_dict['item_id']  # [batch_size, -1]
        history = feed_dict['item_his']  # [batch_size, history_max]
        lengths = feed_dict['lengths']  # [batch_size]
        #print(i_ids.shape)
        #
        #user_feature = feed_dict['user_feature']
        #
        #tmp1 = user_feature[:, 0]
        # print(i_ids.shape) #[256,129] ?
        # print(tmp1.shape) # [batch_size]


        i_vectors = self.i_embeddings(i_ids)  # output : [batchsize * L ]





        his_vectors = self.i_embeddings(history)

        # Sort and Pack
        sort_his_lengths, sort_idx = torch.topk(lengths, k=len(lengths))
        sort_his_vectors = his_vectors.index_select(dim=0, index=sort_idx)
        # print(sort_his_vectors.shape)
        # print(torch.min(sort_his_vectors))
        history_packed = torch.nn.utils.rnn.pack_padded_sequence(sort_his_vectors, sort_his_lengths.cpu(),
                                                                 batch_first=True)

        # RNN
        output, hidden = self.rnn(history_packed, None)

        # Unsort
        sort_rnn_vector = self.out(hidden[-1])
        unsort_idx = torch.topk(sort_idx, k=len(lengths), largest=False)[1]
        rnn_vector = sort_rnn_vector.index_select(dim=0, index=unsort_idx)

        # print(rnn_vector.shape)
        if(self.user_feature_train):
            user_feature = feed_dict['user_feature']
            u1_vectors = self.u_embeddings_1(user_feature[:, 0])  # output : [batchsize  ]
            u2_vectors = self.u_embeddings_2(user_feature[:, 1])
            u3_vectors = self.u_embeddings_3(user_feature[:, 2])
            u4_vectors = self.u_embeddings_4(user_feature[:, 3])
            u_vectors = torch.cat((u1_vectors,u2_vectors,u3_vectors,u4_vectors),dim=1)

            mask = (user_feature>0).repeat(1,int(self.emb_size/4))
            u_vectors = u_vectors * mask

            normalize_u = torch.nn.functional.normalize(u_vectors,p=2,dim=1)/4

            rnn_vector=rnn_vector + normalize_u

            #rnn_vector = rnn_vector + u_vectors


            #exp89
            #rnn_vector =torch.cat((rnn_vector,u_vectors),dim=1)
            #i_vectors=i_vectors.repeat(1, 1, 2)

            #exp 87



            #pred_1 = (rnn_vector[:, None, :] * i_vectors).sum(-1)
            #pred_2=(tmp2_vectors[:, None, :] * i_vectorss).sum(-1)
            #print(pred_1.size())
            #print(pred_2.size())
            #print(pred_1)
            #print(pred_2)
            # only  sum
            #rnn_vector=rnn_vector + u1_vectors + u2_vectors + u3_vectors + u4_vectors

        # Predicts
        if phase != 'train' and not eval_on_sampling:
            # todo: target score, neg mask
            negs = torch.arange(1, self.item_num).cuda()
            neg_mask = ~negs.eq(i_ids)
            #if self.user_feature_train:
           #     neg_pred = torch.matmul(rnn_vector, self.i_embeddings(negs).t().repeat(2,1))
           # else:
            #    neg_pred = torch.matmul(rnn_vector, self.i_embeddings(negs).t())

            neg_pred = torch.matmul(rnn_vector, self.i_embeddings(negs).t())
            target_pred = (rnn_vector[:, None, :] * i_vectors).sum(-1)
            neg_pred = torch.where(neg_mask, neg_pred, torch.ones_like(neg_pred) * (-2 ** 32 + 1))
            prediction = torch.cat([target_pred, neg_pred], -1)
            # print(prediction)
            # print(prediction.shape)
        else:
            prediction = (rnn_vector[:, None, :] * i_vectors).sum(-1)

        return prediction.view(feed_dict['batch_size'], -1)
