# -*- coding: UTF-8 -*-

import os
import time
import pickle
import logging
from collections import defaultdict
import numpy as np
import torch
from torch.utils.data import Dataset as BaseDataset
from torch.nn.utils.rnn import pad_sequence

from utils import utils

from models.CFDataset import CFDataset

class SeqDataset(CFDataset):
    def __init__(self, corpus, args):
        super().__init__(corpus, args)

        self._prepare()

    def _prepare(self):
            idx_select = np.array(self.data['his_length']) > 0  # history length must be non-zero
            for key in self.data:
                if key == 'item_his':
                    self.data[key] = np.array(self.data[key], dtype=np.object)[idx_select]
                else:
                    self.data[key] = np.array(self.data[key])[idx_select]


    def _get_feed_dict(self, index):
        feed_dict = super()._get_feed_dict(index)
        feed_dict['user_id'] = self.data['user_id'][index]
        feed_dict['item_his'] = np.array(self.data['item_his'][index])
        feed_dict['lengths'] = self.data['his_length'][index]
        return feed_dict