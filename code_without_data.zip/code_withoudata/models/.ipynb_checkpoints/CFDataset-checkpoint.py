# -*- coding: UTF-8 -*-

import os
import time
import pickle
import logging
from collections import defaultdict
import numpy as np
import torch
from torch.utils.data import Dataset as BaseDataset
from torch.nn.utils.rnn import pad_sequence

from utils import utils

class CFDataset(BaseDataset):
    def __init__(self, corpus, args):
        # self.corpus           = corpus
        self.user_clicked_set = corpus.user_clicked_set
        self.eval_on_sampling = args['eval_on_sampling']
        self.phase            = args['phase']
        self.ns_mode          = args['ns_mode']
        self.n_items          = corpus.n_items
        self.num_neg          = args['num_neg']
        self.data             = utils.df_to_dict(corpus.data_df[self.phase])
        # DataFrame is not compatible with multi-thread operations
        self.neg_items = []
        # if self.phase != 'train' and self.eval_on_sampling:
        #     self.neg_items = self.data['neg_items']

    def __len__(self):
        for key in self.data:
            return len(self.data[key])

    def __getitem__(self, index):
        return self._get_feed_dict(index)

    # Key method to construct input data for a single instance
    def _get_feed_dict(self, index):
        target_item = self.data['item_id'][index]
        if self.phase != 'train' and not self.eval_on_sampling:
            item_ids = np.concatenate([[target_item]])
        else:
            neg_items = self.neg_items[index]
            item_ids = np.concatenate([[target_item], neg_items])
        
        feed_dict = {'item_id': item_ids}
        return feed_dict

    # Sample negative items for all the instances (called before each epoch)
    def negative_sampling(self, num_neg=None):
        # if self.ns_mode == 1:
        #     self.neg_items = np.random.randint(1, self.corpus.n_items, size=(len(self), self.num_neg))
        # elif self.ns_mode == 2:
        #     raise ValueError("Not implement ns model 2!")
        self.neg_items = []
        if num_neg is None:
            num_neg = self.num_neg

        for i, u in enumerate(self.data['user_id']):
            negs = []
            user_clicked_set = self.user_clicked_set[u]
            
            while len(negs) < num_neg:
                tmp_neg = np.random.randint(
                    1, self.n_items, size=num_neg)
                tmp_neg = [x for x in tmp_neg if x not in user_clicked_set]
                negs.extend(tmp_neg)
            self.neg_items.append(negs[:num_neg])

    # Collate a batch according to the list of feed dicts
    def collate_batch(self, feed_dicts):
        feed_dict = dict()
        for key in feed_dicts[0]:
            if key in ('item_his'):
                feed_dict[key] = pad_sequence(
                    [torch.from_numpy(d[key]) for d in feed_dicts],
                    batch_first=True,
                    padding_value=0)
            else:
                stack_val = np.array([d[key] for d in feed_dicts])
                feed_dict[key] = torch.from_numpy(stack_val)
                
        feed_dict['batch_size'] = len(feed_dicts)
        feed_dict['phase'] = self.phase

        return feed_dict