# -*- coding: UTF-8 -*-

import os
import torch
import torch.nn as nn
import logging
import numpy as np

from models.GRU4Rec import GRU4Rec
from models.BaseModel import BaseModel

from utils import components
from utils import utils


class GCSAN(GRU4Rec):
    @staticmethod
    def parse_model_args(parser):
        # parser.add_argument('--num_layers', type=int, default=2,
        #                     help='Number of self-attention layers.')
        # parser.add_argument('--num_heads', type=int, default=2,
        #                     help='Number of self-attention heads.')
        # parser.add_argument('--inner_times', type=int, default=2,
        #                     help='times of embedding size.')
        return GRU4Rec.parse_model_args(parser)

    def __init__(self, args, corpus):
        self.max_his = args.history_max
        self.num_layers = args.num_layers
        self.len_range = utils.numpy_to_torch(np.arange(self.max_his))
        self.num_heads = args.num_heads
        self.inner_times = args.inner_times
        super().__init__(args, corpus)

    def _define_params(self):
        self.i_embeddings = torch.nn.Embedding(self.item_num, self.emb_size, padding_idx=0)
        self.p_embeddings = torch.nn.Embedding(self.max_his + 1, self.emb_size)
        self.rnn = torch.nn.GRUCell(input_size=2 * self.emb_size, hidden_size=self.emb_size)
        self.linear_in = torch.nn.Linear(self.emb_size, self.emb_size, bias=True)
        self.linear_out = torch.nn.Linear(self.emb_size, self.emb_size, bias=True)


        inner_size = self.inner_times * self.emb_size
        head_emb_size = int(self.emb_size / self.num_heads)
        logging.info('head_emb_size is ' + str(head_emb_size))

        self.layer_stack = nn.ModuleList([
            components.EncoderLayer(self.emb_size, inner_size, self.num_heads, head_emb_size, head_emb_size, dropout=self.dropout)
            for _ in range(self.num_layers)])

        self.dropout_layer = torch.nn.Dropout(p=self.dropout)
        self.layer_norm = torch.nn.LayerNorm(self.emb_size)
    
    def load_pretrained_i_emb(self, i_emb_path):
        if os.path.exists(i_emb_path):
            pre_i_embeddings = torch.load(i_emb_path)
            assert pre_i_embeddings.shape == self.i_embeddings.weight.shape, \
            "pre-trained embedding's shape != item embedding's shape"
            self.i_embeddings = self.i_embeddings.from_pretrained(pre_i_embeddings, freeze=False)
            logging.info('Load pre-trained item embeddings from ' + i_emb_path)
        else:
            raise ValueError("The path for pre-trained item embedding is wrong!")

    def forward(self, feed_dict, phase, eval_on_sampling):
        self.check_list = []
        i_ids = feed_dict['item_id']          # [batch_size, -1]
        history = feed_dict['history_items']  # [batch_size, history_max]
        lengths = feed_dict['lengths']        # [batch_size]
        in_items = feed_dict['in_items']
        out_items = feed_dict['out_items']
        batch_size, seq_len = history.shape

        valid_his = (history > 0).byte()
        i_vectors = self.i_embeddings(i_ids)
        his_vectors = self.i_embeddings(history)
        
        in_vectors = self.linear_in(self.i_embeddings(in_items))
        out_vectors = self.linear_out(self.i_embeddings(out_items))
        graph_vectors = torch.cat((in_vectors, out_vectors), dim=-1)
        graph_vectors = graph_vectors.view(batch_size * seq_len, -1)
        his_vectors = his_vectors.view(batch_size * seq_len, -1)
        graph_vectors = self.rnn(graph_vectors, his_vectors)
        graph_vectors = graph_vectors.view(batch_size, seq_len, -1)


        # Position embedding
        # lengths:  [4, 2, 5]
        # position: [[4, 3, 2, 1, 0], [2, 1, 0, 0, 0], [5, 4, 3, 2, 1]]
        position = self.len_range[:seq_len].unsqueeze(0).repeat(batch_size, 1)
        position = (lengths[:, None] - position) * valid_his.long()
        pos_vectors = self.p_embeddings(position)
        #his_vectors = his_vectors + pos_vectors
        his_vectors = graph_vectors + pos_vectors

        his_vectors = self.layer_norm(his_vectors)
        his_vectors = self.dropout_layer(his_vectors)

        # Self-attention
        #attn_mask = 1 - valid_his.unsqueeze(1).repeat(1, seq_len, 1)
        attn_mask = valid_his.unsqueeze(1).repeat(1, seq_len, 1)
        last_position = (lengths - 1).unsqueeze(1)
        aux_idx = [torch.LongTensor(range(lengths.shape[0])).unsqueeze(1), last_position]

        for self_layer in self.layer_stack:
            his_vectors, _ = self_layer(his_vectors, slf_attn_mask=attn_mask)

        his_vectors = his_vectors * valid_his[:, :, None].double()
        graph_vectors = graph_vectors * valid_his[:, :, None].double()
        graph_vector = graph_vectors[aux_idx].squeeze()

        # his_vector = (his_vectors * (position == 1).double()[:, :, None]).sum(1)
        #his_vector = his_vectors.sum(1) / lengths[:, None].double()
        his_vector = his_vectors[aux_idx].squeeze()
        his_vector = 0.5 * his_vector + 0.5 * graph_vector
        # ↑ average pooling is shown to be more effective than the most recent embedding
        if phase != 'train' and not eval_on_sampling:
            # todo: target score, neg mask
            negs = torch.arange(1, self.item_num).cuda()
            neg_mask = ~negs.eq(i_ids)
            neg_pred = torch.matmul(his_vector, self.i_embeddings(negs).t())
            target_pred = (his_vector[:, None, :] * i_vectors).sum(-1)
            neg_pred = torch.where(neg_mask, neg_pred, torch.ones_like(neg_pred)* (-2 ** 32 + 1))
            prediction = torch.cat([target_pred, neg_pred], -1)
        else:
            prediction = (his_vector[:, None, :] * i_vectors).sum(-1)

        return prediction.view(batch_size, -1)
    
    # class Dataset(BaseModel.Dataset):
    #     def _prepare(self):
    #         idx_select = np.array(self.data['his_length']) > 0  # history length must be non-zero
    #         for key in self.data:
    #             self.data[key] = np.array(self.data[key])[idx_select]
    #         super()._prepare()

    #     def _get_feed_dict(self, index):
    #         feed_dict = super()._get_feed_dict(index)
    #         feed_dict['user_id'] = self.data['user_id'][index]
    #         feed_dict['history_items'] = np.asarray(self.data['item_his'][index])
    #         feed_dict['lengths'] = self.data['his_length'][index]

    #         if feed_dict['lengths'] == 1:
    #             feed_dict['in_items'] = np.asarray([0])
    #             feed_dict["out_items"] = np.asarray([0])
    #         else:
    #             feed_dict['in_items'] = np.asarray([0] + self.data['item_his'][index][:-1])
    #             feed_dict['out_items'] = np.asarray(self.data['item_his'][index][1:] + [0])


    #         return feed_dict