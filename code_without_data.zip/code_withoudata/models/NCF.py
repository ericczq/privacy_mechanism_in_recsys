# -*- coding: UTF-8 -*-

import torch
import logging

from utils import utils
from models.BPR import BPR


class NCF(BPR):
    @staticmethod
    def parse_model_args(parser):
        parser.add_argument('--layers', type=str, default='[64]',
                            help="Size of each layer.")
        return BPR.parse_model_args(parser)

    def __init__(self, args, corpus, user_feature_dim=[], user_feature_train=False):
        self.layers = eval(args.layers)
        if user_feature_train:
            self.user_feature_dim = user_feature_dim

        self.user_feature_train = user_feature_train
        super().__init__(args, corpus)

    def _define_params(self):
        self.mf_u_embeddings = torch.nn.Embedding(self.user_num, self.emb_size)
        self.mf_i_embeddings = torch.nn.Embedding(self.item_num, self.emb_size)
        self.mlp_u_embeddings = torch.nn.Embedding(self.user_num, self.emb_size)
        self.mlp_i_embeddings = torch.nn.Embedding(self.item_num, self.emb_size)

        if self.user_feature_train:
            self.u_embeddings_1 = torch.nn.Embedding(self.user_feature_dim[0], int(self.emb_size/4))
            self.u_embeddings_2 = torch.nn.Embedding(self.user_feature_dim[1], int(self.emb_size/4))
            self.u_embeddings_3 = torch.nn.Embedding(self.user_feature_dim[2], int(self.emb_size/4))
            self.u_embeddings_4 = torch.nn.Embedding(self.user_feature_dim[3], int(self.emb_size/4))

        self.mlp = torch.nn.ModuleList([])
        pre_size = 2 * self.emb_size
        for i, layer_size in enumerate(self.layers):
            self.mlp.append(torch.nn.Linear(pre_size, layer_size))
            pre_size = layer_size
        self.dropout_layer = torch.nn.Dropout(p=self.dropout)
        self.prediction = torch.nn.Linear(pre_size + self.emb_size, 1, bias=False)

    def forward(self, feed_dict, phase, eval_on_sampling):
        self.check_list = []
        u_ids = feed_dict['user_id']  # [batch_size]
        i_ids = feed_dict['item_id']  # [batch_size, -1]

        u_ids = u_ids.unsqueeze(-1).repeat((1, i_ids.shape[1]))  # [batch_size, -1]

        mf_u_vectors = self.mf_u_embeddings(u_ids)
        mf_i_vectors = self.mf_i_embeddings(i_ids)
        mlp_u_vectors = self.mlp_u_embeddings(u_ids)
        mlp_i_vectors = self.mlp_i_embeddings(i_ids)

        # print(mf_u_vectors.size())
        # print(mlp_u_vectors.size())

        if (self.user_feature_train):
            user_feature = feed_dict['user_feature']
            u1_vectors = self.u_embeddings_1(user_feature[:, 0])  # output : [batchsize  ]
            u2_vectors = self.u_embeddings_2(user_feature[:, 1])
            u3_vectors = self.u_embeddings_3(user_feature[:, 2])
            u4_vectors = self.u_embeddings_4(user_feature[:, 3])
            #print(u1_vectors.size())
            #print(mlp_u_vectors.size())

            #tmp = u1_vectors.reshape([u1_vectors.shape[0], 1, u1_vectors.shape[1]])

            u_vectors = torch.cat((u1_vectors, u2_vectors, u3_vectors, u4_vectors), dim=1)

            mask = (user_feature > 0).repeat(1, int(self.emb_size / 4))
            u_vectors = u_vectors * mask

            normalize_u = torch.nn.functional.normalize(u_vectors, p=2, dim=1) / 4.0
            #
            # tmp2=normalize_u[0]
            # tmp3=sum(tmp2)


            normalize_u=(normalize_u).reshape(
                [normalize_u.shape[0], 1, normalize_u.shape[1]])[:, :1, :].repeat(1, mlp_u_vectors.shape[1], 1)

            mlp_u_vectors = mlp_u_vectors +  normalize_u


            #print(tmp.size())
            # print(tmp.repeat(1, 3, 1))
            # print(tmp[:,:1,:].repeat(1, 3, 1))

            # only  sum
            # mlp_u_vectors = mlp_u_vectors + (u1_vectors + u2_vectors + u3_vectors + u4_vectors).reshape(
            #     [u1_vectors.shape[0], 1, u1_vectors.shape[1]])[:, :1, :].repeat(1, mlp_u_vectors.shape[1], 1)

        if phase != 'train' and not eval_on_sampling:
            # todo: target score, neg mask
            negs = torch.arange(0, self.item_num).cuda()
            neg_mask = ~negs.eq(i_ids)

            negs = torch.arange(1, self.item_num).cuda()
            neg_mf_emb = self.mf_i_embeddings(negs).repeat(i_ids.shape[0], 1, 1)
            mf_i_vectors = torch.cat([mf_i_vectors, neg_mf_emb], dim=1)

            neg_mlp_emb = self.mlp_i_embeddings(negs).repeat(i_ids.shape[0], 1, 1)
            mlp_i_vectors = torch.cat([mlp_i_vectors, neg_mlp_emb], dim=1)
            mlp_u_vectors = mlp_u_vectors[:, :1, :].repeat(1, self.item_num, 1)

        mf_vector = mf_u_vectors * mf_i_vectors
        #print(mf_vector.size())
        mlp_vector = torch.cat([mlp_u_vectors, mlp_i_vectors], dim=-1)
        #print(mlp_vector.size())
        #print(1 / 0)

        for layer in self.mlp:
            mlp_vector = layer(mlp_vector).relu()
            mlp_vector = self.dropout_layer(mlp_vector)

        output_vector = torch.cat([mf_vector, mlp_vector], dim=-1)
        prediction = self.prediction(output_vector).squeeze(-1)

        if phase != 'train' and not eval_on_sampling:
            prediction = torch.where(neg_mask, prediction, torch.ones_like(prediction) * (-2 ** 32 + 1))

        return prediction.view(feed_dict['batch_size'], -1)

    def save_model(self, model_path=None):
        if model_path is None:
            model_path = self.model_path
        utils.check_dir(model_path)
        torch.save(self.state_dict(), model_path)

        logging.info('Save model to ' + model_path[:50] + '...')
