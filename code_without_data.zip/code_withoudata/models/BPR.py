# -*- coding: UTF-8 -*-

import torch
import logging

from utils import utils
from models.BaseModel import BaseModel


class BPR(BaseModel):
    @staticmethod
    def parse_model_args(parser):
        parser.add_argument('--emb_size', type=int, default=64,
                            help='Size of embedding vectors.')
        return BaseModel.parse_model_args(parser)

    def __init__(self, args, corpus):
        self.emb_size = args.emb_size
        self.user_num = corpus.n_users
        super().__init__(args, corpus)

    def _define_params(self):
        self.u_embeddings = torch.nn.Embedding(self.user_num, self.emb_size)
        self.i_embeddings = torch.nn.Embedding(self.item_num, self.emb_size)
        self.user_bias = torch.nn.Embedding(self.user_num, 1)
        self.item_bias = torch.nn.Embedding(self.item_num, 1)

    def forward(self, feed_dict, phase, eval_on_sampling):
        self.check_list = []
        u_ids = feed_dict['user_id']  # [batch_size]
        i_ids = feed_dict['item_id']  # [batch_size, -1]

        cf_u_vectors = self.u_embeddings(u_ids)
        cf_i_vectors = self.i_embeddings(i_ids)
        u_bias = self.user_bias(u_ids)
        i_bias = self.item_bias(i_ids).squeeze(-1)
        
        if phase != 'train' and not eval_on_sampling:
            # todo: target score, neg mask
            negs = torch.arange(1, self.item_num).cuda()
            neg_mask = ~negs.eq(i_ids)
            neg_pred = torch.matmul(cf_u_vectors, self.i_embeddings(negs).t())
            target_pred = (cf_u_vectors[:, None,:] * cf_i_vectors).sum(dim=-1)
            neg_pred = torch.where(neg_mask, neg_pred, torch.ones_like(neg_pred)* (-2 ** 32 + 1))
            prediction = torch.cat([target_pred, neg_pred], -1)
        else:
            prediction = (cf_u_vectors[:, None,:] * cf_i_vectors).sum(dim=-1)  # [batch_size, -1]
            
        prediction = prediction + u_bias + i_bias
        return prediction.view(feed_dict['batch_size'], -1)
    
    def save_model(self, model_path=None):
        if model_path is None:
            model_path = self.model_path
        utils.check_dir(model_path)
        torch.save(self.state_dict(), model_path)
        # save embeddings for other models' finetuning
        torch.save(self.i_embeddings.weight, model_path[:model_path.rfind('.')]+'__i_emb.pt')
        
        logging.info('Save model to ' + model_path[:50] + '...')
        
        
    # class Dataset(BaseModel.Dataset):
    #     def _get_feed_dict(self, index):
    #         feed_dict = super()._get_feed_dict(index)
    #         feed_dict['user_id'] = self.data['user_id'][index]
    #         return feed_dict
