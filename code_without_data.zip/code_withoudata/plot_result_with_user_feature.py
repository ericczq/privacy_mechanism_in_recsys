import os.path
import pickle
from rl_helper import *
from rl_helper.rl_utils import int_to_binary_list
import matplotlib.pyplot as plt
from collections import Counter
import torch
import numpy


class Save_logs(object):
    def __init__(self, exp_id=0, continues=True, dataloader_mode='latest', action_split=3,
                 epoch='latest', version='act3_sn630_rn300', specific_num=630, risk_policy_agt_num=300, save_dir='',
                 dataset='ml-100k', rl_agent_type='EpsilonGreedy',user_feature_dim=None):
        self.exp_id = exp_id
        self.continues = continues
        self.dataloader_mode = dataloader_mode
        self.rl_agent_type = rl_agent_type
        self.dataset = dataset
        self.action_split = action_split
        self.action_space = -1

        self.epoch = epoch
        self.version = version

        self.policy_agent_num = specific_num
        self.risk_policy_agt_num = risk_policy_agt_num

        self.save_dir = save_dir
        self.model_file = ''
        self.model = None
        self.user_feature_dim=None

        # sensitive users
        self.sensitive_w = 10
        # normal users
        self.normal_w = 1
        self.train_epoch = 0
        #
        self.figure_name_list = ['action', 'privacy_cost', 'rec_reward', 'utility', 'gamma', 'estimation',
                                 'non_zero_privacy_cost', 'non_zero_action',
                                 'last_action']
        if user_feature_dim is not None:
            self.user_feature_dim=user_feature_dim

        self.profile_combined=True



    def set_model_file(self, path):
        self.model_file = path

    def set_plot_epoch(self, epoch):
        self.train_epoch = min(epoch, self.train_epoch)

    def set_action_space(self):
        if self.continues:
            self.action_space = self.action_split + 1
        else:
            self.action_space = 2 ** self.action_split
        ## user feature
        if self.user_feature_dim is not None:

            if self.profile_combined:
                self.action_space = self.action_space*2
            else:
                self.action_space=self.action_space *(2 ** self.user_feature_dim)

    def init_results_list(self):
        self.normal_user_his = torch.zeros([5, self.policy_agent_num - self.risk_policy_agt_num, self.train_epoch])
        self.normal_user_id = []
        self.normal_user_gamma = []
        self.normal_user_define = "[4* normal_user_num * train_epoch] :u ser_action_list;user_cost_list;rec_reward_list;user_utility_list"
        self.normal_user_estimate = torch.zeros(self.policy_agent_num - self.risk_policy_agt_num, self.action_space)

        self.privacy_risk_user_his = torch.zeros([5, self.risk_policy_agt_num, self.train_epoch])
        self.privacy_risk_user_id = []
        self.privacy_risk_user_gamma = []
        self.privacy_risk_user_define = "[4* privacy_risk_num * train_epoch] :u ser_action_list;user_cost_list;rec_reward_list;user_utility_list"
        self.privacy_risk_user_estimate = torch.zeros(self.risk_policy_agt_num, self.action_space)

    def add_normal_user_result(self, users, list_id):


        if self.profile_combined==True:
            his_action=[]
            profile_action=[]
            for action in users.actions:

                history_action = action % 2
                attribute_action_coded = int(action / 2)
                if attribute_action_coded ==1:
                    attribute_action= (2 ** self.user_feature_dim)-1
                else:
                    attribute_action =0
                his_action.append(history_action)
                profile_action.append(attribute_action)
        else:
            his_action = [ int(u / (2 ** self.user_feature_dim)) for u in users.actions]
            profile_action = [int(u % (2 ** self.user_feature_dim)) for u in users.actions]

        self.normal_user_his[0][list_id] = torch.tensor(his_action)
        self.normal_user_his[1][list_id] = torch.tensor(users.cost_list) * -1
        self.normal_user_his[2][list_id] = torch.tensor(users.rec_reward_list)
        self.normal_user_his[3][list_id] = torch.tensor(users.reward_list)
        self.normal_user_his[4][list_id] = torch.tensor(profile_action)


        self.normal_user_gamma.append(users.gamma)
        self.normal_user_id.append(users.uid)
        max_action = users.estimates.index(max(users.estimates))
        values=max(users.estimates)
        #action_compare=users.estimates[4]
        #action_compare2=users.estimates[16]

        self.normal_user_estimate[list_id] = torch.tensor(users.estimates)  # list N *[action space]

    def add_privacy_risk_user_results(self, users, list_id):

        his_action = [ int(u / (2 ** self.user_feature_dim)) for u in users.actions]
        profile_action = [ int(u % (2 ** self.user_feature_dim)) for u in users.actions]

        self.privacy_risk_user_his[0][list_id] = torch.tensor(his_action)
        self.privacy_risk_user_his[1][list_id] = torch.tensor(users.cost_list) * -1
        self.privacy_risk_user_his[2][list_id] = torch.tensor(users.rec_reward_list)
        self.privacy_risk_user_his[3][list_id] = torch.tensor(users.reward_list)
        self.privacy_risk_user_his[4][list_id] = torch.tensor(profile_action)

        self.privacy_risk_user_gamma.append(users.gamma)
        self.privacy_risk_user_id.append(users.uid)
        self.privacy_risk_user_estimate[list_id] = torch.tensor(users.estimates)  # list N *[action space]

    def load_model_file(self):
        with open(self.model_file, 'rb') as file:
            user_list = pickle.load(file)

            self.set_action_space()
            self.train_epoch = user_list[0].t

            self.init_results_list()
            cnt = 0
            for i, users in enumerate(user_list):
                if users.w == self.normal_w:
                    self.add_normal_user_result(users=users, list_id=i - cnt)
                else:
                    self.add_privacy_risk_user_results(users=users, list_id=cnt)
                    cnt += 1



    def get_data(self, data_tensor, id='avg'):

        if id == 'non_zero':
            results = torch.sum(data_tensor, dim=0) / torch.sum(data_tensor > 0, dim=0)
            return results

        if id != 'avg':
            id_num = int(id)
            if (id_num < data_tensor.size()[0]):
                return data_tensor[id].tolist()
            else:
                print('error key with id =  ' + id)

        else:
            # deal with avg results
            tmp = torch.sum(data_tensor, dim=0)
            # print( tmp[-1])
            results = torch.sum(data_tensor, dim=0) / data_tensor.size()[0]
            return results.tolist()
    def get_data_num(self,data_tensor,epoch=1,normal_user=True,ln=0,user_feature=False):

        if user_feature==True:
            data_list = [4 for i in range(638)]
        else:

            data_list= read_from_disk('/Users/eric.czq/Downloads/privacy_clean/src/mv_user_data_len.pkl')
        epoch_data = data_tensor[:, epoch]

        if normal_user:
            user_list=self.normal_user_id
        else:
            user_list=self.privacy_risk_user_id

        data_volume=[0]*len(user_list)
        ori_data_volume=[0]*len(user_list)

        #check all user num

        data_1=0
        data_2=0
        data_3=0

        for i in range(1,638):
            if i in self.normal_user_id:
                data_1+=(data_list[i])
            elif i in self.privacy_risk_user_id:
                data_2+=(data_list[i])
            else:
                data_3+=(data_list[i])

        cnt = 0
        volume_num = 0

        for usr_id in user_list:
            ori_data_volume[cnt]=data_list[usr_id]
            if self.user_feature_dim is not None:
                if user_feature :
                    one_part = (ori_data_volume[cnt] * 1.0 / self.user_feature_dim)
                    check = self.user_feature_dim
                else:
                    one_part = (ori_data_volume[cnt] * 1.0 / self.action_split)
                    check = self.action_split
            else:
                one_part = (ori_data_volume[cnt] * 1.0/self.action_split)
                check = self.action_split

            tmp=0

            for i in range(epoch):
                if (data_tensor.size()[1]) >= 400 and (data_tensor.size()[1]) < 1000:
                    epoch_data = data_tensor[:, (i + 380)]
                else:
                    epoch_data = data_tensor[:, -(i + 1)]

                if self.continues:
                    action = epoch_data[cnt]
                else:
                    action=compute_action(int(epoch_data[cnt]))

                if user_feature:
                    action = compute_action(int(epoch_data[cnt]))

                if action == check:
                        data_volume[cnt]+=ori_data_volume[cnt]
                else:
                        data_volume[cnt] += int(one_part*action)
                if (action) > 0:
                    tmp += 1

            volume_num += tmp / (epoch*1.0)
            data_volume[cnt] = data_volume[cnt] / (epoch*1.0)
            cnt = cnt + 1
        print('----')
        print(str(volume_num))
        return data_volume,ori_data_volume

    def get_action_axis(self, ylabel=[]):
        if self.continues:
            return [i / self.action_split for i in range(self.action_split + 1)]
        else:
            x_new_label = []
            # act = 0->2**N-1
            for i, y_ans in enumerate(ylabel):
                action = compute_action(i) / self.action_split
                x_new_label.append(action)

            return x_new_label

    def get_epoch_data(self, data_tensor, epoch=-1, figure_name='last_action', gamma=[]):

        epoch_data = data_tensor[:, epoch]

        if figure_name == 'non_zero_action':
            epoch_data3 = []
            for i, data in enumerate(epoch_data):

                if (gamma[i] > 0):
                    if self.continues:
                        epoch_data3.append(int(data) * 1.0 / self.action_split)
                    else:
                        epoch_data3.append(compute_action(int(data)) * 1.0 / self.action_split)
            return epoch_data3

        # deal with data distrbution
        if 'action' in figure_name:
            if self.continues:
                return (epoch_data * 1.0 / self.action_split).tolist()
            else:
                epoch_data2 = []

                for data in (epoch_data):
                    # print(data)
                    epoch_data2.append(compute_action(int(data)) * 1.0 / self.action_split)
                    # print(epoch_data2[i])
                    # print('----')
                return epoch_data2

        if 'profile' in figure_name:

                epoch_data = data_tensor[:, epoch]
                epoch_data2 = []

                for i, data in enumerate(epoch_data):
                  if (gamma[i] > 0):
                    # print(data)
                    action = data
                    epoch_data2.append(compute_action(int(data)) * 1.0 / self.user_feature_dim)
                    # print(epoch_data2[i])
                    # print('----')

                return epoch_data2

        return epoch_data.tolist()

    def plot_result(self, figure_name, label, id='avg', normal_user=True, cnt=0):

        # if (figure_name not in self.figure_name_list):
        #     print('figure name is ' + figure_name + ' not in the figure list ' + str(self.figure_name_list))
        #     return

        if figure_name == 'gamma':
            plot_data = self.normal_user_gamma if normal_user else self.privacy_risk_user_gamma  # gamma list
            plt.hist(plot_data, label=label)
            return plot_data
        elif figure_name == 'last_20_action':
            results, ori_data = self.get_data_num(data_tensor=self.normal_user_his[0], epoch=20, normal_user=True,
                                                  ln=0) if normal_user else \
                self.get_data_num(
                    data_tensor=self.privacy_risk_user_his[0], epoch=20, normal_user=normal_user, ln=0)
            print('total normal is ' + str(sum(results)) + ' /' + str(sum(ori_data)) + ' | p= ' + str(
                sum(results) / sum(ori_data)))
            print(
                'avg history action percentage is' + str(sum([results[i] / ori_data[i] for i in range(len(results))]) / len(results)))


            return [results, ori_data]

        elif figure_name=='last_20_profile':
            tmp = self.normal_user_his[4]
            results, ori_data = self.get_data_num(data_tensor=self.normal_user_his[4], epoch=20, normal_user=True,
                                                  ln=0,user_feature=True) if normal_user else \
                self.get_data_num(
                    data_tensor=self.privacy_risk_user_his[4], epoch=20, normal_user=normal_user, ln=0,user_feature=True)
            print('total normal is ' + str(sum(results)) + ' /' + str(sum(ori_data)) + ' | p= ' + str(
                sum(results) / sum(ori_data)))
            print(
                'avg profile percentage is' + str(sum([results[i] / ori_data[i] for i in range(len(results))]) / len(results)))
            return results

        elif figure_name == 'estimation':
            plot_data = self.get_data(data_tensor=self.normal_user_estimate, id=id) if normal_user else self.get_data(
                data_tensor=self.privacy_risk_user_estimate, id=id)
            new_x = self.get_action_axis(ylabel=plot_data)
            if self.continues:
                plt.plot(new_x, plot_data, label=label)
            else:
                plt.scatter(new_x, plot_data, label=label)
            return plot_data
        elif figure_name == 'last_action':
            # get the action distribution
            plot_data = self.get_epoch_data(data_tensor=self.normal_user_his[0], epoch=-1,
                                            figure_name=figure_name) if normal_user else self.get_epoch_data(
                data_tensor=self.privacy_risk_user_his[0], epoch=-1, figure_name=figure_name)
            # return by N agent * 1 behavior

            # get the number of cnt
            dict = {}
            for key in plot_data:
                dict[key] = dict.get(key, 0) + 1

            # plt.hist([da*100 for da in plot_data],label=label,rwidth=0.5)
            # plt.hist(plot_data+cnt*0.05, label=label,rwidth=0.5)

            import numpy as np
            uni_data = [da * 100.0 + cnt * 0.1 * 100 / 6 for da in plot_data]
            weights = np.ones_like(uni_data) / float(len(uni_data))
            plt.hist([da * 100.0 + cnt * 0.1 * 100 / 6 for da in plot_data], weights=weights, label=label, rwidth=0.1,
                     bins=16)
            plt.ylabel('Density')
            plt.xlabel('User action on data sharing percentage')
            # plt.hist([da+cnt*0.1/6 for da in plot_data ],label=label,rwidth=0.1)
            cnt = 0
            for it in plot_data:
                if it > 0:
                    cnt += 1
            print(cnt)

            return dict
        elif figure_name == 'last_profile':
            # get the action distribution
            plot_data = self.get_epoch_data(data_tensor=self.normal_user_his[4], epoch=-1,gamma=self.normal_user_gamma,
                                            figure_name=figure_name) if normal_user else self.get_epoch_data(
                data_tensor=self.privacy_risk_user_his[4], epoch=-1, figure_name=figure_name,gamma=self.privacy_risk_user_gamma)
            # return by N agent * 1 behavior

            # get the number of cnt
            dict = {}
            for key in plot_data:
                dict[key] = dict.get(key, 0) + 1

            # plt.hist([da*100 for da in plot_data],label=label,rwidth=0.5)
            # plt.hist(plot_data+cnt*0.05, label=label,rwidth=0.5)

            import numpy as np
            uni_data = [da * 100.0 for da in plot_data]
            weights = np.ones_like(uni_data) / float(len(uni_data))
            plt.hist([da * 100.0  for da in plot_data], weights=weights, label=label, rwidth=0.1,
                     bins=4)
            plt.ylabel('Density')
            plt.xlabel('User action on data sharing percentage')
            # plt.hist([da+cnt*0.1/6 for da in plot_data ],label=label,rwidth=0.1)
            cnt = 0
            for it in plot_data:
                if it > 0:
                    cnt += 1
            print('profile number is ' +str(cnt))
            print('avg per is ' +str( sum(uni_data)/637.0))

            return dict
        elif figure_name == 'non_zero_action':
            plot_data = self.get_epoch_data(data_tensor=self.normal_user_his[0], epoch=-1,
                                            figure_name=figure_name,
                                            gamma=self.normal_user_gamma) if normal_user else self.get_epoch_data(
                data_tensor=self.privacy_risk_user_his[0], epoch=-1, figure_name=figure_name,
                gamma=self.privacy_risk_user_gamma)
            # return by N agent * 1 behavior
            plt.hist([da + cnt * 0.1 / 6 for da in plot_data], label=label, rwidth=0.2, bins=self.action_split)
            return plot_data
        elif figure_name == 'non_zero_privacy_cost':

            his_index = self.figure_name_list.index('privacy_cost')
            plot_data = self.get_data(data_tensor=self.normal_user_his[his_index],
                                      id='non_zero') if normal_user else self.get_data(
                data_tensor=self.privacy_risk_user_his[his_index], id='non_zero')

            print(label + ' :' + str(plot_data[-1]))

            plt.plot([i for i in range(self.train_epoch)], plot_data, label=label)
            return plot_data
        else:
            his_index = self.figure_name_list.index(figure_name)
            plot_data = self.get_data(data_tensor=self.normal_user_his[his_index],
                                      id=id) if normal_user else self.get_data(
                data_tensor=self.privacy_risk_user_his[his_index], id=id)

            print(label + ' :' + str(plot_data[-1]))

            plt.plot([i for i in range(self.train_epoch)], plot_data[:self.train_epoch], label=label)
            return plot_data


def compute_action(action=5):
    cnt = 0
    while (action):
        cnt = cnt + (action & 1)
        action = action >> 1

    return cnt


def add_result_into_args_list(continues_list=[], dataloader_list=[], action_split_list=[], epoch_list=[],
                              version_name_list=[], exp_id=0, specific_num_list=[], risk_policy_agt_num_list=[],
                              risky_w_list=[],
                              save_dir='',user_feature_dim=None,
                              dataset='yelp', rl_agent_type='EpsilonGreedy'):
    args_list = []
    for version_names in version_name_list:

        for continues in continues_list:
            for dataloader_mode in dataloader_list:
                for action_split in action_split_list:
                    for epoch in epoch_list:
                        for specific_num in specific_num_list:
                            for risk_policy_agt_num in risk_policy_agt_num_list:
                                for risky_w in risky_w_list:

                                    version_name = version_names
                                    if len(version_name) == 0:
                                        # construct version name temply (or into by list)
                                        version_name = 'cnt_' if continues else ''

                                    else:
                                        version_name = version_name + ('_cnt_' if continues else '_')

                                    if 'yelp' in version_name:
                                        version_name = version_name + str(action_split) + '_sn' + str(
                                            specific_num) + '_rn' + str(
                                            risk_policy_agt_num) + '_w' + str(risky_w)
                                        dataset = 'yelp'
                                    else:
                                        version_name = version_name + 'act' + str(action_split) + '_sn' + str(
                                            specific_num) + '_rn' + str(
                                            risk_policy_agt_num) + '_w' + str(risky_w)

                                    args = Save_logs(exp_id, continues, dataloader_mode, action_split, epoch,
                                                     version_name,
                                                     specific_num,
                                                     risk_policy_agt_num, save_dir, dataset, rl_agent_type,
                                                     user_feature_dim=user_feature_dim)

                                    if args.continues == True:
                                        results_file = 'rl_cnt_record'
                                    else:
                                        results_file = 'rl_record'

                                    model_folder = save_dir + str(
                                        exp_id) + '/' + results_file + '/' + args.rl_agent_type + '/' + args.dataloader_mode + '/'
                                    final_name = model_folder + str(args.version) + '_epoch_' + epoch + '.pickle'

                                    args.set_model_file(final_name)
                                    # print('begin save at '+final_name)

                                    if (os.path.exists(final_name)):
                                        print('find model in ' + final_name + '! successful add into plot list')
                                        args.load_model_file()
                                        args_list.append(args)
                                    else:
                                        print('no model file in : ' + final_name + '! jumped')
                                    #

    return args_list


def plot_summary(args_list, label_list=[], figure_name='privacy_cost', id='avg', normal_user=True):
    data_list = []
    for i, args in enumerate(args_list):
        # figure_name=['action','privacy_cost','rec_reward','utility','gamma','estimation']

        data = args.plot_result(figure_name=figure_name, label=label_list[i],
                                id=id, normal_user=normal_user, cnt=i)
        #
        data_list.append(data)
        #

    return data_list


def plot_show(xlabel='epoch', title='avg privacy choice'):
    plt.legend()
    if 'action' in title:
        plt.title('converged user data sharing policy')
    else:
        plt.xlabel(xlabel)
        plt.title(title)
    # plt.show()
    return

def dealer(saved_pkl_name='tmp.pkl'):
    # inital
    args_list = []

    # parameter fixed

    exp_id = 80
    save_dir = '/Users/eric.czq/Downloads/privacy_clean/src/results/exp'
    dataset = 'ml-100k'
    rl_agent_type = 'EpsilonGreedy'

    specific_num = [637]
    risk_policy_agt_num = [212,0]
    # [0,100,200,400,600,800,943] expid=2

    # parameter list
    continues_list = [False, True]
    dataloader_list = ['latest']
    action_split_list = [1]
    epoch_list = ['latest']
    version_name_list = ['Use_user_fearture_NCF','Div4_Use_user_fearture_profile_cnt_GRU','Use_user_fearture_GRU']
        #,'Norm_Use_user_fearture_profile_cnt_GRU',]
                         #'No_div_w_Enhanced_Use_user_fearture_GRU']
    risky_w = [10]
    cnt = 0
    user_feature_dim =4

    args_list = add_result_into_args_list(continues_list=continues_list, dataloader_list=dataloader_list,
                                          action_split_list=action_split_list, epoch_list=epoch_list,
                                          version_name_list=version_name_list,
                                          exp_id=exp_id, specific_num_list=specific_num,
                                          risk_policy_agt_num_list=risk_policy_agt_num, risky_w_list=risky_w,
                                          save_dir=save_dir, dataset=dataset, rl_agent_type=rl_agent_type,
                                          user_feature_dim=user_feature_dim
                                          )

    # display args_list or the model list
    print('-----------' + 'total model num is ' + str(len(args_list)) + '-------')

    # saved on pkl
    f = open(saved_pkl_name, 'wb')
    pickle.dump(args_list, f)
    #
    return args_list


def write_multi_list_into_txt(file_name='data.txt', data_list=[], figure_name='last_action'):
    import numpy
    if (figure_name != 'last_action'):
        numpy.savetxt(file_name, numpy.array(data_list))
    else:
        for data in data_list:
            with open(file_name, 'rb') as f:

                for u, v in enumerate(data):
                    print('data :' + str(v) + ' with :' + str(data[v]))

                print('----')


def read_from_disk(path):
    with open(path, 'rb') as file:
        args_list = pickle.load(file)
    return args_list


def plot_result_summary_normal_user(args_list=[], label_list=[], selected_list=[], plot_name='', save_flag=True):
    final_data_list = []
    args_list = [args_list[i] for i in selected_list]  # 取几个画图
    label_list = [label_list[i] for i in selected_list]

    label_list1 = label_list#[label + 'normal_user' for label in label_list]
    for figure_name in ['utility','last_action','last_20_action','last_20_profile','last_profile','rec_reward']:
        #['privacy_cost', 'rec_reward','last_20_action','last_20_profile', 'last_action','last_profile']:  # 'privacy_cost',
        data_list = plot_summary(args_list=args_list, label_list=label_list1, figure_name=figure_name, id='avg',
                                 normal_user=True)
        final_data_list.append(data_list)

        # write_multi_list_into_txt(file_name='data.txt',data_list=data_list2,figure_name=figure_name)

        plot_show(xlabel='', title='avg ' + figure_name)  # use plot show to show figure and add figure configuration
        print('----')
        if save_flag:
            plt.savefig('./mvlen/'+str(plot_name) + '_normal_user_mvlen_' + str(figure_name) + '.png', bbox_inches='tight')
        plt.show()


    action_lists = final_data_list[0]
    profile_lists =final_data_list[3][0]
    reward_list=final_data_list[-1]


    record_reward=[]
    record_non_profile_cnt=[]
    record_gamma=[]
    profile_effect=[]
    cnt=0
    for j in range(len(profile_lists)):
        i=args_list[0].normal_user_id[j]-1

        reward_ls=args_list[0].normal_user_his[2][i]
        profile_ls = args_list[0].normal_user_his[4][i]
        last_20_epoch_reward=reward_ls[-20:]
        last_20_epoch_profile = profile_ls[-20:]
        for ii in range(20):
            if last_20_epoch_profile[ii] >0.0:
                last_20_epoch_profile[ii]=4.0

        avg_profile = sum(last_20_epoch_profile) /20.0
        avg_rec_reward = sum(last_20_epoch_reward)/20.0

        profile = profile_lists[i]
        if profile!=avg_profile:
            print('diff discover')
            print(profile)
            print(avg_profile)
            print('id is ' + str(j) + 'user id ' + str(i))
        if profile ==4.0:
            # recheck whether is the random results
            gamma = args_list[0].normal_user_gamma[i]
            estimate=args_list[0].normal_user_estimate[i].tolist()
            max_estimate_idx = estimate.index(max(estimate))

            # history_action = action % 2
            # attribute_action_coded = int(action / 2)

            if max_estimate_idx ==2:

                diff = estimate[2]-estimate[0]  - gamma
            elif max_estimate_idx ==3:
                diff = estimate[3]-estimate[1]  - gamma
            else:
                print('not profile?')
            profile_effect.append(diff)

            print(profile)
            record_gamma.append(gamma)
            record_reward.append(avg_rec_reward)
            record_non_profile_cnt.append(j)
            if diff<0.008:
                cnt+=1

    print('cnt' + str(cnt))
    plt.plot(profile_effect)
    plt.show()
    plt.plot(record_reward)
    plt.show()
    print('avg_profile_effect = ' + str(sum(profile_effect) / len(record_non_profile_cnt)))
    print('with profile avg rec reward is ' + str(sum(record_reward) / len(record_non_profile_cnt) ))





    print(avg_rec_reward)


    # for i in range(1):
    #     all_share_user=0
    #     profile_only_share_user=0
    #     action_only_share_user=0
    #     non_share_user=0
    #     action_list=action_lists[i][0]
    #     #full_history=action_lists[i][1]
    #
    #     profile_list=profile_lists[i]
    #
    #     for j in range(len(action_list)):
    #         act=action_list[j]
    #         profile=profile_list[j]
    #         if(act>0) and (profile>0):
    #             all_share_user+=1
    #            # print(full_history[j])
    #         elif (act==0) and (profile >0):
    #             action_only_share_user+=1
    #         elif (act>0) and (profile ==0):
    #             profile_only_share_user+=1
    #         elif (act==0) and (profile ==0):
    #             non_share_user+=1
    #     print('in the model ' +label_list[i] + 'the all share user is '+str(all_share_user) +
    #           '| the profile share user is '+str(profile_only_share_user)+
    #           '| the action share user is '+str(action_only_share_user)+
    #           '| the non share user is '+str(non_share_user))


    return final_data_list


def plot_result_summary_risky_user(args_list=[], label_list=[], selected_list=[], plot_name='', save_flag=True):
    final_data_list = []
    args_list = [args_list[i] for i in selected_list]  # 取几个画图
    label_list = [label_list[i] for i in selected_list]

    label_list2 =label_list #[label + 'risky_user' for label in label_list]
    for figure_name in  ['last_20_action','last_20_profile','last_profile']:
        #['privacy_cost', 'rec_reward','last_20_action','last_20_profile', 'last_action','last_profile']:
            #['privacy_cost', 'rec_reward','last_20_action', 'last_action']:
        data_list = plot_summary(args_list=args_list, label_list=label_list2, figure_name=figure_name, id='avg',
                                 normal_user=False)
        final_data_list.append(data_list)

        # write_multi_list_into_txt(file_name='data.txt',data_list=data_list2,figure_name=figure_name)

        plot_show(xlabel='', title='avg ' + figure_name)  # use plot show to show figure and add figure configuration
        if save_flag:
            plt.savefig('./mvlen/'+str(plot_name) + 'risky_user_mvlen_' + str(figure_name) + '.png', bbox_inches='tight')
        plt.show()

    action_lists = final_data_list[0]
    profile_lists = final_data_list[1]

    for i in range(1):
        all_share_user = 0
        profile_only_share_user = 0
        action_only_share_user = 0
        non_share_user = 0
        action_list=action_lists[i][0]
        profile_list = profile_lists[i]

        for j in range(len(action_list)):
            act = action_list[j]
            profile = profile_list[j]
            if (act > 0) and (profile > 0):
                all_share_user += 1
            elif (act == 0) and (profile > 0):
                action_only_share_user += 1
            elif (act > 0) and (profile == 0):

                profile_only_share_user += 1
            elif (act == 0) and (profile == 0):
                non_share_user += 1
        print('in the model ' + label_list[i] + 'the all share user is ' + str(all_share_user) +
              '| the profile share user is ' + str(profile_only_share_user) +
              '| the action share user is ' + str(action_only_share_user) +
              '| the non share user is ' + str(non_share_user))

    return final_data_list


def get_rec_from_rec_list(uid=[], rec_result=0,risky_user_index=[], normal_user_index=[], rec_label='NDCG@100', label='',
                          normal_his=None):
    #rec_result = rec_result_list[rec_label]
    uid_list =uid# rec_result_list['uid']

    # check

    if normal_his is not None:
        x1 = torch.sum(normal_his).int()
        for i, id in enumerate(normal_user_index):
            id1 = uid_list.index(id)
            a1 = normal_his[i].int()
            a2 = rec_result[id1]
            # a3 = rec_result[id ]
            if normal_his[i].float() != rec_result[id1]:
                print('id' + str(normal_his[i]) + ' vs ' + str(rec_result[uid_list.index(id)]))

    all_info_user_rec = []
    risky_user_rec = []
    normal_user_rec = []
    for i, uid in enumerate(uid_list):
        if uid in risky_user_index:
            risky_user_rec.append(rec_result[i])
        elif uid in normal_user_index:
            normal_user_rec.append(rec_result[i])
        else:
            all_info_user_rec.append(rec_result[i])

    avg_user = sum(rec_result) / len(rec_result)
    if len(all_info_user_rec)==0:
        all_infor_user=0
    else:
        all_infor_user = sum(all_info_user_rec) / len(all_info_user_rec)
    if len(risky_user_rec) == 0:
        risky_user = 0
    else:
        risky_user = sum(risky_user_rec) / len(risky_user_rec)
    #risky_user = sum(risky_user_rec) / len(risky_user_rec)
    normal_user = sum(normal_user_rec) / len(normal_user_rec)

    x2 = sum(normal_user_rec)

    print('----')

    print('in the exp ' + label + ' all info user results is ' + str(all_infor_user))
    print('in the exp ' + label + ' normal user results is ' + str(normal_user))
    print('in the exp ' + label + ' risky user results is ' + str(risky_user))
    print('in the exp ' + label + ' avg results is ' + str(avg_user))
    print('----')

    # print( str(sum(normal_user_rec)))

    return avg_user, all_infor_user, normal_user, risky_user


##
# main: load data from model or saved pkl
# then call the function in plot_summary  or args.plot()
# detailed in plot_summary
##
load_from_raw_model = True
if load_from_raw_model:
    args_list = dealer(saved_pkl_name='mvlen_user_feature.pkl')
else:
    args_list = read_from_disk('mvlen.pkl')

rec_results_list = []
uid=[]

mvlen_inital_rec = read_from_disk('/Users/eric.czq/Downloads/privacy_clean/src/mvlen100k_sn424_gru_result.pkl')
mvlen_inital_rec_with_user_feature = read_from_disk('/Users/eric.czq/Downloads/privacy_clean/src/user_user_feature_mvlen100k_sn424_ncf_result.pkl')
# yelp_inital_rec = read_from_disk('/Users/eric.czq/Downloads/privacy_clean/src/yelp_sep4_sn5558_rn2779_gru_result.pkl')
uid = read_from_disk('/Users/eric.czq/Downloads/privacy_clean/src/tmp_mvlen100k_sn424_rn212uid.pkl')

for i, args in enumerate(args_list):
    print('the ' + str(i) + ' model is : ' + str(args.model_file))
    rec_result = read_from_disk(args.model_file[:-7] + 'results_list.pickle')
    # avg_results=rec_result['NDCG@100']
    if (len(rec_result) >= 400) and len(rec_result)<1000:
        tmp = rec_result[380]
        rec_result = rec_result[381:400]
    else:
        tmp = rec_result[-20]
        rec_result=rec_result[-19:]
    #tmp=rec_result[-20]
    for ls in rec_result:
        for j in range(len(ls)):
            tmp[j]+=ls[j]

    avg_result_20 =[j/20.0 for j in tmp]

    #avg_rec_results=tmp/(20.0 * len(rec_result[-1]))
    rec_results_list.append(avg_result_20)

    # print(rec_result)

mv_avg_user, mv_all_infor_user, mv_normal_user, mv_risky_user = get_rec_from_rec_list(rec_result=mvlen_inital_rec['NDCG@100'],
                                                                                      uid=mvlen_inital_rec['uid'],
                                                                                      normal_user_index=args_list[
                                                                                          0].normal_user_id,
                                                                                      risky_user_index=args_list[
                                                                                          0].privacy_risk_user_id,
                                                                                      label='mvlen100k-100%')

# figure_name=['action','privacy_cost','rec_reward','utility',
# # 'gamma','estimation','last_action','non_zero_privacy_cost','non_zero_action']
#     'cnt1', 'cnt2', 'cnt4', 'cnt8', 'cnt16',  # 2,3,4,5,6
#     'post2', 'post4', 'post8', 'post16'  # 7,8,9,10
#
# 'p=1', 'p=2', 'p=4', 'p=8', 'p=16',  # 3,4,5,6 7 cnt
# 'p=2', 'p=4', 'p=8', 'p=16'  # 8,9,10，11 post

### tmp
label_list = [  # mvlen w=10
    'cnt4-NCF','cnt4-bisa','ln4-gru',



]
select_list = [
 [0]
]
#ndcg -> 10

id = 0
plot_name_list = ['NCF','GRU','BisA']

###
# for i in select_list[id]:
#    tmp=args_list[i]
#   tmp.set_plot_epoch(600)

## plot mvlen_cnt1-16 on normal user
list_1 = plot_result_summary_normal_user(args_list, label_list, selected_list=select_list[id],
                                         plot_name=plot_name_list[id], save_flag=False)
# risky user
list_2 = plot_result_summary_risky_user(args_list, label_list, selected_list=select_list[id],
                                        plot_name=plot_name_list[id], save_flag=False)

tmp_list1 = []
tmp_list2 = []
tmp_list3 = []
tmp_list4 = []
for i in select_list[id]:
    dataset_id =  0
    label_tmp = 'mvlen_'

    yelp_avg_user, yelp__all_infor_user, yelp__normal_user, yelp_risky_user = get_rec_from_rec_list(
        rec_result=rec_results_list[i],
        uid=uid,
        normal_user_index=args_list[dataset_id].normal_user_id,
        risky_user_index=args_list[dataset_id].privacy_risk_user_id,
        label=label_tmp + label_list[i])
    # ,normal_his=args_list[i].normal_user_his[2][:,-1])

    tmp_list1.append(yelp_avg_user)
    tmp_list2.append(yelp__all_infor_user)
    tmp_list3.append(yelp__normal_user)
    tmp_list4.append(yelp_risky_user)

delta_a = 0
delta_b = 1
# print(tmp_list1[delta_a] - tmp_list1[delta_b])
# print(tmp_list2[delta_a] - tmp_list2[delta_b])
# print(tmp_list3[delta_a] - tmp_list3[delta_b])
# print(tmp_list4[delta_a] - tmp_list4[delta_b])
