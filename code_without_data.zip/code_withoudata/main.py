# -*- coding: UTF-8 -*-

import os
import sys
import pickle
import logging
import argparse
import numpy as np
import torch
import warnings
import random

from preprocessing.eric_dataloader import *
from preprocessing.Masked_User import *

from models import *
from helpers import *
from utils import utils


def parse_global_args(parser):
    parser.add_argument('--gpu', type=str, default='0',
                        help='Set CUDA_VISIBLE_DEVICES')
    parser.add_argument('--verbose', type=int, default=logging.INFO,
                        help='Logging Level, 0, 10, ..., 50')
    parser.add_argument('--log_file', type=str, default='',
                        help='Logging file path')
    parser.add_argument('--random_seed', type=int, default=2021,
                        help='Random seed of numpy and pytorch.')
    parser.add_argument('--load', type=int, default=0,
                        help='Whether load model and continue to train')
    parser.add_argument('--i_emb_path', type=str, default='',
                        help='The path of pre-trained item embedding file')
    parser.add_argument('--train', type=int, default=1,
                        help='To train the model or not.')
    parser.add_argument('--regenerate', type=int, default=0,
                        help='Whether to regenerate intermediate files.')
    parser.add_argument('--eval_on_sampling', type=int, default=0,
                        help='Eval on random negative samplings or the whole candidate sets.')
    parser.add_argument('--version', type=str, default='1',
                        help='to tackle the problem of log that can only run a model a time')
    parser.add_argument('--user_feature_train', type=bool, default=True,
                        help='Model use User chararter feature or not ')
    return parser


def main():
    logging.info('-' * 45 + ' BEGIN: ' + utils.get_time() + ' ' + '-' * 45)
    exclude = ['check_epoch', 'log_file', 'model_path', 'path', 'pin_memory',
               'regenerate', 'sep', 'train', 'verbose']
    logging.info(utils.format_arg_str(args, exclude_lst=exclude))

    # Random seed
    random.seed(args.random_seed)
    np.random.seed(args.random_seed)
    torch.manual_seed(args.random_seed)
    torch.cuda.manual_seed(args.random_seed)

    # GPU
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu
    logging.info("# cuda devices: {}".format(torch.cuda.device_count()))

    #
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    # mv-len#
    character_feature_len = 4
    action_split_len = 1
    user_feature_train=args.user_feature_train
    ######

    mask_user = mkdataset(dataset='ml-1m', dataset_path='./data/',
                          character_feature_len=character_feature_len, action_split_len=action_split_len,
                          device=device, min_all_information_num=4000)

    mask_user.set_random_user()
    #mask_user.set_random_mask()
    # test tmp
    #print(mask_user.ger_rnd_action_mask())
    # split training set
    print('privacy user number is ' + str(mask_user.rnd_information_user_num))  
    
    privacy_user_id_list = mask_user.get_rnd_information_user_index()
    history_split_mask = mask_user.ger_rnd_action_mask()

    privacy_delete_percentage = int(100 / action_split_len + 1)

    history_split_mode_list = ['sequential', 'random']

    history_split_mode = history_split_mode_list[0]  # set for random = random delete

    # Read data
    corpus = reader_name(args,
                         mask_user=mask_user,
                         history_split_mode=history_split_mode, action_split_len=action_split_len
                         )

    #

    # get user feature embedding
    feature_embedding_dim_list = mask_user.character_feature_embedding_dim

    # Define model
    model = model_name(args, corpus,user_feature_dim=feature_embedding_dim_list,user_feature_train=user_feature_train)

    logging.info(model)
    model = model.double()
    model.apply(model.init_weights)
    model.actions_before_train()
    if torch.cuda.device_count() > 0:
        model = model.cuda()

    # Run model
    data_dict = dict()
    for phase in ['train', 'dev', 'test']:
        ds_args = {'phase': phase,
                   'eval_on_sampling': args.eval_on_sampling,
                   'ns_mode': model.ns_mode,
                   'num_neg': model.num_neg}
        if args.dataset in ('books_2018', 'yelp') and phase == 'dev':
            ds_args['eval_on_sampling'] = 1
        data_dict[phase] = SeqDataset.SeqDataset(corpus, ds_args)

    runner = runner_name(args)

    if args.load > 0:
        model.load_model()
    elif args.i_emb_path != '':
        model.load_pretrained_i_emb(args.i_emb_path)

    # logging.info('Test Before Training: ' + runner.print_res(model, data_dict['test'], args.eval_on_sampling))
    if args.train > 0:
        runner.train(model, data_dict)
    logging.info(
        os.linesep + 'Test After Training: ' + runner.print_res(model, data_dict['test'], args.eval_on_sampling))

    model.actions_after_train()
    logging.info(os.linesep + '-' * 45 + ' END: ' + utils.get_time() + ' ' + '-' * 45)


if __name__ == '__main__':

    # warnings.filterwarnings('ignore')
    warnings.filterwarnings("ignore", category=Warning)

    init_parser = argparse.ArgumentParser(description='Model')
    init_parser.add_argument('--model_name', type=str, default='BPR', help='Choose a model to run.')
    init_args, init_extras = init_parser.parse_known_args()
    model_name = eval('{0}.{0}'.format(init_args.model_name))
    reader_name = eval('{0}.{0}'.format(model_name.reader))
    runner_name = eval('{0}.{0}'.format(model_name.runner))

    # Args
    parser = argparse.ArgumentParser(description='')
    parser = parse_global_args(parser)
    parser = reader_name.parse_data_args(parser)
    parser = runner_name.parse_runner_args(parser)
    parser = model_name.parse_model_args(parser)
    args, extras = parser.parse_known_args()

    # Logging configuration
    log_args = [args.dataset, args.version, str(args.random_seed)]
    # for arg in ['loss', 'num_neg', 'eval_on_sampling', 'dropout', 'lr', 'l2', 'history_max', 'num_heads', 'inner_times', 'num_layers'] + model_name.extra_log_args:
    for arg in ['num_neg', 'min_strategy', 'dropout', 'lr', 'l2'] + model_name.extra_log_args:
        if arg in args:
            log_args.append(arg + '=' + str(eval('args.' + arg)))

    log_file_name = '__'.join(log_args).replace(' ', '__')
    if args.i_emb_path != '':
        log_file_name += '__finetune=' + args.i_emb_path[args.i_emb_path.rfind('/') + 1:args.i_emb_path.find('__')]
    if args.log_file == '':
        args.log_file = '../log/{}/{}.txt'.format(init_args.model_name, log_file_name)
    if args.model_path == '':
        args.model_path = '../model/{}/{}.pt'.format(init_args.model_name, log_file_name)

    utils.check_dir(args.log_file)
    logging.basicConfig(filename=args.log_file, level=args.verbose)
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(init_args)

    main()
