
import os
import time
import pickle
import argparse
import logging
import numpy as np
import pandas as pd
from collections import defaultdict

#%%

def print_data_stat(data,i_stat):
    print('# user', len(data))
    print('# item', len(i_stat))

    behavior_len = [len(v) for k, v in data.items()]
    total_num = sum(behavior_len)
    print('# records', total_num)

    max_u_len = np.max(behavior_len)
    min_u_len = np.min(behavior_len)
    avg_u_len = np.mean(behavior_len)
    med_u_len = np.median(behavior_len)

    print('max user behavior seq len: ', max_u_len)
    print('min user behavior seq len: ', min_u_len)
    print('avg user behavior seq len: ', avg_u_len)
    print('median user behavior seq len: ', med_u_len)

    i_u_len = [v for k, v in i_stat.items()]
    max_i_len = np.max(i_u_len)
    min_i_len = np.min(i_u_len)
    avg_i_len = np.mean(i_u_len)
    med_i_len = np.median(i_u_len)

    print('max item behavior seq len: ', max_i_len)
    print('min item behavior seq len: ', min_i_len)
    print('avg item behavior seq len: ', avg_i_len)
    print('median item behavior seq len: ', med_i_len)

    valid_user_20 = {k: v for k, v in data.items() if len(v) > 20}
    print('# users with len > 20: ', len(valid_user_20))

    valid_user_40 = {k: v for k, v in data.items() if len(v) > 40}
    print('# users with len > 40: ', len(valid_user_40))

    valid_user_20_2k = {k: v for k, v in data.items() if len(v) > 20 and len(v) < 2000}
    print('# users with 2000 > len > 20: ', len(valid_user_20_2k))

    valid_user_40_2k = {k: v for k, v in data.items() if len(v) > 40 and len(v) < 2000}
    print('# users with 2000 > len > 40: ', len(valid_user_40_2k))

    valid_user_20_1k = {k: v for k, v in data.items() if len(v) > 20 and len(v) < 1000}
    print('# users with 1000 > len > 20: ', len(valid_user_20_1k))

    valid_user_40_1k = {k: v for k, v in data.items() if len(v) > 40 and len(v) < 1000}
    print('# users with 1000 > len > 40: ', len(valid_user_40_1k))

    valid_item_5 = {k: v for k, v in i_stat.items() if v > 5}
    print('# item with freq > 5: ', len(valid_item_5))

n_users = 0
n_items = 0
data = defaultdict(list)
#%%


#%%

# user, item, rating, timestamp

data = defaultdict(list)
i_stat = defaultdict(int)
cnt=0

with open('./ml-100k/u.data') as f:
    #next(f)
    for line in f:
        u, i, r, t = line.strip().split('\t')
        data[u].append((i, int(t)))
        i_stat[i] += 1
        cnt+=1
        #print('line is '+ str(cnt))
print_data_stat(data,i_stat)

# valid_data = copy.deepcopy(data)
data = {k: v for k, v in data.items() if len(v) > 40 and len(v) < 2000}


print('--------')

## item > 5,  2000 > # user > 40
while True:
    i_stat = defaultdict(int)
    for u, hist in data.items():
        for i, t in hist:
            i_stat[i] += 1

    i_stat_new = {i: l for i, l in i_stat.items() if l > 5}

    for u, hist in data.items():
        data[u] = [(i, t) for i, t in hist if i in i_stat_new]
    data_new = {u: hist for u, hist in data.items() if len(hist) > 40}

    if len(data_new) == len(data) and len(i_stat) == len(i_stat_new):
        break
    else:
        data = data_new

print_data_stat(data,i_stat)

u_vocab = {}
i_vocab = {}
for u, hist in data.items():
    if u not in u_vocab:
        u_vocab[u] = len(u_vocab) + 1
    for i, t in hist:
        if i not in i_vocab:
            i_vocab[i] = len(i_vocab) + 1
    hist = [(i_vocab[i], t) for i, t in hist]


import json
output = {
        'user_vocab': u_vocab,
        'item_vocab': i_vocab
        }

with open('./ml-100k/ml-100k_vocab.json', 'w') as f:
    json.dump(output, f, indent=4)

max([v for k, v in u_vocab.items()]), max([v for k, v in i_vocab.items()])

data = {u_vocab[u]: [(i_vocab[i], t) for i, t in seq] for u, seq in data.items()}

# sorted by timestamp
data = {k:sorted(v, key=lambda x: x[1]) for k, v in data.items()}

# write file
with open(os.path.join('./ml-100k/', 'ml-100k.csv'), 'w') as f:
    f.write('user_id\titem_id\ttime\n')
    for u, seq in data.items():
        for i, t in seq:
             f.write('\t'.join(map(str, [u, i, t]))+'\n')


