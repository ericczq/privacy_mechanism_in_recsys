import os
from datetime import datetime
from collections import defaultdict
import numpy as np
import pickle
def print_data_stat(data,i_stat):
    print('# user', len(data))
    print('# item', len(i_stat))

    behavior_len = [len(v) for k, v in data.items()]
    total_num = sum(behavior_len)
    print('# records', total_num)

    max_u_len = np.max(behavior_len)
    min_u_len = np.min(behavior_len)
    avg_u_len = np.mean(behavior_len)
    med_u_len = np.median(behavior_len)

    print('max user behavior seq len: ', max_u_len)
    print('min user behavior seq len: ', min_u_len)
    print('avg user behavior seq len: ', avg_u_len)
    print('median user behavior seq len: ', med_u_len)

    i_u_len = [v for k, v in i_stat.items()]
    max_i_len = np.max(i_u_len)
    min_i_len = np.min(i_u_len)
    avg_i_len = np.mean(i_u_len)
    med_i_len = np.median(i_u_len)

    print('max item behavior seq len: ', max_i_len)
    print('min item behavior seq len: ', min_i_len)
    print('avg item behavior seq len: ', avg_i_len)
    print('median item behavior seq len: ', med_i_len)

    valid_user_20 = {k: v for k, v in data.items() if len(v) > 20}
    print('# users with len > 20: ', len(valid_user_20))

    valid_user_40 = {k: v for k, v in data.items() if len(v) > 40}
    print('# users with len > 40: ', len(valid_user_40))

    valid_user_20_2k = {k: v for k, v in data.items() if len(v) > 20 and len(v) < 2000}
    print('# users with 2000 > len > 20: ', len(valid_user_20_2k))

    valid_user_40_2k = {k: v for k, v in data.items() if len(v) > 40 and len(v) < 2000}
    print('# users with 2000 > len > 40: ', len(valid_user_40_2k))

    valid_user_20_1k = {k: v for k, v in data.items() if len(v) > 20 and len(v) < 1000}
    print('# users with 1000 > len > 20: ', len(valid_user_20_1k))

    valid_user_40_1k = {k: v for k, v in data.items() if len(v) > 40 and len(v) < 1000}
    print('# users with 1000 > len > 40: ', len(valid_user_40_1k))

    valid_item_5 = {k: v for k, v in i_stat.items() if v > 5}
    print('# item with freq > 5: ', len(valid_item_5))

data = defaultdict(list)
i_stat = defaultdict(int)

# load_flag=False
# if load_flag:
#  with open('./yelp/yelp_academic_dataset_review.json') as f:
#     cnt=0
#     for line in f:
#         r = eval(line)
#         u = r['user_id']
#         i = r['business_id']
#         t = int(datetime.fromisoformat(r['date']).timestamp())
#         data[u].append((i, int(t)))
#         i_stat[i] += 1
#         cnt+=1
#         if cnt % 200000 ==0:
#             print('now loading '+ str(cnt))
#
#  #f2 = open('data.pkl', 'wb')
#  #pickle.dump(data, f2)
#  #f3 = open('i_stat.pkl','wb')
#  #pickle.dump(i_stat,f3)
# else:
#     with open('data.pkl', 'rb') as file:
#         data = pickle.load(file)
#     with open('i_stat.pkl', 'rb') as file:
#         i_stat = pickle.load(file)

#%% md

#data = defaultdict(list)
with open('./yelp/yelp.csv') as f:
    next(f)
    for line in f:
        u, i, t = line.strip().split('\t')
        data[int(u)].append((int(i), int(t)))
        i_stat[i]+=1

# %% md

# Dataset stat

# %%
# Dataset stat

# %%

print('# user', len(data))
print('# item', len(i_stat))

behavior_len = [len(v) for k, v in data.items()]
total_num = sum(behavior_len)
print('# records', total_num)

max_u_len = np.max(behavior_len)
min_u_len = np.min(behavior_len)
avg_u_len = np.mean(behavior_len)
med_u_len = np.median(behavior_len)

print('max user behavior seq len: ', max_u_len)
print('min user behavior seq len: ', min_u_len)
print('avg user behavior seq len: ', avg_u_len)
print('median user behavior seq len: ', med_u_len)

i_u_len = [v for k, v in i_stat.items()]
max_i_len = np.max(i_u_len)
min_i_len = np.min(i_u_len)
avg_i_len = np.mean(i_u_len)
med_i_len = np.median(i_u_len)

print('max item behavior seq len: ', max_i_len)
print('min item behavior seq len: ', min_i_len)
print('avg item behavior seq len: ', avg_i_len)
print('median item behavior seq len: ', med_i_len)

max_len_uid = 0
for k, v in data.items():
    if len(v) >= max_u_len:
        max_len_uid = k
        break

# id2u = {v:k for k, v in u_vocab.items()}
# id2i = {v:k for k, v in i_vocab.items()}
print('the max seq len user: ', max_len_uid)

valid_user_20 = {k: v for k, v in data.items() if len(v) > 20}
print('# users with len > 20: ', len(valid_user_20))

valid_user_40 = {k: v for k, v in data.items() if len(v) > 40}
print('# users with len > 40: ', len(valid_user_40))

valid_user_20_2k = {k: v for k, v in data.items() if len(v) > 20 and len(v) < 2000}
print('# users with 2000 > len > 20: ', len(valid_user_20_2k))

valid_user_40_2k = {k: v for k, v in data.items() if len(v) > 40 and len(v) < 2000}
print('# users with 2000 > len > 40: ', len(valid_user_40_2k))

valid_user_20_1k = {k: v for k, v in data.items() if len(v) > 20 and len(v) < 1000}
print('# users with 1000 > len > 20: ', len(valid_user_20_1k))

valid_user_40_1k = {k: v for k, v in data.items() if len(v) > 40 and len(v) < 1000}
print('# users with 1000 > len > 40: ', len(valid_user_40_1k))

valid_item_5 = {k: v for k, v in i_stat.items() if v > 5}
print('# item with freq > 5: ', len(valid_item_5))

print('# records with 1000 > seq len > 40', sum([len(v) for k, v in valid_user_40_1k.items()]))

print('# records with 2000 > seq len > 40', sum([len(v) for k, v in valid_user_40_2k.items()]))
