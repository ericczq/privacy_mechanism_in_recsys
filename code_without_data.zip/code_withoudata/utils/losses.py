
import torch.nn.functional as F
import torch.nn as nn
import torch

def bce(model, predictions):
    loss = predictions
    return loss

def bpr_max(model, predictions):
    """
    BPR ranking loss with optimization on multiple negative samples
    @{Recurrent neural networks with top-k gains for session-based recommendations}
    :param predictions: [batch_size, -1], the first column for positive, the rest for negative
    :return:
    """
    pos_pred, neg_pred = predictions[:, :1], predictions[:, 1:]
    neg_softmax = neg_pred.softmax(dim=-1)
    diff = pos_pred - neg_pred
    loss = - torch.log(torch.mean(neg_softmax * diff.sigmoid(), dim=-1)).mean()
    #neg_pred = (neg_pred * neg_softmax).sum(dim=1)
    #loss = F.softplus(-(pos_pred - neg_pred)).mean()
        
    # ↑ For numerical stability, we use 'softplus(-x)' instead of '-log_sigmoid(x)'
    return loss

def bpr(model, predictions):
    pos_pred, neg_pred = predictions[:, :1], predictions[:, 1:]

def top1_max(model, predictions):
    pass

def mrl(model, predictions, margin = 0.2):
    """
    Marginal ranking loss
    @input:
    - predictions: [batch_size, 1+], the first column for positive, the rest for negative
    @return:
    - loss: 
    """
    pos_pred, neg_pred = predictions[:, 0], predictions[:, 1:]
    neg_softmax = (neg_pred - neg_pred.max()).softmax(dim=1)
    neg_pred = (neg_pred * neg_softmax).sum(dim=1)
    y = torch.ones_like(pos_pred)
    loss = -(torch.sigmoid(pos_pred) - torch.sigmoid(neg_pred)) + margin
    loss[loss<0] = 0
    loss = torch.mean(loss)
    return loss

def sigmoid_cross_entropy(model, predictions):
    pos_pred, neg_pred = predictions[:, :1], predictions[:, 1:]
    target = torch.cat([torch.ones_like(pos_pred), torch.zeros_like(neg_pred)], dim=-1)
    loss = nn.BCEWithLogitsLoss()
    loss = loss(predictions, target)
    
    return loss

def softmax_cross_entropy(model, predictions):
    pos_pred, neg_pred = predictions[:, 0], predictions[:, 1:]
    loss = nn.CrossEntropyLoss()
    loss = loss(predictions, torch.zeros_like(pos_pred, dtype=torch.long))
    
    return loss


def get_loss_fn(loss_type):
    return eval(loss_type)
