
class tmp(object):
    def __init__(self):
        self.cnt=0
    def cnt_1(self):
        self.cnt+=1

def test(tmp):
    tmp.cnt_1()


def main():

    a=tmp()
    print(a.cnt)
    test(a)
    print(a.cnt)

if __name__ == '__main__':
    main()